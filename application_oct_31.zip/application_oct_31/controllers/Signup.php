<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Signup extends CI_Controller {
	function __construct(){

        parent::__construct();
        $this->load->helper(array('form','url','date','custom'));
        $this->load->library(array('session','form_validation','email'));
        $this->load->model('signup_model');
    }

    function index(){

    	$data['title'] = 'Sign Up';
    	$this->load->view('templates/sign_up',$data);
	}

    function Sign_up()
	{
        if( $this->input->post('pass') !== $this->input->post('pass2') )
        {
            redirect('index.php/signup');
        }

		$post_data = [
            'username' => $this->input->post('username'),
            'email' => $this->input->post('email'),
            'password' => $this->input->post('pass')
        ];
		$add_data = $this->signup_model->signup($post_data);

    	if($add_data) {
      		$this->session->set_flashdata('msg', '<div class="alert alert-success text-center">Data created successfully.</div>');
			redirect('index.php/login');
		} else {
			$this->session->set_flashdata('msg', '<div class="alert alert-danger text-center">Something Went Wrong form not submitted.</div>');
			redirect('index.php/signup');
		}
	}
}
