<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mentor extends CI_Controller {

	function __construct()
	{
        parent::__construct();
        $this->load->model('mentor_model');
        $this->load->helper(array('form','url','date','custom'));
        $this->load->library(array('session','form_validation','email'));
        is_logged_in();
    }
	function index()
	{
		$data['title'] = 'Mentor Dashboard';
		/* Purpose: Get events */
		$this->load->model('event_model');
		$data['get_events_mentor'] = $this->event_model->get_events_mentor();
    	//$this->load->view('templates/mentor-dash', $data);
    	$this->load->view('templates/mentor-dashboard', $data);
	}
	function profile(){
		$data['title'] = 'Mentor Profile';
		/* Purpose: Get events */
		$this->load->model('mentor_model');
		$data['profile'] = $this->mentor_model->mentor_profile($this->session->userdata('id'));
		//$this->load->view('templates/mentor-dash', $data);
    	$this->load->view('templates/profile', $data);
	}
	
	function add_mentor()
	{
		if($this->input->post())
		{
			$post_data = [
	            'name' => $this->input->post('name'),
	            'email' => $this->input->post('email'),
	            'contact' => $this->input->post('contact'),
	            'gender' => $this->input->post('gender'),
	            'technology' => $this->input->post('technology'),
	            'address' => $this->input->post('address'),
	            'location' => $this->input->post('location'),
	            'unique_id' => uniqid(),
	            'active' => '1'
	        ];

			$add_data = $this->mentor_model->add_mentor($mentor_id = 0, $post_data);

	    	if($add_data) {
	      		$this->session->set_flashdata('msg', '<div class="alert alert-success text-center">Data created successfully.</div>');
				redirect('index.php/mentor-details');
			} else {
				$this->session->set_flashdata('msg', '<div class="alert alert-danger text-center">Something Went Wrong form not submitted.</div>');
				redirect('index.php/add-mentor');
			}
		}
		$data['title'] = 'Add Guru';
    	$this->load->view('templates/add-mentor',$data);
	}
	function mentor_details()
	{
		$data['title'] = 'Guru Details';
		$data['mentors'] = $this->mentor_model->mentor_details();

    	$this->load->view('templates/mentor-dash',$data);
    	/* old
    	$this->load->view('templates/mentor-details',$data);
    	*/
	}
	function edit_mentor($mentor_id = 0)
	{ 
		$data['mentor'] = $this->mentor_model->edit_mentor($mentor_id);
		
		$this->form_validation->set_rules('name','Name','trim|required');
		$this->form_validation->set_rules('email', 'Email', 'trim|required');
		$this->form_validation->set_rules('gender', 'Gender', 'trim|required');
		$this->form_validation->set_rules('technology', 'Technology', 'trim|required');
		$this->form_validation->set_rules('location', 'Location', 'trim|required');
		$this->form_validation->set_rules('contact', 'User Name', 'trim|required');
		$this->form_validation->set_rules('address', 'Address', 'trim|required');
		
		if($this->form_validation->run() === false){
			$data['title'] = 'Edit Guru';
			$this->load->view('templates/edit-mentor', $data);
		} else {
			$this->db->set('name', $this->input->post('name'));
			$this->db->set('email', $this->input->post('email'));
			$this->db->set('gender', $this->input->post('gender'));
			$this->db->set('technology', $this->input->post('technology'));
			$this->db->set('location', $this->input->post('location'));
			$this->db->set('contact', $this->input->post('contact'));
			$this->db->set('address', $this->input->post('address'));
			$this->db->set('updated_date', date('Y-m-d h:i:s'));

			$this->db->where('id', $mentor_id);
$is_updated = $this->db->update('nscm_mentors');

			if($is_updated) {
				$this->session->set_flashdata('msg', '<div class="alert alert-success text-center">Data updated successfully but e-mail not sent to user.</div>');
				redirect('index.php/mentor-details/');
			} else {
				$this->session->set_flashdata('msg', '<div class="alert alert-danger text-center">Something Went Wrong form not edited.</div>');
               redirect('index.php/edit-mentor/'. $mentor_id);
				
			}
		}
	}
	/* Only deactive not active again*/
	function deactive_mentor($id)
    {
        if (empty($id))
        {
            show_404();
        }

        if($this->mentor_model->deactive_mentor($id)){
			$this->session->set_flashdata('message', 'Mentor Deactivated Sucessfully');
			redirect('index.php/mentor-details');  
		}		
    }

	function event_attendance($btn_id,$event_id,$mentor_id)
    {
    	$data['title'] = 'Event Attendance';
        $data['event_attendance'] = get_event_attendance($event_id, $mentor_id, $btn_id);
		$data['btn_id'] = $btn_id;
        $this->load->view('templates/applied-event',$data);

    }/*
    old attendance function
    function get_event_attendance(){

        $event_id = $this->input->post('event_id');
        $mentor_id = $this->session->userdata('id');
        $get_event_attendance = get_event_attendance($event_id, $mentor_id);
        
        $htmlData = '';
       
        foreach ($get_event_attendance as $key => $event_attendance) {
        	$style = ($event_attendance->apply_status == 'Present') ? "style='background-color:#dff0d8;'":'';
        	$checked = ($event_attendance->apply_status == 'Present') ? "checked":'';

	        $htmlData .= "<tr ".$style.">";
		        $htmlData .= '<td><label class="rt-chkbox rt-chkbox-single rt-chkbox-outline">
		                  <input type="checkbox" class="checkboxes" aid="'.$event_attendance->aid.'" eid="'.$event_attendance->eid.'" sid="'.$event_attendance->id.'" sts="'.$event_attendance->apply_status.'" '.$checked.'/>
		                  <span></span></label></td>';
	            $htmlData .= "<td>".$event_attendance->unique_id."</td>";
	            $htmlData .= "<td>".$event_attendance->name."</td>";
	            $htmlData .= "<td>".get_technology($event_attendance->technology)."</td>";  
	            $htmlData .= "<td>".$event_attendance->email."</td>";
	            $htmlData .= "<td>".$event_attendance->address."</td>";
	            $htmlData .= "<td>".$event_attendance->location."</td>";
	            $htmlData .= "<td>".$event_attendance->contact."</td>";
	      	$htmlData .= "</tr>";
        }
        echo $htmlData;
    }*/
    function check_attendance(){

    	$post_data = $this->input->post('data');

		if( count($post_data) > 0 ){
			foreach ($post_data as $post) {
				$post_value = ['apply_status' => 'Present'];

    			$this->db->where('id', $post['aid'])->where('event_id', $post['eid'])->where('student_id', $post['sid'])->where('apply_status', 'Applied');

				$this->db->update('nscm_attendance', $post_value);
    		}
		}
    }
    function event_details()
	{
		$data['title'] = 'Event Details';
		$data['event_details'] = $this->mentor_model->event_details();
		$this->load->view('templates/mentor-event-details',$data);
		
	}
	
	function ask(){
		$data['title'] = 'Ask Question';
		$this->load->view('templates/mentor-faq',$data);
	}

} //End Class
