<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Student extends CI_Controller {

	function __construct(){
        parent::__construct();
        $this->load->helper(array('form','url','date','custom'));
        $this->load->library(array('session','form_validation','email'));
        $this->load->model('Student_model');
        is_logged_in();

    }
	
	function index()
	{
		$data['title'] = 'Events List';
        $data['student_past_event'] = $this->Student_model->student_events('past');
        $data['student_upcoming_event'] = $this->Student_model->student_events('upcoming');
        // $this->load->view('templates/student-dashboard',$data);
        $this->load->view('templates/student-index',$data);
	}
	
	function profile(){
		$data['title'] = 'Profile';
		$data['profile'] = $this->Student_model->user_profile($this->session->userdata('id'));
		$this->load->view('templates/student-profile',$data);
	}
	
    /*function get_events_student(){
        $this->load->model('Event_model');
        $data['get_events_student'] = $this->Student_model->get_events_student();
        $this->load->view('templates/student-dash',$data);

    }*/
    function student_events()
    {
        $data['title'] = 'Student Event Details';
        $data['student_past_event'] = $this->Student_model->student_events('past');
        $data['student_upcoming_event'] = $this->Student_model->student_events('upcoming');
        $this->load->view('templates/student-dashboard',$data);
    }
    function apply_event()
    {
        $data['apply_event'] = $this->Student_model->apply_event();
        $this->load->view('templates/student-view-detail', $data);
    }
	function delete_student($id)
    {
        if (empty($id))
        {
            show_404();
        }

        if($this->Student_model->delete_mentor($id)){
			$this->session->set_flashdata('message', 'Mentor Deleted Sucessfully');
			redirect('index.php/student');
		}		
    }
    /*Student ask a question*/
    function ask()
    {
        $data['title'] = 'Ask a question';
        $this->load->view('templates/faq',$data);
    }
    function applyforevent(){
        echo $this->Student_model->applyforevent($this->input->post());
    }
    /*Student Bar Chart*/
    function student_barchart()
    {
        echo $this->Student_model->student_barchart();
    }
    /*Student Feedback*/
    function student_feedback($event_id =0,$student_id=0)
    {
		$data['title'] = 'Feedback';
		$att_id =  student_feedback($event_id,$student_id);
		$data['title'] = 'Feedback';
		// $result = $this->Student_model->student_feedback($this->input->post(),$eid=0);
		// print_r($result);
		$validations = [
			['fname','First Name','required|trim'],
			['lname','Last Name','required|trim'],
			['email','Email','required|trim'],
			['let_know','Please let us know if (on a scale of 1-5)','required|trim'],
			['session_name','Which Session did you attend?','required|trim'],
			['satisfied','How satisfied are you with the content of the session?','required|trim'],
			['information','Any information that you think was not covered in the session?','required|trim'],
			['interest','Are you already working in your area of primary interest?','required|trim'],
			['assessment','Overall assessment of the event?','required|trim'],
			['comment','Any additional comments?','required|trim'],
			['rating','Rate the relevance of the session on a scale of 1-5?','required|trim']
		];
		$this->form_validation->set_rules($validations);
		if($this->form_validation->run() == false){
			$this->load->view('templates/feedback-form',$data);
		}else{
			echo 'success';
			exit;
			$arr = [
				'fk_att' => $att_id,
				'first_name' => $this->input->post('fname'),
				'last_name' => $this->input->post('lname'),
				'email' => $this->input->post('email'),
				'let_know' => $this->input->post('let_know'),
				'session_name' => $this->input->post('session_name'),
				'satisfied' => $this->input->post('satisfied'),
				'information' => $this->input->post('information'),
				'interest' => $this->input->post('interest'),
				'assessment' => $this->input->post('assessment'),
				'comments' => $this->input->post('comment'),
				'rating' => $this->input->post('rating')
			];
			
			$this->db->insert('nscm_feedback',$arr);
			redirect('index.php/student-event-details');
		}
    }

	

} //End Class
