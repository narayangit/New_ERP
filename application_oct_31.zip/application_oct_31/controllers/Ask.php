<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ask extends CI_Controller {

	function __construct(){
        parent::__construct();
        $this->load->helper(array('form','url','date','custom'));
        $this->load->library(array('session','form_validation','email'));
        $this->load->model('Ask_model');
        is_logged_in();

    }
	
	
	function get(){
		$sender_id = $this->input->post('sender_id');
		$receiver_id = $this->input->post('receiver_id');
		$data = $this->Ask_model->get_messages($sender_id,$receiver_id);
		echo json_encode($data);
	}
	
	function send(){
		$msgArr = [
			'sender_id' => $this->input->post('sender_id'),
			'receiver_id' => $this->input->post('receiver_id'),
			'msg' => $this->input->post('msg')
		];
		$this->db->insert('nscm_ask',$msgArr);
		$last_row_id = $this->db->insert_id();
		$result = $this->db->select("time")->from("nscm_ask")->where("id", $last_row_id)->get();
		$get_time = $result->row()->time;
		$time = date('M d, Y h:i:s a',strtotime($get_time));
		
		$data['username'] = $this->session->userdata('username');
		$data['msg'] = $this->input->post('msg');
		$data['time'] = $time;
		echo json_encode($data);
	}
	

} //End Class
