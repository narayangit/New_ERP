<?php if($this->session->userdata('username')) {  redirect('user'); } ?>
<?php include("common/header.php"); ?>
<div class="login-container">
    <div class="row">
        <div class="col-md-12">
            <div class="text-center m-b-md">
                <h3>PRDP</h3>
                <small>Performnace Review Development Plan</small>
            </div>
            <div class="hpanel">
                <div class="panel-body">
					<?php echo $this->session->flashdata('msg'); ?>
					<?php
					$attributes = array("class" => "m-t", "id" => "loginform", "name" => "loginform","onsubmit" =>"Login.disabled=true; Login.value ='Please wait...'; return true;");
					echo form_open("login", $attributes); ?>
					<div class="form-group">
						<label class="control-label" for="username">Username</label>
						<input type="text" placeholder="Enter MK ID" title="Please enter your username"  name ="username" value="<?php echo set_value('username'); ?>"    id="username" class="form-control">
						<span class="help-block small" style="color:#FF0000;"><?=form_error('username'); ?></span>
					</div>
					<div class="form-group">
						<label class="control-label" for="password">Password</label>
						<input type="password" title="Please enter your password" placeholder="******"  name="password" value="<?php echo set_value('password'); ?>" id="password" class="form-control">
						<span class="help-block small" style="color:#FF0000;"><?=form_error('password'); ?></span>
					</div>
					<!-- <div class="checkbox">
						<input type="checkbox" class="i-checks" checked>
							 Remember login
						<p class="help-block small">(if this is a private computer)</p>
					</div> -->
					<input type="Submit" class="btn btn-success btn-block" name="Login" value="<?php echo $pageid; ?>">
					<a  class="btn btn-default btn-block" href="login/resetpassword">Forgot Password</a>
					</form>
				</div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 text-center">
            <!-- <strong>PRDP</strong> - Performnace Review Development Plan <br/>  --><?php echo date('Y')?> Copyright Mattsenkumar
        </div>
    </div>
</div>
<?php include("common/footer.php"); ?>
