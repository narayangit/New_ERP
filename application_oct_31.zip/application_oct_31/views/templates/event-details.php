<?php 
 //die;
include 'common/header_view.php';
include 'common/sidebar_view.php';
?>
			<!-- start page content -->
            <div class="page-content-wrapper">
                <div class="page-content">
				<div class="page-bar">
				<?php echo $this->session->flashdata('msg');?>
                        <div class="page-title-breadcrumb">
                            <div class=" pull-left">
                                <div class="page-title">Session Details</div>

                            </div>
                            <ol class="breadcrumb page-breadcrumb pull-right">
                                <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="index.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                                </li>
                                <li class="active">Session Details</li>
                            </ol>
                        </div>
                    </div>


<!-- AddEvent added by Narayan -->
					<div class="row">
                      <div class="col-md-12">
                        <div class="" id="line-parent">
  									      <div class="panel-group accordion" id="accordion3">
                            <div class="panel panel-default">
                              <div class="panel-heading panel-heading-blue">
												        <a class="accordion-toggle accordion-toggle-styled collapsed icon-cal" data-toggle="collapse" data-parent="#accordion3" href="#collapse_3_2">
                                  <h4 class="panel-title calender-heading ">Add Session <i class="fa fa-plus plus-custom"></i></h4>
                                </a>
                              </div>
                  <div id="collapse_3_2" class="panel-collapse collapse">
                    <div class="panel-body">           
                      <div class="row">
                        <div class="col-md-12 col-sm-12">
                            <div class="">
                               
                                <div class="card-body" id="bar-parent2">
                                    <?php 
                                      $attributes = array("class" => "form-horizontal","id" =>"form_sample_2","onsubmit" =>"submit.disabled=true; submit.value ='Please wait...'; return true;");
                                      echo form_open_multipart(BASEURL."add-event",$attributes);
                                    ?>
                                        <div class="form-body">
                                        <div class="row">
                                        <div class="col-md-4">
                                                <div class="form-group  ">
                                                <label class="control-label ">Session Name
                                                    <span class="required"> * </span>
                                                </label>
                                                <div class="">
                                                    <div class="input-icon ">
                                                        <i class="fa"></i>
                                                        <input type="text" class="form-control" name="event_name" id="event_name" />
                                                      </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                          <div class="form-group  ">
                                            <label class="control-label ">Guru Name
                                                <span class="required"> * </span>
                                            </label>
                                            <div class="">
                                                <div class="input-icon ">
                                                    <i class="fa"></i>
                                                    <select class="form-control" required name="guru_name" id="guru_name">
                                                      <option value="">--Select--</option>
                                                      <?php echo mentor_list();?>
                                                    </select>
                                                  </div>
                                            </div>
                                          </div>
                                        </div>
                                        <div class="col-md-4">
                                          <div class="form-group  ">
                                            <label class="control-label ">Technology
                                                <span class="required"> * </span>
                                            </label>
                                            <div class="">
                                                <div class="input-icon ">
                                                    <i class="fa"></i>
                                                    <select class="form-control" required name="tech_name" id="tech_name">
                                                      <option value="">--Select--</option>
                                                      <?php echo technologies('event');?>
                                                    </select>
                                                  </div>
                                            </div>
                                          </div>
                                        </div>

                                      <div class="col-md-4">
                                        <div class="form-group">
                                        <label class="control-label "> Start DateTime
                                                    <span class="required"> * </span>
                                                </label>
                                            <div class="input-append date form_datetime">
                                              <input size="30" type="text" class="form-control" name="start_date" id="start_date" value="<?=date('Y-m-d h:i:s');?>" readonly>
                                              <span class="add-on"><i class="fa fa-calendar icon-th "></i></span>
                                          </div>
                                        </div>
                                      </div>

                                      <div class="col-md-4">
                                        <div class="form-group">
                                        <label class="control-label "> End DateTime
                                                    <span class="required"> * </span>
                                                </label>
                                            <div class="input-append date form_datetime">
                    											    <input size="30" type="text" class="form-control" name="end_date" id="end_date" value="<?=date('Y-m-d h:i:s', strtotime('+2 hours'));?>" readonly>
                    											    <span class="add-on"><i class="fa fa-calendar icon-th "></i></span>
                    											</div>
                                        </div>
                                      </div>

                                        <div class="col-md-4">
                                          <div class="form-group">
                                            <label>Location</label>
                                            <select class="form-control" required name="location" id="location">
                                                <option value="">--Select--</option>
                                                <option value="Bengaluru">Bengaluru</option>
                                                <option value="Hyderabad">Hyderabad</option>
                                                <option value="New Delhi">New Delhi</option>
                                                <option value="Gurugram">Gurugram</option>
                                                <option value="Noida">Noida</option>
                                                <option value="Ghaziabad">Ghaziabad</option>
                                            </select>
                                         </div>
                                        </div>
                                        
	                                      <div class="col-md-6">
	                                        
	                                          <div class="form-group  ">
	                                          <label class="control-label ">Venue
	                                              <span class="required"> * </span>
	                                          </label>
	                                          <div class="">
	                                              <div class="input-icon ">
	                                                  <i class="fa"></i>
	                                                  <input type="text" class="form-control" name="address" id="address" /> </div>
	                                          </div>
	                                      </div>
	                                      </div>
										 <div class="col-md-6">
										
										  <div class="form-group  ">
										  <label class="control-label ">Session Logo
											  <span class="required"> * </span>
										  </label>
									
											  <div class="input-icon ">
												
												  <input type="file" name="event_logo" id="event_logo" /> </div>
									
										  </div>
										  </div> 
                                            </div>
                                            </div>
                                     
                                            <div class="col-md-12 text-center">
                                                <button type="submit" class="btn  btn-circle btn-primary ">Submit</button>
                                            </div>
                                        
                                    </form>
                                </div>
                            </div>
                        </div>                         
                      </div>
                  </div>
              </div>
            </div>
          </div>
        </div>
      </div>
   </div>
<!--End by Narayan -->

                <div class="row">
                        <div class="col-md-12">
                            <div class="panel tab-border card-box event-info">
                                <header class="panel-heading panel-heading-gray custom-tab">
                                    <ul class="nav">
                                   
                                        <li class="nav-item">
                                        	<a href="#about" data-toggle="tab" >Past Session</a>
                                        </li>
                                        <li class="nav-item">
                                        	<a href="#profile" data-toggle="tab" class="active">Upcoming Session</a>
                                        </li>
                                    </ul>
                                </header>
                    <div class="panel-body">
                        <div class="tab-content">
			                <div class="tab-pane" id="about">
			                    <div class="row thumb-icon">

                    <?php foreach ($event_details as $events) {

                    	$pastDate = date('Y-m-d', strtotime($events->start_date));
						$now = date('Y-m-d');

						if( $pastDate < $now ){
                        	$total_applied_students = (int) count_applied_students($events->id);
                        	$total_attended_students = (int) count_attend_students($events->id);
                         ?>
		                <div class="col-lg-4 col-md-6 col-12 col-sm-6 ">
							<div class="blogThumb">
								<div class="thumb-center">
                                    <!-- <div class="brand-badge">
                                        <img src="images/logo.png" alt="img">
                                    </div> -->
                                <img class="img-responsive" alt="user" src="<?= base_url("uploaded_logo/".$events->logo) ?>">
                            
                            </div>
								<div class="course-box">
							
									<h5 class="event-name text-center"> <?php echo $events->technology;?></h5>
									<p><span><i class="fa fa-user" aria-hidden="true"></i><?php echo get_name($events->mentor_id);?></span></p>
									<p><span> <i class="fa fa-calendar-o" aria-hidden="true"></i><?php echo $events->start_date." - ".$events->end_date;?></span></p>
			                        <p class="event-add-info"><span><i class="fa fa-address-card-o" aria-hidden="true"></i><?php echo $events->city." ".$events->address;?></span></p>

			                        <p>
										<a href="<?= BASEURL . 'event-attendance/1/'.$events->id.'/'.$events->mentor_id;?>" class="btn btn-circle btn-primary btn-sm">Registered <?=$total_applied_students;?></a>
										<a href="<?= BASEURL . 'event-attendance/2/'.$events->id.'/'.$events->mentor_id;?>" class="btn btn-circle  btn-success btn-sm">Participant <?=$total_attended_students?></a> <br>
										<span style='float:right; margin-right:20%; font-size:10px; color:red'> * check feedback</span>
									</p>
			                    </div>
							</div>
						</div>
					<?php
						 }
					 }
					 ?>
					</div>
		        </div>

        <div class="tab-pane active" id="profile">
            <div class="row thumb-icon">
				<?php foreach ($event_details as $events) {

					$upcomingDate = date('Y-m-d', strtotime($events->start_date));
					$now = date('Y-m-d');

					if( $upcomingDate >= $now ){
                   
					$total_applied_students = (int) count_applied_students($events->id);
				 ?>
	                <div class="col-lg-3 col-md-6 col-12 col-sm-6 ">
						<div class="blogThumb">
							<div class="thumb-center"><img class="img-responsive" alt="user" src="../assets/img/course/course1.jpg"></div>
							<div class="course-box">
								<!-- <h4>Event Details</h4> -->
								<p><span> <i class="fa fa-address-card" aria-hidden="true"></i><?php echo $events->technology;?></span></p>
								<p><span><i class="fa fa-user" aria-hidden="true"></i><?php echo get_name($events->mentor_id);?></span></p>
								<p><span> <i class="fa fa-calendar-o" aria-hidden="true"></i><?php echo $events->start_date." - ".$events->end_date;?></span></p>
		                        <p><span><i class="fa fa-address-card-o" aria-hidden="true"></i><?php echo $events->city." ".$events->address;?></span></p>
		                        <p><a href="<?= BASEURL . 'event-attendance/1/'.$events->id.'/'.$events->mentor_id;?>"" class="btn btn-round btn-primary btn-sm">Registered <?=$total_applied_students;?></a>
		                    </div>
						</div>
					</div>
					<?php
						 }
					 }
					?>
				</div>
        	</div>
     
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
</div>
<?php include 'common/footer_view.php'; ?>
</body>
</html>