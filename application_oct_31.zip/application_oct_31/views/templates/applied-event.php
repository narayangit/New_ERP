<?php 
//print_r($event_attendance);die;
include 'common/header_view.php';
include 'common/sidebar_view.php';
?>

 
			<!-- start page content -->
            <div class="page-content-wrapper">
                <div class="page-content">
                  <div class="row">
                      <div class="col-md-12">
					  <?php 
						$usertype = $this->session->userdata('usertype');
						if($usertype == 1){ ?>
						<a href="<?php echo BASEURL . 'event-details';?>" class="btn btn-circle btn-primary"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</a>  
						<?php }else if($usertype == 2){ ?>
						  <a href="<?php echo BASEURL . 'mentor-event-details';?>" class="btn btn-circle btn-primary"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</a>  
						<?php } ?>
					  
                      </div>
                  </div>  
                    
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card card-topline-red">
                                <div class="card-head">
                                    <header>Attendance</header>
                                    <div class="tools">
                                        <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
	                                    <a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
	                                    <a class="t-close btn-color fa fa-times" href="javascript:;"></a>
                                    </div>
                                </div>
                                <div class="card-body ">
								<?php if($usertype ==2 && $btn_id == 1){ ?>
                                <div class="row">
									<div class="col-md-12 col-sm-12 col-12">
										<div class="btn-group">
										<button type="button" class="btn btn-round btn-primary" id="button" onClick="check_attendance();" disabled="disabled">Submit</button>
										</div>
									</div>
								</div>
								<? } ?>
                                    <div class="table-scrollable">
									
                                    <table class="table table-striped table-bordered table-hover table-checkable order-column" style="width: 100%" id="example4">
                                        <thead>
                                            <tr>
                                                <?php if($this->session->userdata('usertype') == 2 && $btn_id == 1) echo "<th>#</th>" ?>
                                                <th> Reffrence Id </th>
                                                <th> Name </th>
                                                <th> Technology Name </th>
                                                <th> Email </th>
                                                <th> Address </th>
                                                <th> City </th>
                                                <th> Contact </th>
												<?php if($btn_id == 2){ ?>
                                                <th> Feedback </th>
												<th> Rating </th>
												<?php } ?>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                            if(count($event_attendance)>0){
												$i=1;
                                            foreach ($event_attendance as $key => $attendance) { 
											$style = '';
												if($this->session->userdata('usertype') == 2):
													$style = ($attendance->apply_status == 'Present') ? "style='background-color:#dff0d8;'":'';
												endif;
												
                                                
                                                echo "<tr ".$style.">";
												  if($this->session->userdata('usertype') == 2 && $btn_id == 1):
                                                $checked = ($attendance->apply_status == 'Present') ? "checked":'';
                                                    echo '<td><label class="rt-chkbox rt-chkbox-single rt-chkbox-outline">
                                                              <input type="checkbox" class="checkboxes" aid="'.$attendance->aid.'" eid="'.$attendance->eid.'" sid="'.$attendance->id.'" sts="'.$attendance->apply_status.'" '.$checked.'/>
                                                              <span></span></label></td>';
													endif;
													
                                                    echo "<td>".$attendance->unique_id."</td>";
                                                    echo "<td>".$attendance->name."</td>";
                                                    echo "<td>".$attendance->technology."</td>";  
                                                    echo "<td>".$attendance->email."</td>";
                                                    echo "<td>".$attendance->address."</td>";
                                                    echo "<td>".$attendance->location."</td>";
                                                    echo "<td>".$attendance->contact."</td>";
													if($btn_id == 2){ 
                                                    echo "<td>".$attendance->feedback."</td>";
													$rating = $attendance->rating;?>
													<td>
														<div class="rating" style='pointer-events:none;'>
														<input id="star5" name="rating_<?= $i ?>" type="radio" value="5" class="radio-btn hide" <?= ($rating == 5)?'checked':'' ?>  />
														<label for="star5" >☆</label>
														<input id="star4" name="rating_<?= $i ?>" type="radio" value="4" class="radio-btn hide" <?= ($rating == 4)?'checked':'' ?>   />
														<label for="star4" >☆</label>
														<input id="star3" name="rating_<?= $i ?>" type="radio" value="3" class="radio-btn hide" <?= ($rating == 3)?'checked':'' ?>  />
														<label for="star3" >☆</label>
														<input id="star2" name="rating_<?= $i ?>" type="radio" value="2" class="radio-btn hide" <?= ($rating == 2)?'checked':'' ?>  />
														<label for="star2" >☆</label>
														<input id="star1" name="rating_<?= $i ?>" type="radio" value="1" class="radio-btn hide" <?= ($rating == 1)?'checked':'' ?>  />
														<label for="star1" >☆</label>
														<div class="clear"></div>
													</div>
													</td>
														<?php } ?>

													
                                                <?php echo "</tr>";
                                            $i++;}
											}
                                            ?>
                                        </tbody>
                                    </table>
									
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
        </div>

</div>
</div>
<?php include 'common/footer_view.php'; ?>

<script type="text/javascript">

$('input[type=checkbox]').on('click',function(){
  $("input:checkbox").each(function(){
    var len = $("input:checked").length;
    if(len > 0){
      $("#button").prop('disabled',false);
    }else{
      $("#button").prop('disabled',true);
    }
  });
});
              
function check_attendance()
{
    obj = new Array();
    $("input:checkbox").each(function(){
      if($(this).is(":checked")){
        obj.push({'aid': $(this).attr("aid"),'eid': $(this).attr("eid"),'sid': $(this).attr("sid"),'apply_status': $(this).attr("sts")});
      }
    });
    if( obj.length > 0 ){
      $.ajax({
        url: '<?php echo BASEURL . "mentor/check_attendance";?>',
        method : 'post',
        data: {'data': obj},
        success : function(data){
          location.reload();
        }
      });
    }
} //End function


// rating function start

// rating function end

</script>

</body>
</html>