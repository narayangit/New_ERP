<?php 

include 'common/header_view.php';
include 'common/sidebar_view.php';
?>

 
			<!-- start page content -->
            <div class="page-content-wrapper">
                <div class="page-content">
                    <div class="page-bar">
                        <div class="page-title-breadcrumb">
                            <div class=" pull-left">
                                <div class="page-title">User/Ask Question</div>
                            </div>
                            <ol class="breadcrumb page-breadcrumb pull-right">
                                <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="index.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                                </li>
                                <li class="active">User/Ask Question</li>
                            </ol>
                        </div>
                    </div>
                   <!-- start widget -->
                   <div class="row">
					        
                   <div class="col-lg-8 col-md-8 col-sm-12 col-12">
                        	<div class="card  card-box">
                                <div class="card-head">
                                    <header id='selected_user_name'>Ask Question</header>
                                </div>
                                <div class="card-body no-padding height-9">
								
                                    <div class="row">
                                        <ul class="chat nice-chat small-slimscroll-style">
                                            <li class="in"><img src="<?= base_url()?>assets/img/prof/prof1.jpg" class="avatar" alt="">
                                                <div class="message">
                                                    <span class="arrow"></span> <a class="name" href="#">Jone
														Doe</a> <span class="datetime">at Mar 12, 2014 6:12</span> <span class="body"> Lorem ipsum dolor sit amet,
														consectetuer adipiscing elit </span>
                                                </div>
                                            </li>
                                            <li class="out"><img src="<?= base_url()?>assets/img/dp.jpg" class="avatar" alt="">
                                                <div class="message">
                                                    <span class="arrow"></span> <a class="name" href="#">Kiran
														Patel</a> <span class="datetime">at Mar 12, 2014 6:13</span> <span class="body"> sed diam nonummy nibh euismod
														tincidunt ut </span>
                                                </div>
                                            </li>
                                        </ul>
                                        <div class="box-footer chat-box-submit">
						                <form action="#" method="post">
						                  <div class="input-group">
											<input type='hidden' name='sender_id' id='sender_id' value='<?= $this->session->userdata('id') ?>'>
											<input type='hidden' name='receiver_id' id='receiver_id'>
											<input type='hidden' name='picture' id='picture'>
						                    <input type="text" name="message" id="message" placeholder="Enter your ToDo List" class="form-control">
						                    <span class="input-group-btn">
						                    <button type="button" class="btn btn-warning btn-flat" onclick='send( $("#message").val() )'><i class="fa fa-arrow-right"></i></button>
						                    </span> </div>
						                </form>
					               </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-12 col-12">
                             <div class="card card-box">
                                 <div class="card-head">
                                     <header>Guru's List</header>
                                 </div>
                                 <div class="card-body ">
                                 <div class="row">
                                        <ul class="docListWindow small-slimscroll-style">
										<?php $mentors =  mentor_list_for_chat(); 
											foreach($mentors as $mentor):
										?>
                                            <li>
                                                <div class="prog-avatar">
                                                    <img src="<?= $mentor->picture_url ?>" alt="" width="40" height="40">
                                                </div>
                                                <div class="details">
                                                    <div class="title">
                                                        <a href="javascript:void(0)" onclick='getUser("<?= $mentor->first_name." ". $mentor->last_name ?>","<?= $mentor->id ?>","<?= $mentor->picture_url ?>")' ><?= $mentor->first_name." ". $mentor->last_name ?></a> -(<?= $mentor->technology ?>)
                                                    </div>
                                                </div>
                                            </li>
										<?php endforeach; ?>
                                          
                                        </ul>
                                        <div class="full-width text-center p-t-10" >
												<a href="#" class="btn purple btn-outline btn-circle margin-0">View All</a>
											</div>
                                    </div>
                                 </div>
                             </div>
						</div>


					     
                    					</div>
					
					<!-- end widget -->

			       
        </div>
</div>
        <!-- end page container -->
<?php include 'common/footer_view.php'; ?>

<script>
function getUser(username,userid,picture){
	$('#selected_user_name').text(username);
	$('#receiver_id').val(userid);
	$('#picture').val(picture);
	// console.log(picture);
	var sender_id = $('#sender_id').val();
	var receiver_id = $('#receiver_id').val();
	$.ajax({
		url:'<?php echo BASEURL . "ask/get";?>',
		type: 'POST',
		datatype: 'JSON',
		data: {sender_id:sender_id,receiver_id:receiver_id},
		success: function(data){
			// var obj = JSON.parse(data);
			console.log(data);
			// var msg = '<li class="out"><img src="'+pic+'" class="avatar" alt=""><div class="message"><span class="arrow"></span> <a class="name" href="#">'+obj.username+'</a> <span class="datetime">at '+ obj.time +'</span> <span class="body"> '+ obj.msg +' </span></div></li>';
			// $('.chat').append(msg);
			// $('#message').val('');
		}
	}); //End ajax
	
	// var msg = '<li class="in"><img src="assets/img/dp.jpg" class="avatar" alt=""><div class="message"><span class="arrow"></span> <a class="name" href="#">Kiran Patel</a> <span class="datetime">at Mar 12, 2014 6:13</span> <span class="body"> hiiiiiiiiiiiiii </span></div></li>';
	// $('.chat').append(msg)
}

function send(msg){
	var sender_id = $('#sender_id').val();
	var receiver_id = $('#receiver_id').val();
	var pic = $('#picture').val();
	// console.log(" pic:- "+pic);
	$.ajax({
		url:'<?php echo BASEURL . "ask/send";?>',
		type: 'POST',
		datatype: 'JSON',
		data: {sender_id:sender_id,receiver_id:receiver_id,msg:msg},
		success: function(data){
			var obj = JSON.parse(data);
			console.log(obj.msg);
			var msg = '<li class="out"><img src="'+pic+'" class="avatar" alt=""><div class="message"><span class="arrow"></span> <a class="name" href="#">'+obj.username+'</a> <span class="datetime">at '+ obj.time +'</span> <span class="body"> '+ obj.msg +' </span></div></li>';
			$('.chat').append(msg);
			$('#message').val('');
		}
	}); //End ajax
}
</script>

</body>
</html>