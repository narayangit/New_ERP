<?php 

include 'common/header_view.php';
include 'common/sidebar_view.php';
?>
<div class="page-content-wrapper">
                <div class="page-content">
                    <div class="page-bar">
                        <div class="page-title-breadcrumb">
                            <div class=" pull-left">
                                <div class="page-title">Form</div>
                            </div>
                            <ol class="breadcrumb page-breadcrumb pull-right">
                                <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="index.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                                </li>
								<li class="active">Feedback Form</li>
                            </ol>
                        </div>
                    </div>

<div class="row">
                        <div class="col-md-12 col-sm-12">
                            <div class="card card-box">
                                <div class="card-head">
                                    <header>Feedback Form</header>
                                </div>
                                <div class="card-body" id="bar-parent2">
                                    <!--<form action="#" id="form_sample_2" class="form-horizontal" novalidate="novalidate"> -->
									<?php echo form_open('index.php/feedback',['id'=>'form_sample_2','class'=>'form-horizontal','novalidate'=>'novalidate']) ?>
                                        <div class="form-body">
                                        <div class="row">
                                        <div class="col-md-4">
                                          
                                              
                                                <div class="form-group  ">
                                                <label class="control-label ">First Name
                                                    <span class="required" aria-required="true"> * </span>
                                                </label>
                                                <div class="">
                                                    <div class="input-icon ">
                                                        <i class="fa"></i>
                                                        <input type="text" class="form-control" name="fname" value='<?= $this->session->userdata('username') ?>'  readonly> </div>
                                                </div>
                                            </div>
                                            </div>
                                            <div class="col-md-4">
                                          
                                              
                                          <div class="form-group  ">
                                          <label class="control-label ">Last Name
                                              <span class="required" aria-required="true"> * </span>
                                          </label>
                                          <div class="">
                                              <div class="input-icon ">
                                                  <i class="fa"></i>
                                                  <input type="text" class="form-control" name="lname"> </div>
                                          </div>
                                      </div>
                                      </div>
                                      <div class="col-md-4">
                                          
                                              
                                          <div class="form-group  ">
                                          <label class="control-label ">Email Address
                                              <span class="required" aria-required="true"> * </span>
                                          </label>
                                          <div class="">
                                              <div class="input-icon ">
                                                  <i class="fa"></i>
                                                  <input type="text" class="form-control" name="email" value='<?= $this->session->userdata('email') ?>'  readonly> </div>
                                          </div>
                                      </div>
                                      </div>
                                            <div class="col-md-12">
                                            <div class="form-group">
	                                            <label>Please let us know if (on a scale of 1-5)</label>
	                                            <select class="form-control" required="" aria-required="true" name='let_know' >
                                                <option value="">Choose</option>
	                                                <option value='the Presenter was easy to understand?'>the Presenter was easy to understand?</option>
	                                                <option value='Meeting your fellow participants was one of the highlights of the session?'>Meeting your fellow participants was one of the highlights of the session?</option>
	                                                <option value='you look forward to attending the next session?'>you look forward to attending the next session?</option>
	                                            
	                                            </select>
	                                        </div>
                                            </div>
                                            <div class="col-md-4">
                                          
                                              
                                          <div class="form-group  ">
                                          <label class="control-label ">Which Session did you attend?
                                              <span class="required" aria-required="true"> * </span>
                                          </label>
                                          <div class="">
                                              <div class="input-icon ">
                                                  <i class="fa"></i>
                                                  <input type="text" class="form-control" name="session_name"> </div>
                                          </div>
                                      </div>
                                      </div>
                        
                                      <div class="col-md-8">
                                          
                                              
                                          <div class="form-group  ">
                                          <label class="control-label ">How satisfied are you with the content of the session?
                                              <span class="required" aria-required="true"> * </span>
                                          </label>
                                          <div class="">
                                              <div class="input-icon ">
                                                  <i class="fa"></i>
                                                  <input type="text" class="form-control" name="satisfied"> </div>
                                          </div>
                                      </div>
                                      </div>
                                      <div class="col-md-6">
                                          
                                              
                                          <div class="form-group  ">
                                          <label class="control-label ">Any information that you think was not covered in the session?
                                              <span class="required" aria-required="true"> * </span>
                                          </label>
                                          <div class="">
                                              <div class="input-icon ">
                                                  <i class="fa"></i>
                                                  <input type="text" class="form-control" name="information"> </div>
                                          </div>
                                      </div>
                                      </div>
                                      <div class="col-md-6">
                                          
                                              
                                          <div class="form-group  ">
                                          <label class="control-label ">Are you already working in your area of primary interest?
                                              <span class="required" aria-required="true"> * </span>
                                          </label>
                                          <div class="">
                                              <div class="input-icon ">
                                                  <i class="fa"></i>
                                                  <input type="text" class="form-control" name="interest"> </div>
                                          </div>
                                      </div>
                                      </div>
                              
                                      <div class="col-md-6">
                                          
                                        
                                          <div class="form-group  ">
                                          <label class="control-label ">Overall assessment of the event?
                                              <span class="required" aria-required="true"> * </span>
                                          </label>
                                          <div class="">
                                              <div class="input-icon ">
                                                  <i class="fa"></i>
                                                  <textarea class="form-control" rows="2" id="assessment" name='assessment'></textarea> </div>
                                          </div>
                                      </div>
                                      </div>   
                                      <div class="col-md-6">
                                          
                                        
                                          <div class="form-group  ">
                                          <label class="control-label ">Any additional comments?
                                              <span class="required" aria-required="true"> * </span>
                                          </label>
                                          <div class="">
                                              <div class="input-icon ">
                                                  <i class="fa"></i>
                                               
                                                  <textarea class="form-control" rows="2" id="comment" name='comment'></textarea>
                                                </div>
                                          </div>
                                      </div>
                                      </div>  
                                      <div class="col-md-12">
										<div class="form-group  ">
                                         <p> <label class="control-label ">Rate the relevance of the session on a scale of 1-5?
                                              <span class="required" aria-required="true"> * </span>
                                          </label></p>
                                          
                                          <div class="radio radio-yellow form-check-inline">
                                                    <input id="radiobg2" name="rating" type="radio" checked="checked">
                                                    <label for="radiobg2">
                                                        1
                                                    </label>
                                                </div>
                                                <div class="radio radio-yellow form-check-inline">
                                                    <input id="radiobg3" name="rating" type="radio" checked="checked">
                                                    <label for="radiobg3">
                                                        2
                                                    </label>
                                                </div>
                                                <div class="radio radio-yellow form-check-inline">
                                                    <input id="radiobg4" name="rating" type="radio" checked="checked">
                                                    <label for="radiobg4">
                                                        3
                                                    </label>
                                                </div>
                                                <div class="radio radio-yellow form-check-inline">
                                                    <input id="radiobg5" name="rating" type="radio" checked="checked">
                                                    <label for="radiobg5">
                                                        4
                                                    </label>
                                                </div>
                                                <div class="radio radio-yellow form-check-inline">
                                                    <input id="radiobg6" name="rating" type="radio" checked="checked">
                                                    <label for="radiobg6">
                                                        5
                                                    </label>
                                                </div>
                                      </div>
                                      </div>                   
                                            </div>
                                            </div>
                                        </form></div>

                                         <div class="form-group">
                                            <div class="offset-md-4 col-md-8">
                                                <button type="submit" class="btn btn-info m-r-20">Submit</button>
                                                <!--<button type="button" class="btn btn-default">Cancel</button>-->
                                            </div>
                                        </div>
                                    
                                </div>
                            </div>
                        </div>


</div>
</div>

<?php include 'common/footer_view.php'; ?>