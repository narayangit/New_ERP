<?php 

include 'common/header_view.php';
include 'common/sidebar_view.php';
?>
	<!-- start page content -->
    <div class="page-content-wrapper">
        <div class="page-content">
            <div class="page-bar">
                <div class="page-title-breadcrumb">
                    <div class=" pull-left">
                        <div class="page-title">Mentor/Guru's Details</div>
                    </div>
                    <ol class="breadcrumb page-breadcrumb pull-right">
                        <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="index.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                        </li>
                        <li class="active">Mentor/Guru's Details</li>
                    </ol>
                </div>
            </div>
           <!-- start widget -->
           <div class="row">
                <div class="col-md-4">
                    <div class="card card-box">
                        <div class="card-body no-padding ">
                        	<div class="doctor-profile">
                                    <img src="../assets/img/dp.jpg" class="doctor-pic" alt=""> 
                                <div class="profile-usertitle">
                                    <div class="doctor-name">Pooja Patel </div>
                                    <div class="name-center"> Science </div>
                                </div>
                                    <p>A-103, shyam gokul flats, Mahatma Road <br>Mumbai</p> 
                                    <div><p><i class="fa fa-phone"></i><a href="tel:(123)456-7890">  (123)456-7890</a></p> </div>
                                <div class="profile-userbuttons">
                                    <a href="professor_profile.html" class="btn btn-circle deepPink-bgcolor btn-sm">Join</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
              
            </div>
		</div>
	</div>
	<!-- end page container -->
	<?php include 'common/footer_view.php'; ?>
  </body>
</html>