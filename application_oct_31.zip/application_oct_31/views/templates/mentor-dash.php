<?php 

include 'common/header_view.php';
include 'common/sidebar_view.php';
?>
	<!-- start page content -->
    <div class="page-content-wrapper">
        <div class="page-content">
            <div class="page-bar">
                <div class="page-title-breadcrumb">
                    <div class=" pull-left">
                        <div class="page-title">Guru's Details</div>
                    </div>
                    <ol class="breadcrumb page-breadcrumb pull-right">
                        <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="#">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                        </li>
                        <li class="active">Guru's Details</li>
                    </ol>
                </div>
            </div>
            
          <a href="<?php echo BASEURL.'add-mentor';?>" class="btn btn-info deepPink-bgcolor btn-sm">Add Guru</a>
           <!-- start widget -->
           <div class="row">
     
			<?php foreach ($mentors as $mentor) { ?>
                <div class="col-md-4">
                    <div class="card card-box">
                        <div class="card-body no-padding ">
                        	<div class="doctor-profile">

                                    <img src="<?php echo ($mentor->picture_url)?$mentor->picture_url:base_url().'/assets/img/dp.jpg';?>" class="doctor-pic" alt=""> 
                                <div class="profile-usertitle">

                                    <div class="doctor-name"><?php echo $mentor->first_name; ?></div>
                                    <!-- <style>
                                        
						.rateyo svg{
width:20px;
height:20px;
						} 
						</style>
						<div class="rateyo"></div> -->
                                    <div class="name-center"> <?php echo $mentor->technology; ?></div>
									<div class="name-center"> <?php echo $mentor->position; ?></div>
									<div class="name-center"> <?php echo $mentor->company; ?></div>
                                    <div class="name-center"> <?php echo $mentor->email; ?></div>
                                </div>
                                    <p><?php echo $mentor->locale; ?></p> 
                                    <div><p><i class="fa fa-phone"></i><a href="javascript:void(0);"><?php echo $mentor->contact; ?></a></p> </div>
                                <div class="profile-userbuttons">
                                    <a href="<?php echo BASEURL.'edit-mentor/'. $mentor->id;?>" class="btn btn-success deepPink-bgcolor btn-sm" title="Edit Details"><i class="fa fa-pencil"></i></a>
									
									<a href="<?php echo $mentor->profile_url ?>" target='_blank' class="btn btn-success deepPink-bgcolor btn-sm" title="Edit Details">View</a>
	
									<a href="<?php echo BASEURL.'deactive-mentor/'. $mentor->id;?>" class="btn <?php echo ($mentor->active == '1')?'btn-danger':'btn-success';?> deepPink-bgcolor btn-sm" title="Active / Deactive"><?php echo ($mentor->active == '1')?'Deactive':'Active';?></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
               <?php  } ?>

            </div>
		</div>
	</div>
    <!-- end page container -->

    <?php include 'common/footer_view.php'; ?>
    <script>

$(function () {

  var rating = 1.6;

  $(".counter").text(rating);

  $("#rateYo1").on("rateyo.init", function () { console.log("rateyo.init"); });

  $("#rateYo1").rateYo({
    rating: rating,
    numStars: 5,
    precision: 2,
    starWidth: "64px",
    spacing: "5px",
rtl: true,
    multiColor: {

      startColor: "#000000",
      endColor  : "#ffffff"
    },
    onInit: function () {

      console.log("On Init");
    },
    onSet: function () {

      console.log("On Set");
    }
  }).on("rateyo.set", function () { console.log("rateyo.set"); })
    .on("rateyo.change", function () { console.log("rateyo.change"); });

  $(".rateyo").rateYo();

  $(".rateyo-readonly-widg").rateYo({

    rating: rating,
    numStars: 5,
    precision: 2,
    minValue: 1,
    maxValue: 5
  }).on("rateyo.change", function (e, data) {
  
    console.log(data.rating);
  });
});
</script>

  </body>
</html>