<?php 
//print_r($student_details);die;
include 'common/header_view.php';
include 'common/sidebar_view.php';
?>
			<!-- start page content -->
            <div class="page-content-wrapper">
                <div class="page-content">
                    <div class="page-bar">
                        <div class="page-title-breadcrumb">
                            <div class=" pull-left">
                                <div class="page-title">Dashboard</div>
                            </div>
                            <ol class="breadcrumb page-breadcrumb pull-right">
                                <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="<?php echo BASEURL;?>">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                                </li>
                                <li class="active">Dashboard</li>
                            </ol>
                        </div>
                    </div>
                   <!-- start widget -->

					<div class="state-overview">
              <div class="row">

              <?php 
              $student_id = $this->session->userdata('id');
              foreach ($student_details as $key => $events) { ?>

                <div class="col-xl-4 col-md-6 col-12">
                  <div class="info-box bg-b-blue">
                      <!-- <span class="info-box-icon push-bottom"> <img src="../assets/img/dp.jpg" class="img-circle " alt="User Image"></span> -->
                        <div class="info-box-content">
                          <span class="info-box-text"><?php echo $events->event_name;?></span>
                          <div class="info-box-text"><!-- Thursday, october04,2018 --><?php $events->mentor_id;?></div>
                            <div class="info-box-text"><!--  10:00AM To 12.00PM  --><?php echo $events->city;?></div>
                            <div class="info-box-text"><!--  10:00AM To 12.00PM  -->Start : <?php echo $events->start_date;?> End: <?php echo $events->end_date;?></div>
                            <!-- <span class="student-info btn-success btn-circle">Total 3</span> -->
                                <span class="btn btn-primary btn-circle" onClick="applyforevent(this,'<?=$events->id;?>','<?=$events->mentor_id;?>');"><?php echo (has_applied($student_id,$events->id)) ? 'Applied': 'Apply';?> </span>
                        </div>
                    </div>
                </div>

              <?php } ?>

						  </div><!-- end row -->
					</div><!-- end state-overview -->
					
					<!-- end widget -->
             
          <!-- <div class="row">
              <div class="col-md-12">
                  <div class="card card-topline-red">
                      <div class="card-head">
                          <header>Attendance Submission</header>
                          <div class="tools">
                              <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
                            <a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
                            <a class="t-close btn-color fa fa-times" href="javascript:;"></a>
                          </div>
                      </div>
                    <form action="" method="post">
                      <div class="card-body ">
                      <div class="row">
                            <div class="col-md-12 col-sm-12 col-12">
                                <div class="btn-group">
                                <button type="button" class="btn btn-round btn-primary">Submit</button>
                                </div>
                            </div>
                          </div>
                          <div class="table-scrollable">
                          <table class="table table-striped table-bordered table-hover table-checkable order-column" style="width: 100%" id="example4">
                              <thead>
                                  <tr>
                                      <th> Attendance </th>
                                      <th> Reffrence Id </th>
                                      <th> Name </th>
                                      <th> Email </th>
                                      <th> Address </th>
                                      <th> City </th>
                                      <th> Contact </th>
                                  </tr>
                              </thead>
                              <tbody>
                                  <tr class="odd gradeX">
                                      <td>
                                          <label class="rt-chkbox rt-chkbox-single rt-chkbox-outline">
                                              <input type="checkbox" class="checkboxes" value="1" />
                                              <span></span>
                                          </label>
                                      </td>
                                      <td> 201152 </td>
                                      <td>
                                          Jay
                                      </td>
                                      <td>
                                      <a href="mailto:shuxer@gmail.com"> Jay@gmail.com </a>
                                      </td>
                                      <td>34, Udyog Vihar Phase IV, Sector 19, Gurugram, Haryana 122008  </td>
                                      <td >
                                      Gurugram
                                      </td>
                                      <td >
                                      7899999945
                                      </td>
                                  </tr>
                              </tbody>
                          </table>
                          </div>
                      </div>
                    </from>
                  </div>
              </div>
          </div> -->

        </div>
        <!-- end page container -->
		<?php include 'common/footer_view.php'; ?>

    <script type="text/javascript">
      function applyforevent(obj, eid,mid) {
            $.ajax({
                url: '<?php echo BASEURL . "student/applyforevent";?>',
                method :'post',
                data: {'event_id': eid,'mentor_id': mid},
                success : function(data){
                  console.log(data);
                  if(data == 1){
                      $(obj).text('Applied');
                    }
                  }
            });
        }
    </script>
    
  </body>
</html>