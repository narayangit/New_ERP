<?php 

include 'common/header_view.php';
include 'common/sidebar_view.php';
?>
			<!-- start page content -->
            <div class="page-content-wrapper">
                <div class="page-content">
                    <div class="page-bar">
                        <div class="page-title-breadcrumb">
                            <div class=" pull-left">
                                <div class="page-title">Dashboard</div>
                            </div>
                            <ol class="breadcrumb page-breadcrumb pull-right">
                                <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="<?php echo BASEURL;?>">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                                </li>
                                <li class="active">Dashboard</li>
                            </ol>
                        </div>
                    </div>
                   <!-- start widget -->
					<div class="state-overview">
              <div class="row">

              <?php foreach ($get_events_mentor as $events) {
                $total_students = (int) count_applied_students($events->id);
              ?>

                <div class="col-xl-4 col-md-6 col-12" onclick="get_event_attendance('<?=$events->id;?>','<?=$total_students;?>');" >
                  <div class="info-box bg-b-blue">
                      <!-- <span class="info-box-icon push-bottom"> <img src="../assets/img/dp.jpg" class="img-circle " alt="User Image"></span> -->
                      <div class="info-box-content">
                        <span class="info-box-text"><?=$events->event_name;?></span>
                        <div class="info-box-text"><?=$events->city;?></div>
                          <div class="info-box-text">Start: <?=date('d-F-Y h:i A', strtotime($events->start_date));?>End: <?=date('d-F-Y h:i A', strtotime($events->end_date));?></div>
                          <span class="student-info btn-success btn-circle"><?php echo $total_students; ?></span>
                      </div>
                    </div>
                </div>

              <?php } ?>

						  </div><!-- end row -->
					</div><!-- end state-overview -->
					
					<!-- end widget -->
             
          <div class="row">
              <div class="col-md-12">
                  <div class="card card-topline-red">
                      <div class="card-head">
                          <header>Attendance Submission</header>
                          <div class="tools">
                              <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
                            <a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
                            <a class="t-close btn-color fa fa-times" href="javascript:;"></a>
                          </div>
                      </div>
                    <form action="#" method="post">
                      <div class="card-body ">
                      <div class="row">
                            <div class="col-md-12 col-sm-12 col-12">
                                <div class="btn-group">
                                <button type="button" class="btn btn-round btn-primary" id="button" onClick="check_attendance();" disabled="disabled">Submit</button>
                                </div>
                            </div>
                          </div>
                          <div class="table-scrollable">
                          <table class="table table-striped table-bordered table-hover table-checkable order-column" style="width: 100%" id="example4">
                              <thead>
                                  <tr>
                                      <th> Attendance </th>
                                      <th> Reffrence Id </th>
                                      <th> Name </th>
                                      <th> Technology </th>
                                      <th> Email </th>
                                      <th> Address </th>
                                      <th> City </th>
                                      <th> Contact </th>
                                  </tr>
                              </thead>
                              <tbody class="append_data">

                              </tbody>
                              
                          </table>
                          
                          </div>
                          
                      </div>

                    </from>

                  </div>
                  
              </div>
              
          </div>

        </div>
        <!-- end page container -->
		<?php include 'common/footer_view.php'; ?>
    <script type="text/javascript">

      function get_event_attendance(eid,total_students)
      {
        $.ajax({
            url: '<?php echo BASEURL . "mentor/get_event_attendance";?>',
            method :'post',
            data: {'event_id': eid},
            success : function(data){
              if(total_students == 0){
                $("tbody.append_data").html('');
              }else{
                $("tbody.append_data").html(data);

                $('input[type=checkbox]').on('click',function(){
                  $("input:checkbox").each(function(){
                    var len = $("input:checked").length;
                    //if($(this).is(":checked")){
                    if(len > 0){
                      console.log($("input:checked").length);
                      $("#button").prop('disabled',false);
                    }else{
                      $("#button").prop('disabled',true);
                      //$("#button").attr('onclick','check_attendance();');
                    }
                  });
                });
              }
            } // End success
        });
      }

      function check_attendance()
      {
        obj = new Array();
        $("input:checkbox").each(function(){
          if($(this).is(":checked")){
            obj.push({'aid': $(this).attr("aid"),'eid': $(this).attr("eid"),'sid': $(this).attr("sid"),'apply_status': $(this).attr("sts")});
          }
        });
        console.log(obj);
        if( obj.length > 0 ){
          $.ajax({
            url: '<?php echo BASEURL . "mentor/check_attendance";?>',
            method : 'post',
            data: {'data': obj},
            success : function(data){
              location.reload();
              console.log(data);
            }
          });
        }
    } //End function

    </script>
  </body>
</html>