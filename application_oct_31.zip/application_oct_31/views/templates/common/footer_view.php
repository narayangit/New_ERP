<div class="page-footer">
            <div class="page-footer-inner"> 2017 &copy; All Rights Reserved by 
            <a href="https://www.mattsenkumar.com/" target="_top" class="makerCss">MattsenKumar LLC.</a>
            </div>
            <div class="scroll-to-top">
                <i class="icon-arrow-up"></i>
            </div>
        </div>
        <!-- end footer -->
    </div>
    <!-- start js include path -->
    <script src="<?php echo base_url('assets/plugins/jquery/jquery.min.js');?>" ></script>
    <script src="<?php echo base_url('assets/plugins/popper/popper.js');?>" ></script>
    <script src="<?php echo base_url('assets/plugins/jquery-blockui/jquery.blockui.min.js');?>" ></script>
	<script src="<?php echo base_url('assets/plugins/jquery-slimscroll/jquery.slimscroll.js');?>"></script>
    <script src="<?php echo base_url('assets/plugins/jquery-ui/jquery-ui.min.js');?>" ></script>

    <!-- bootstrap -->
    <script src="<?php echo base_url('assets/plugins/bootstrap/js/bootstrap.min.js');?>" ></script>
    <script src="<?php echo base_url('assets/plugins/bootstrap-switch/js/bootstrap-switch.min.js');?>" ></script>
    <script src="<?php echo base_url('assets/plugins/sparkline/jquery.sparkline.js');?>" ></script>
	<script src="<?php echo base_url('assets/js/pages/sparkline/sparkline-data.js');?>" ></script>
 
    <!-- Common js-->
	<script src="<?php echo base_url('assets/js/app.js');?>" ></script>
    <script src="<?php echo base_url('assets/js/layout.js');?>" ></script>
    <script src="<?php echo base_url('assets/js/theme-color.js');?>" ></script>
   
    <!-- material -->
    <script src="<?php echo base_url('assets/plugins/material/material.min.js');?>"></script>
    <!-- chart js -->
    <script src="<?php echo base_url('assets/plugins/chart-js/Chart.bundle.js');?>" ></script>
    <script src="<?php echo base_url('assets/plugins/chart-js/utils.js');?>" ></script>
    <script src="<?php echo base_url('assets/js/pages/chart/chartjs/home-data.js');?>" ></script>
    <script src="<?php echo base_url('assets/js/pages/chart/chartjs/chartjs-data.js');?>" ></script>
    <!-- summernote -->
    <script src="<?php echo base_url('assets/plugins/summernote/summernote.js');?>" ></script>
    <script src="<?php echo base_url('assets/js/pages/summernote/summernote-data.js');?>" ></script>
   
   <!-- calendar -->
   <script src="<?php echo base_url('assets/plugins/moment/moment.min.js');?>" ></script>
    <script src="<?php echo base_url('assets/plugins/fullcalendar/fullcalendar.min.js');?>" ></script>
    <script src="<?php echo base_url('assets/js/pages/calendar/calendar.min.js');?>" ></script>
     <!-- data tables -->
     <script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js');?>" ></script>
 	<script src="<?php echo base_url('assets/plugins/datatables/plugins/bootstrap/dataTables.bootstrap4.min.js');?>" ></script>
    <script src="<?php echo base_url('assets/js/pages/table/table_data.js');?>" ></script>
    <script src="<?php echo base_url('assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js');?>" ></script>
    <script src="<?php echo base_url('assets/plugins/jquery-validation/js/jquery.validate.min.js');?>" ></script>
    <script src="<?php echo base_url('assets/plugins/jquery-validation/js/additional-methods.min.js');?>" ></script>
    <script src="<?php echo base_url('assets/js/pages/validation/form-validation.js');?>" ></script>
    <!-- date picker -->
    <script src="<?php echo base_url('assets/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.js');?>"  charset="UTF-8"></script>
    <script src="<?php echo base_url('assets/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker-init.js');?>"  charset="UTF-8"></script>
    <script src="<?php echo base_url('assets/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js');?>"  charset="UTF-8"></script>
    <script src="<?php echo base_url('assets/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker-init.js');?>"  charset="UTF-8"></script>
    <script src="<?php echo base_url('assets/js/pages/material-select/getmdl-select.js');?>"  charset="UTF-8"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar-scheduler/1.9.4/scheduler.min.js"  charset="UTF-8"></script>
    <script src="<?php echo base_url('assets/js/jquery.rateyo.min.js');?>" ></script>
    <!-- end js include path -->
 <!--  </body>
</html> -->