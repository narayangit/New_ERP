<?php 

include 'common/header_view.php';
include 'common/sidebar_view.php';
?>
 
			<!-- start page content -->
            <div class="page-content-wrapper">
                <div class="page-content">
                    <div class="page-bar">
                        <div class="page-title-breadcrumb">
                            <div class=" pull-left">
                                <div class="page-title">Mentor/Ask Question</div>
                            </div>
                            <ol class="breadcrumb page-breadcrumb pull-right">
                                <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="index.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                                </li>
                                <li class="active">Mentor/Ask Question</li>
                            </ol>
                        </div>
                    </div>
                   <!-- start widget -->
                   <div class="row">
					        
                   <div class="col-lg-8 col-md-8 col-sm-12 col-12">
                        	<div class="card  card-box">
                                <div class="card-head">
                                    <header>Ask Question</header>
                                    <button id = "chatlist" 
			                           class = "mdl-button mdl-js-button mdl-button--icon pull-right" 
			                           data-upgraded = ",MaterialButton">
			                           <i class = "material-icons">more_vert</i>
			                        </button>
			                        <ul class = "mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect"
			                           data-mdl-for = "chatlist">
			                           <li class = "mdl-menu__item"><i class="material-icons">assistant_photo</i>Action</li>
			                           <li class = "mdl-menu__item"><i class="material-icons">print</i>Another action</li>
			                           <li class = "mdl-menu__item"><i class="material-icons">favorite</i>Something else here</li>
			                        </ul>
                                </div>
                                <div class="card-body no-padding height-9">
                                    <div class="row">
                                        <ul class="chat nice-chat small-slimscroll-style">
                                            <li class="in"><img src="assets/img/prof/prof1.jpg" class="avatar" alt="">
                                                <div class="message">
                                                    <span class="arrow"></span> <a class="name" href="#">Jone
														Doe</a> <span class="datetime">at Mar 12, 2014 6:12</span> <span class="body"> Lorem ipsum dolor sit amet,
														consectetuer adipiscing elit </span>
                                                </div>
                                            </li>
                                            <li class="out"><img src="assets/img/dp.jpg" class="avatar" alt="">
                                                <div class="message">
                                                    <span class="arrow"></span> <a class="name" href="#">Kiran
														Patel</a> <span class="datetime">at Mar 12, 2014 6:13</span> <span class="body"> sed diam nonummy nibh euismod
														tincidunt ut </span>
                                                </div>
                                            </li>
                                            <li class="in"><img src="assets/img/prof/prof1.jpg" class="avatar" alt="">
                                                <div class="message">
                                                    <span class="arrow"></span> <a class="name" href="#">Jone
														Doe</a> <span class="datetime">at Mar 12, 2014 6:12</span> <span class="body"> aoreet dolore magna aliquam erat
														volutpat. </span>
                                                </div>
                                            </li>
                                            <li class="out"><img src="assets/img/dp.jpg" class="avatar" alt="">
                                                <div class="message">
                                                    <span class="arrow"></span> <a class="name" href="#">Kiran
														Patel</a> <span class="datetime">at Mar 12, 2014 6:13</span> <span class="body"> sed diam nonummy nibh euismod
														tincidunt ut </span>
                                                </div>
                                            </li>
                                            <li class="in"><img src="assets/img/prof/prof1.jpg" class="avatar" alt="">
                                                <div class="message">
                                                    <span class="arrow"></span> <a class="name" href="#">Jone
														Doe</a> <span class="datetime">at Mar 12, 2014 6:12</span> <span class="body"> aoreet dolore magna aliquam erat
														volutpat. </span>
                                                </div>
                                            </li>
                                            <li class="out"><img src="assets/img/dp.jpg" class="avatar" alt="">
                                                <div class="message">
                                                    <span class="arrow"></span> <a class="name" href="#">Kiran
														Patel</a> <span class="datetime">at Mar 12, 2014 6:13</span> <span class="body"> sed diam nonummy nibh </span>
                                                </div>
                                            </li>
                                        </ul>
                                        <div class="box-footer chat-box-submit">
						                <form action="#" method="post">
						                  <div class="input-group">
						                    <input type="text" name="message" placeholder="Enter your ToDo List" class="form-control">
						                    <span class="input-group-btn">
						                    <button type="submit" class="btn btn-warning btn-flat"><i class="fa fa-arrow-right"></i></button>
						                    </span> </div>
						                </form>
					               </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-12 col-12">
                             <div class="card card-box">
                                 <div class="card-head">
                                     <header>Guru's List</header>
                                     <button id = "prfList" 
			                           class = "mdl-button mdl-js-button mdl-button--icon pull-right" 
			                           data-upgraded = ",MaterialButton">
			                           <i class = "material-icons">more_vert</i>
			                        </button>
			                        <ul class = "mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect"
			                           data-mdl-for = "prfList">
			                           <li class = "mdl-menu__item"><i class="material-icons">assistant_photo</i>Action</li>
			                           <li class = "mdl-menu__item"><i class="material-icons">print</i>Another action</li>
			                           <li class = "mdl-menu__item"><i class="material-icons">favorite</i>Something else here</li>
			                        </ul>
                                 </div>
                                 <div class="card-body ">
                                 <div class="row">
                                        <ul class="docListWindow small-slimscroll-style">
                                            <li>
                                                <div class="prog-avatar">
                                                    <img src="assets/img/prof/prof1.jpg" alt="" width="40" height="40">
                                                </div>
                                                <div class="details">
                                                    <div class="title">
                                                        <a href="#">Rajesh</a> -(M.Com, PHD)
                                                    </div>
                                                        <div>
                                                            <span class="clsAvailable">Available</span>
                                                        </div>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="prog-avatar">
                                                    <img src="assets/img/prof/prof2.jpg" alt="" width="40" height="40">
                                                </div>
                                                <div class="details">
                                                    <div class="title">
                                                        <a href="#">Sarah Smith</a> -(M.A., B.Ed)
                                                    </div>
													<div>
														<span class="clsAvailable">Available</span>
													</div>
												</div>
                                            </li>
                                            <li>
                                                <div class="prog-avatar">
                                                    <img src="assets/img/prof/prof3.jpg" alt="" width="40" height="40">
                                                </div>
                                                <div class="details">
                                                    <div class="title">
                                                        <a href="#">John Deo</a> - (B.C.A., M.C.A.)
                                                    </div>
													<div>
														<span class="clsNotAvailable">Not Available</span>
													</div>
												</div>
                                            </li>
                                            <li>
                                                <div class="prog-avatar">
                                                    <img src="assets/img/prof/prof4.jpg" alt="" width="40" height="40">
                                                </div>
                                                <div class="details">
                                                    <div class="title">
                                                        <a href="#">Jay Soni</a> - (B.E., M.E.)
                                                    </div>
													<div>
														<span class="clsOnLeave">On Leave</span>
													</div>
												</div>
                                            </li>
                                            <li>
                                                <div class="prog-avatar">
                                                    <img src="assets/img/prof/prof5.jpg" alt="" width="40" height="40">
                                                </div>
                                                <div class="details">
                                                    <div class="title">
                                                        <a href="#">Jacob Ryan</a> - (M.Phil)
                                                    </div>
													<div>
														<span class="clsNotAvailable">Not Available</span>
													</div>
												</div>
                                            </li>
                                            <li>
                                                <div class="prog-avatar">
                                                    <img src="assets/img/prof/prof6.jpg" alt="" width="40" height="40">
                                                </div>
                                                <div class="details">
                                                    <div class="title">
                                                        <a href="#">Megha Trivedi</a> - (M.S.W, PHD)
                                                    </div>
													<div>
														<span class="clsAvailable">Available</span>
													</div>
												</div>
                                            </li>
                                            <li>
                                                <div class="prog-avatar">
                                                    <img src="assets/img/prof/prof2.jpg" alt="" width="40" height="40">
                                                </div>
                                                <div class="details">
                                                    <div class="title">
                                                        <a href="#">Sarah Smith</a> -(B.S.C, M.S.C.)
                                                    </div>
													<div>
														<span class="clsAvailable">Available</span>
													</div>
												</div>
                                            </li>
                                            <li>
                                                <div class="prog-avatar">
                                                    <img src="assets/img/prof/prof3.jpg" alt="" width="40" height="40">
                                                </div>
                                                <div class="details">
                                                    <div class="title">
                                                        <a href="#">John Deo</a> - (B.E., M.E.)
                                                    </div>
													<div>
														<span class="clsNotAvailable">Not Available</span>
													</div>
												</div>
                                            </li>
                                            <li>
                                                <div class="prog-avatar">
                                                    <img src="assets/img/prof/prof4.jpg" alt="" width="40" height="40">
                                                </div>
                                                <div class="details">
                                                    <div class="title">
                                                        <a href="#">Jay Soni</a> - (B.C.A., M.C.A.)
                                                    </div>
													<div>
														<span class="clsOnLeave">On Leave</span>
													</div>
												</div>
                                            </li>
                                        </ul>
                                        <div class="full-width text-center p-t-10" >
												<a href="#" class="btn purple btn-outline btn-circle margin-0">View All</a>
											</div>
                                    </div>
                                 </div>
                             </div>
						</div>


					     
                    					</div>
					
					<!-- end widget -->

			       
        </div>
</div>
        <!-- end page container -->
		<?php include 'common/footer_view.php'; ?>