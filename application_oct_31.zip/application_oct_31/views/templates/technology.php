<?php
include 'common/header_view.php';
include 'common/sidebar_view.php';
 ?>

			<!-- start page content -->
            <div class="page-content-wrapper">
                <div class="page-content">
				
					<!-- start by sonu -->
						<div class="row">
                      <div class="col-md-12">
                        <div class="" id="line-parent">
  									      <div class="panel-group accordion" id="accordion3">
                            <div class="panel panel-default" style="border: 0px solid transparent;">
                              <div class="panel-heading panel-heading-blue" id='tech-accordion' style="border-top-left-radius: 0px;border-top-right-radius: 0px;background: #188ae2;">
												        <a class="accordion-toggle accordion-toggle-styled collapsed icon-cal" data-toggle="collapse" data-parent="#accordion3" href="#collapse_3_2">
                                  <h4 class="panel-title calender-heading ">Add Technology <i class="fa fa-plus plus-custom"></i></h4>
                                </a>
                              </div>
                  <div id="collapse_3_2" class="panel-collapse collapse">
                    <div class="panel-body">           
                      <div class="row">
                        <div class="col-md-12 col-sm-12">
                            <div class="card card-box">
                               
                                <div class="card-body" id="bar-parent2">
                                    <?php 
                                      $attributes = array("class" => "form-inline","id" =>"form_sample_2","onsubmit" =>"submit.disabled=true; submit.value ='Please wait...'; return true;");
                                      echo form_open_multipart('index.php/technologies',$attributes);
                                    ?>
									  <div class="form-group">
										<label for="tech-name">Technology Name:- &nbsp</label>
										<input type="text" class="form-control" id="tech-name" name='tech_name' required>
									  </div>
									  &nbsp
									  <!--<div class="form-group">
										<label for="tech-logo">Technology Logo:- &nbsp</label>
										<input type="file" class="form-control" id="tech-logo" name='tech_logo'>
									  </div>-->
									  &nbsp&nbsp&nbsp&nbsp
									  <button type="submit" class="btn btn-default">Submit</button>
									</form>
									
                                </div>
                            </div>
                        </div>                         
                      </div>
                  </div>
              </div>
            </div>
          </div>
        </div>
      </div>
   </div>
   <!-- end by sonu -->
                  <div class="row">
                        <div class="col-md-12">
                            <div class="card card-topline-red">
                                <div class="card-head">
                                    <header>Technology</header>
                                    <div class="tools">
                                        <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
	                                    <a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
	                                    <a class="t-close btn-color fa fa-times" href="javascript:;"></a>
                                    </div>
                                </div>
                                <div class="card-body ">
                                    <div class="table-scrollable">
                                    <table class="table table-striped table-bordered table-hover table-checkable order-column" style="width: 100%" id="example4">
                                        <thead>
                                            <tr>
                                                <th> Technology Name </th>
                                                <th> Users</th>
												<th> Action </th>
                                              
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                            if(count($technologies)>0){
												foreach ($technologies as $key => $tech) { 
													echo "<tr>";
														echo "<td>".$tech->name."</td>";
														echo "<td>".$tech->users."</td>"; ?>
														<td>
														<a href='javascript:void(0)' onclick='edit_tech("<?= $tech->name ?>")' > Edit</a>
														/<a href='javascript:void(0)' onclick='del_tech("<?= $tech->id ?>")' > delete</a></td>
												<?php	echo "</tr>";
												}
											}
                                            ?>
                                        </tbody>
                                    </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
        </div>

</div>
</div>
 <?php
include 'common/footer_view.php';
 ?>
  <script>
	
	function edit_tech(value){
		console.log(value);
		$('#tech-name').val(value);
		$('.icon-cal').click();
	}
	
	function del_tech(tid){
		$.ajax({
			url: '<?php echo BASEURL . "del-technology";?>',
			method :'post',
			data: {'tech_id': tid},
			success : function(data){
				var res = JSON.parse(data);
				if(res.msg == 'success'){
					$("#example4").load(window.location + " #example4");
				}
			}
		});
	}
  </script>

