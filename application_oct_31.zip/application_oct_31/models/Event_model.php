<?php
class Event_model extends CI_Model
{
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
		$this->load->database();
    }
	function add_event($post_data)
    {
        $this->db->insert('nscm_events', $post_data);
		return true;
    }
	/* Purpose : get event details */
	function get_events()
    {
		$this->db->select("*")->from("nscm_events");
		$result = $this->db->get();
		return $result->result_object();
	}
	/* Purpose : get latest event details */
	function get_events_mentor()
    {
    	$mentor_id = $this->session->userdata('id');
		
		$this->db->select("*")->from("nscm_events")->where("mentor_id = '".$mentor_id."'")->where("DATE(start_date) >= DATE(NOW())");

		/*if($eventdays === 'today'){
			//$codition = "DATE(start_date) = DATE(NOW())";
            $codition = array('mentor_id' => $mentor_id,'DATE(start_date) =' => DATE(NOW()));
        }elseif($eventdays === 'past'){
            $codition = array('mentor_id' => $mentor_id,'DATE(start_date) <=' => DATE(NOW()));
        }elseif($eventdays === 'upcoming'){
            $codition = array('mentor_id' => $mentor_id,'DATE(start_date) >' => DATE(NOW()));
        }
		$this->db->select("*")->from("nscm_events")->where($codition)->order_by("start_date","ASC");*/

		$result = $this->db->get();
		return $result->result_object();
	}
	/* Purpose : get latest event details */
	function get_events_all()
    {
    	$user_id = $this->session->userdata('id');
    	$usertype = $this->session->userdata('usertype');
		
		$this->db->select("*")->from("nscm_events")->where("mentor_id = '".$user_id."'")->where("DATE(start_date) >= DATE(NOW())");

		/*if($eventdays === 'today'){
			//$codition = "DATE(start_date) = DATE(NOW())";
            $codition = array('mentor_id' => $user_id,'DATE(start_date) =' => DATE(NOW()));
        }elseif($eventdays === 'past'){
            $codition = array('mentor_id' => $user_id,'DATE(start_date) <=' => DATE(NOW()));
        }elseif($eventdays === 'upcoming'){
            $codition = array('mentor_id' => $user_id,'DATE(start_date) >' => DATE(NOW()));
        }
		$this->db->select("*")->from("nscm_events")->where($codition)->order_by("start_date","ASC");*/

		$result = $this->db->get();
		return $result->result_object();
	}

	/* Purpose : Event list for student*/
    function get_events_student()
    {
		$this->db->select("*")->from("nscm_events")->where("start_date >= NOW()")->order_by("start_date","ASC");
		$result = $this->db->get();
		return $result->result_object();
	}
	/* purpose of show events in calendar. */
	function events_calendar()
	{    
		$this->db->select("e.event_name,e.mentor_id,m.name,e.start_date,e.end_date,e.city,e.address")->from("nscm_events AS e")->join('nscm_mentors AS m','m.id = e.id');

		$result = $this->db->get();
		$event = $result->result_array();
		$json_array = $events =[];
		
		foreach ($result->result_array() as $key => $event) {
				$events['title'] = $event["event_name"] ." ". $event["name"] ." ". $event["city"] ." ". $event["address"];
				$events['start'] =  $event["start_date"];
				$events['end'] =  $event["end_date"];
				$events['backgroundColor'] = $this->random_color();
				array_push($json_array, $events);
			}
			
		return json_encode($json_array);
	}
	
	function events_calendar_guru($mentor_id=0)
	{    
		$this->db->select("e.event_name,e.mentor_id,m.name,e.start_date,e.end_date,e.city,e.address")->from("nscm_events AS e")->join('nscm_mentors AS m','m.id = e.mentor_id')->where('e.mentor_id',$mentor_id);

		$result = $this->db->get();
		$event = $result->result_array();
		$json_array = $events =[];
		
		foreach ($result->result_array() as $key => $event) {
				$events['title'] = $event["event_name"] ." ". $event["name"] ." ". $event["city"] ." ". $event["address"];
				$events['start'] =  $event["start_date"];
				$events['end'] =  $event["end_date"];
				$events['backgroundColor'] = $this->random_color();
				array_push($json_array, $events);
			}
			
		return json_encode($json_array);
	}

	function events_calendar_user($user_id=0)
	{    
		$this->db->select("e.event_name,e.start_date,e.end_date,e.city,e.address,m.name")->from("nscm_events AS e")->join('nscm_attendance AS a','a.event_id = e.id')->join('nscm_mentors AS m','m.id = e.mentor_id')->where('a.student_id',$user_id);

		$result = $this->db->get();
		$event = $result->result_array();
		$json_array = $events =[];
		
		foreach ($result->result_array() as $key => $event) {
				$events['title'] = $event["event_name"] ." ". $event["name"] ." ". $event["city"] ." ". $event["address"];
				$events['start'] =  $event["start_date"];
				$events['end'] =  $event["end_date"];
				$events['backgroundColor'] = $this->random_color();
				array_push($json_array, $events);
			}
			
		return json_encode($json_array);
	}
	
	function get_events_by_date($date){
		$this->db->select("e.id,e.event_name,e.mentor_id,m.name,e.start_date,e.end_date,e.city,e.address")->from("nscm_events AS e")->join('nscm_mentors AS m','m.id = e.id')->where("'$date' BETWEEN DATE(start_date) AND DATE(end_date)");

		$result = $this->db->get();
		$event = $result->result_array();
		$json_array = $events =[];
		
		foreach ($result->result_array() as $key => $event) {
				$events['id'] = $event['id'];
				$events['title'] = $event["event_name"] ." ". $event["name"] ." ". $event["city"] ." ". $event["address"];
				$events['start'] =  $event["start_date"];
				$events['end'] =  $event["end_date"];
				$events['backgroundColor'] = $this->random_color();
				array_push($json_array, $events);
			}
			
		return json_encode($json_array);
	}
	
	function get_events_by_date_for_mentor($date,$mentor_id){
		$this->db->select("e.id,e.event_name,e.mentor_id,m.name,e.start_date,e.end_date,e.city,e.address")->from("nscm_events AS e")->join('nscm_mentors AS m','m.id = e.id')->where("'$date' BETWEEN DATE(start_date) AND DATE(end_date)")->where('e.mentor-id',$mentor_id);

		$result = $this->db->get();
		$event = $result->result_array();
		$json_array = $events =[];
		
		foreach ($result->result_array() as $key => $event) {
				$events['id'] = $event['id'];
				$events['title'] = $event["event_name"] ." ". $event["name"] ." ". $event["city"] ." ". $event["address"];
				$events['start'] =  $event["start_date"];
				$events['end'] =  $event["end_date"];
				$events['backgroundColor'] = $this->random_color();
				array_push($json_array, $events);
			}
			
		return json_encode($json_array);
	}

	function RGB() {
	    return str_pad( dechex( mt_rand( 0, 255 ) ), 2, '0', STR_PAD_LEFT);
	}

	function random_color() {
	    return "#" . $this->RGB() . $this->RGB() . $this->RGB();
	}

}
?>