<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_model extends CI_Model
{
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
		$this->load->database();
    }
	function add_admin($post_data)
    {
        $this->db->insert('nscm_events', $post_data);
		return true;
    }
}
?>