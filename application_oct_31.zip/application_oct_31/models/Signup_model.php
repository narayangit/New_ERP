<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Signup_model extends CI_Model
{
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
		$this->load->database();
    }
	function signup($post_data)
    {
        $this->db->insert('nscm_login', $post_data);
		return true;
    }
}
?>