<?php
class Student_model extends CI_Model
{
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
		$this->load->database();
    }

	/* Purpose : get event details */
	function get_details()
    {
		$this->db->select("*")->from("nscm_events");
		$result = $this->db->get();
		return $result->result_object();
	}
	/* purpose : get user details for profile */
	function user_profile($user_id)
    {   
		$this->db->select("*")->from("nscm_students")->where("id",$user_id);
		$result = $this->db->get();
		return $result->row_object();
	}
	/* Purpose : Event list in technology wise*/
    function student_events($eventdays = 'past')
    {
        $student_id = $this->session->userdata('id');
        if($eventdays == 'past'){
            $codition = "DATE(e.start_date) <= DATE(NOW()) AND s.id = '".$student_id."'";
        }elseif($eventdays == 'upcoming'){
            $codition = "DATE(e.start_date) > DATE(NOW()) AND s.id = '".$student_id."'";
        }
        
		$this->db->select("e.*,s.id sid,s.technology")->from("nscm_events e")->join("nscm_students s","s.technology = e.technology")->where($codition)->order_by("e.start_date","ASC");
		$result = $this->db->get();
        
		return $result->result_object();
	}
    /* purpose of check student applied event or not */
    function applyforevent($post = array())
    {
        $student_id = $this->session->userdata('id');
        $post_data = [
            'event_id' => $post['event_id'],
            'student_id' => $student_id,
            'mentor_id' => $post['mentor_id'],
            'apply_status' => 'Applied'
        ];
        
        $this->db->select("*")->from("nscm_attendance")->where("event_id = '".$post['event_id']."'")->where("student_id = '".$student_id."'");
        $result = $this->db->get()->result_object();
        if (count($result) > 0){
            return 0;
        }else{
            $result = $this->db->insert('nscm_attendance', $post_data);
            if($result){
                return 1;
            }
        }
    }
    /* purpose of student feedback (update and view) */
	function student_feedback($post = array(),$event_id = 0)
    {
        $student_id = $this->session->userdata('id');

        if (is_array($post) && count($post) > 0 ){
            $event_id = $post['event_id'];
        }
        $this->db->select("*")->from("nscm_attendance")->where("event_id = '".$event_id."' AND student_id = '".$student_id."' AND apply_status = 'Present'");

        $select = $this->db->get()->row();
		// return $this->db->last_query();
            
        if (is_array($post) && count($post) > 0 && count($select) > 0){
            $update = $this->db->where("event_id = '".$post['event_id']."' AND student_id = '".$student_id."' AND apply_status = 'Present'")->update('nscm_attendance', ['feedback' => $post['feedback'],'rating'=>$post['rating']]);
        }
        if (count($select) > 0 ){
            return $select;
        }
	}
    function student_barchart(){

        $this->db->select("COUNT(s.id) AS users,s.technology")->from("nscm_students AS s")->group_by('s.technology');
        $result = $this->db->get();
        $students = $result->result_array();

        $json_array = $technology =$data=[];
        
        foreach ($students as $student) {
                $data['student_no'] =  (int) $student["users"];
                $data['technology'] = (string) $student["technology"];
                array_push($json_array,$data);
            }
            
        return json_encode($json_array);
    }
}
?>