<?php
class Ask_model extends CI_Model
{
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
		$this->load->database();
    }
	
	
	
	function get_messages($sender,$receiver){
		$query = $this->db->select('*')->from('nscm_ask')->where("sender_id in ($sender,$receiver)")->where("receiver_id in ($sender,$receiver)")->get();
		// echo $this->db->last-query();
		return $query->result_object();
	}

}
?>