<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Agent_model extends CI_Model{


  // get request id data under agent
  function getAssignRequestIdUnderAgent($agent,$from = '',$to=''){
    $this->db->select('unique_id,request_id,seller_id,vertical,assigned_date,status');
    $this->db->where(" NOT EXISTS(select * from form_data f where m.unique_id=f.unique_id)");
    $this->db->where('m.agent_id',$agent);
	if($from != '' && $to != ''){
		$this->db->where('DATE(m.assigned_date)>=',$from);
		$this->db->where('DATE(m.assigned_date)<=',$to);
	}
    $this->db->from('meta_data m');
    $result = $this->db->get();
    // return $this->db->last_query();
    return $result->result_array();
  }

  // get request id data under agent
  function getRequestIdUnderAgentByStatus($uniqId,$from='',$to=''){
    $this->db->select('f.unique_id,f.request_id,f.seller_id,f.vertical,r.status,r.submit_date',false);
    $this->db->from('form_data f');
    $this->db->join('request_history r','f.unique_id = r.unique_id');
    $this->db->where('f.unique_id',$uniqId);
	if($from != '' && $to != ''){
		$this->db->where('DATE(r.submit_date)>=',$from);
		$this->db->where('DATE(r.submit_date)<=',$to);
	}
    $this->db->order_by('r.id','DESC');
    $this->db->limit(1);
    $result = $this->db->get();
    // return $this->db->last_query();
    return $result->row_array();
  }

  // update the record
  function update($uniqueId,$data){
    $this->db->where('unique_id',$uniqueId);
    $update = $this->db->update('form_data',$data);
  }

  // get status wise request id under agent from request_history
  function getRequestIdByStatus($userid,$status){
    $this->db->select('f.*,r.*',false);
    $this->db->from('form_data f');
    $this->db->join('request_history r','f.unique_id = r.unique_id');
    $this->db->where('f.agent_id',$userid);
    $result = $this->db->get();
    // return $this->db->last_query();
    return $result->result_array();
  }

  // callback notification for current date
  function callbacknotification($userid,$date){
    $this->db->select('f.*,r.*',false);
    $this->db->from('form_data f');
    $this->db->join('request_history r','f.unique_id = r.unique_id');
    $this->db->where('f.agent_id',$userid);
    $this->db->where('r.followUp_date',$date);
    $this->db->where('r.status','call back');
    $result = $this->db->get();
    return $result->result_array();
  }

// check seller is exist or not
  function checkSeller($seller_id){
    $this->db->select('*');
    $this->db->from('seller');
    $this->db->where('s_id',$seller_id);
    $result = $this->db->get();
    return $result->row_array();
  }
  
  // count of not_contactable status for unique id
  function get_not_contactable($uniqId){
	  $this->db->select('id');
	  $this->db->from('request_history');
	  $this->db->where('unique_id',$uniqId);
	  $this->db->where('status','Non Contatable/Not Reachable');
	  $query = $this->db->get();
	  return $query->num_rows();
  }
  
  // update status from request id
	function closeRequestId($reqId){
		// get the last record for request id
		$this->db->select('t1.id');
		$this->db->from('request_history t1');
		$this->db->join("(SELECT unique_id, MAX(submit_date) AS submit_date FROM request_history GROUP BY unique_id) tm","t1.unique_id = tm.unique_id AND t1.submit_date = tm.submit_date");
		$this->db->join('form_data t2','t1.unique_id = t2.unique_id');
		$this->db->where('t2.request_id',$reqId);
		$query = $this->db->get();
		// $this->db->last_query();
		$result = $query->row_array();
		$update_id = $result['id'];
		
		// update the last record 
		$this->db->where('id',$update_id);
		$update = $this->db->update('request_history',array('status'=>'Close'));
		if($update){
			return true;
		}else{
			return false;
		}
		
		
	}
	
	
	
  // write above
}
 ?>
