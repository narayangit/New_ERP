<?php
defined('BASEPATH') OR die('No Direct script access allowed');

class Login_model extends CI_Model{

  /*
  *purpose : get the user details from table login
  */
  function getUser($username,$password)
  {
    $this->db->select("*");
    $this->db->from("login");
    $this->db->where('user_id',$username);
    $this->db->where('password',$password);
    $result = $this->db->get();
    //echo $this->db->last_query();
    return  $result->row_array();
  }
}
 ?>
