<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Supervisor_model extends CI_Model{

  /*
   get all agent under supervisor
  */
  function get_all_agent(){
    $this->db->select('user_id,evaluator_name');
    $this->db->from('login');
    $this->db->where('user_type','agent');
	$this->db->order_by('evaluator_name','ASC');
    $result = $this->db->get();
    // $this->db->last_query();
    return $result->result_array();
  }

  /*
   update the request id after assign to agent
  */
  function update($uniqueId,$data){
    $this->db->where('unique_id',$uniqueId);
    $this->db->update('meta_data',$data);
  }

  /*
   get data accroding filter
  */
  function getData($from,$to,$agentId){
    $this->db->select('*');
    // $this->db->where('submit_date>=',$from);
    // $this->db->where('submit_date<=',$to);
	$this->db->where("DATE_FORMAT(submit_date,'%Y-%m-%d') >= DATE_FORMAT('$from','%Y-%m-%d')");
      $this->db->where("DATE_FORMAT(submit_date,'%Y-%m-%d') <= DATE_FORMAT('$to','%Y-%m-%d')");
    $this->db->where('agent_id',$agentId);
    $this->db->from('meta_data');
    $result = $this->db->get();
    return $result->result_array();
  }

  function fetch_data($from,$to,$seller_id,$request_id,$agent_id,$status){
    $this->db->select('r.outcall_date,r.called_by,r.catalog_handling,r.catalog_name,r.catalog_ph_no,r.spoken_with,r.uploading_reason,r.other_reason,r.failure_reason,r.status,r.reason,r.comment,r.seller_type,r.followUp_date,r.followUp_time,r.submit_date,f.seller_ph_no,f.tier,f.vertical,f.request_id,f.feed_time,f.rows_edited,f.rows_passed,f.rows_failed,f.assigned_work,f.seller_id,f.seller_name,');
    $this->db->from('form_data as f');
    $this->db->join('request_history as r','f.unique_id = r.unique_id');
	$this->db->where("DATE_FORMAT(r.submit_date,'%Y-%m-%d') >= DATE_FORMAT('$from','%Y-%m-%d')");
	$this->db->where("DATE_FORMAT(r.submit_date,'%Y-%m-%d') <= DATE_FORMAT('$to','%Y-%m-%d')");
	if($seller_id!=""){$this->db->where('f.seller_id',$seller_id);}
	if($request_id!=""){$this->db->where('f.request_id',$request_id);}
	if($agent_id!=""){$this->db->where('f.agent_id',$agent_id);}
	if($status!=""){$this->db->where('r.status',$status);}
	$result = $this->db->get();
    return $result->result();
    // echo $this->db->last_query();
  }

// fetch feed data
  function fetch_feed_data($from,$to){
    $this->db->select('*');
    $this->db->from('feed_data');
    $this->db->where("DATE_FORMAT(date,'%Y-%m-%d') >= DATE_FORMAT('$from','%Y-%m-%d')");
	  $this->db->where("DATE_FORMAT(date,'%Y-%m-%d') <= DATE_FORMAT('$to','%Y-%m-%d')");
    $result = $this->db->get();
    return $result->result();
    // echo $this->db->last_query();
  }

  // get pending request id data under agent
  function getPendingRequestIdUnderAgent($agent,$from,$to){
    $this->db->select('*');
    $this->db->where(" NOT EXISTS(select * from form_data f where m.unique_id=f.unique_id)");
    $this->db->where('m.agent_id',$agent);
	// $this->db->where('m.submit_date>=',$from);
	// $this->db->where('m.submit_date<=',$to);
	$this->db->where("DATE_FORMAT(m.submit_date,'%Y-%m-%d') >= DATE_FORMAT('$from','%Y-%m-%d')");
	$this->db->where("DATE_FORMAT(m.submit_date,'%Y-%m-%d') <= DATE_FORMAT('$to','%Y-%m-%d')");
    $this->db->from('meta_data m');
    $result = $this->db->get();
    // return $this->db->last_query();
    return $result->result_array();
  }

 // get unique worked request id
  function getWorkedRequestIdUnderAgent($agent,$from,$to){
    $this->db->select('t1.*,t2.*');
	$this->db->from('request_history t1');
	$this->db->join("(SELECT unique_id, MAX(submit_date) AS submit_date FROM request_history GROUP BY unique_id) tm","t1.unique_id = tm.unique_id AND t1.submit_date = tm.submit_date");
	$this->db->join('form_data t2','t1.unique_id = t2.unique_id');
	$this->db->where('t2.agent_id',$agent);
	$this->db->where("DATE_FORMAT(t2.submit_date,'%Y-%m-%d') >= DATE_FORMAT('$from','%Y-%m-%d')");
	$this->db->where("DATE_FORMAT(t2.submit_date,'%Y-%m-%d') <= DATE_FORMAT('$to','%Y-%m-%d')");
	$result = $this->db->get();
    // echo  $this->db->last_query();
    return $result->result_array();
  }

  // get follow up worked request id
  function getFollowUpRequestIdUnderAgent($from,$to){
    $this->db->select('t1.*,t2.*');
	$this->db->from('request_history t1');
	$this->db->join("(SELECT unique_id, MAX(submit_date) AS submit_date FROM request_history GROUP BY unique_id) tm","t1.unique_id = tm.unique_id AND t1.submit_date = tm.submit_date");
	$this->db->join('form_data t2','t1.unique_id = t2.unique_id');
	$this->db->where("DATE_FORMAT(t1.followUp_date,'%Y-%m-%d') >= DATE_FORMAT('$from','%Y-%m-%d')");
	$this->db->where("DATE_FORMAT(t1.followUp_date,'%Y-%m-%d') <= DATE_FORMAT('$to','%Y-%m-%d')");
	$result = $this->db->get();
    // echo  $this->db->last_query();
    return $result->result_array();
  }

//write above
}

 ?>
