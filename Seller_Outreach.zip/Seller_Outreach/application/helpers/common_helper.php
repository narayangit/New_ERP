<?php

// get all request id list
function get_all_request($date){
  $CI = & get_instance();
  $CI->db->select('*');
  $CI->db->from('meta_data');
  $CI->db->where("DATE_FORMAT(submit_date,'%Y-%m-%d') = DATE_FORMAT('$date','%Y-%m-%d')");
  $CI->db->where('status','Not Assign');
  $result = $CI->db->get();
  return $result->result_array();
}

// get all request id list
function get_all_pending_request($date){
  $CI = & get_instance();
  $CI->db->select('*');
  $CI->db->where(" NOT EXISTS(select * from form_data f where m.unique_id=f.unique_id)");
  $CI->db->where("DATE_FORMAT(m.assigned_date,'%Y-%m-%d') = DATE_FORMAT('$date','%Y-%m-%d')");
  $CI->db->where("status !=","Not Assign");
  $CI->db->from('meta_data m');
  $result = $CI->db->get();
  // return $CI->db->last_query();
  return $result->result_array();
}

// get all request id under agent
  function getRequestIdUnderAgent($agent,$from="",$to=""){
	$CI = & get_instance();
    $CI->db->select('*');
    $CI->db->where('agent_id',$agent);
    if($from!="" && $to!=""){
      $CI->db->where("DATE_FORMAT(submit_date,'%Y-%m-%d') >= DATE_FORMAT('$from','%Y-%m-%d')");
      $CI->db->where("DATE_FORMAT(submit_date,'%Y-%m-%d') <= DATE_FORMAT('$to','%Y-%m-%d')");
    }
    $CI->db->from('meta_data');
    $result = $CI->db->get();
    // return $CI->db->last_query();
    return $result->result_array();
  }

  // get status wise request id under agent from request_history
  function getRequestIdByStatusWithDate($userid,$from,$to,$status=null){
	$CI = & get_instance();
    $CI->db->select('f.*,r.*',false);
    $CI->db->from('form_data f');
    $CI->db->join('request_history r','f.unique_id = r.unique_id');
    $CI->db->where('r.called_by',$userid);
    $CI->db->where("DATE_FORMAT(f.submit_date,'%Y-%m-%d') >= DATE_FORMAT('$from','%Y-%m-%d')");
      $CI->db->where("DATE_FORMAT(f.submit_date,'%Y-%m-%d') <= DATE_FORMAT('$to','%Y-%m-%d')");
    if($status!=""){
      $CI->db->where('r.status',$status);
    }
    $result = $CI->db->get();
    // return $CI->db->last_query();
    return $result->result_array();
  }

  // contacted seller and request id
  function getTotalContacted($field,$userid,$from,$to,$status=null){
	$CI = & get_instance();
  // if($field == 'seller_id'){
    $CI->db->distinct();
  // }
  $field = 'f.'.$field;
    $CI->db->select($field,false);
    $CI->db->from('form_data f');
    $CI->db->join('request_history r','f.unique_id = r.unique_id');
    $CI->db->where('r.called_by',$userid);
    $CI->db->where("DATE_FORMAT(f.submit_date,'%Y-%m-%d') >= DATE_FORMAT('$from','%Y-%m-%d')");
      $CI->db->where("DATE_FORMAT(f.submit_date,'%Y-%m-%d') <= DATE_FORMAT('$to','%Y-%m-%d')");
    if($status!=""){
      $CI->db->where('r.status',$status);
    }
    $result = $CI->db->get();
    // return $CI->db->last_query();
    return $result->result_array();
  }


// get agent name using agent id
function getAgentNameFromAgentId($agentId){
    $CI = & get_instance();
    $CI->db->select('evaluator_name');
    $CI->db->where('user_id',$agentId);
    $result = $CI->db->get('login');
    $row = $result->row_array();
    return $row['evaluator_name'];
}

// get status of request //
function getStatusOfUniqueId($uniqueId){
  $CI = & get_instance();
  $CI->db->select('status');
  $CI->db->where('unique_id',$uniqueId);
  $result = $CI->db->get('meta_data');
  $row = $result->row_array();
  return $row['status'];
}

//get unique id data from meta data table
function getUniqueIdDataFromMetaData($uniqueId){
  $CI = & get_instance();
  $CI->db->select('*');
  $CI->db->where('unique_id',$uniqueId);
  $result = $CI->db->get('meta_data');
  return $result->row_array();
}

//get unique id data from form data
function getUniqueIdDataFromFormData($uniqueId){
  $CI = & get_instance();
  $CI->db->select('*');
  $CI->db->where('unique_id',$uniqueId);
  $result = $CI->db->get('form_data');
  return $result->row_array();
}

// get unique id data from history table
function getUniqueIdDataFromRecord($uniqueId){
  $CI = & get_instance();
  $CI->db->select('*');
  $CI->db->where('unique_id',$uniqueId);
  $result = $CI->db->get('request_history');
  return $result->result_array();
}

// get all agent
function getAllAgent(){
  $CI = & get_instance();
  $CI->db->select('evaluator_name');
  $CI->db->where('user_type','agent');
  $result = $CI->db->get('login');
  return $result->result_array();
}

// check unique id exists or not in form_data
  function checkFormDataRecord($uniqueId){
    $CI = & get_instance();
    $CI->db->select('*');
    $CI->db->where('unique_id',$uniqueId);
    $result = $CI->db->get('form_data');
    return $result->row_array();
  }

  // last updated date for request id
  function getLastUpdatedDate($uniqId){
	$CI = & get_instance();
    $CI->db->select("submit_date");
    $CI->db->where('unique_id',$uniqId);
	$CI->db->order_by('id','DESC');
    $CI->db->limit(1);
	$query = $CI->db->get('request_history');
    $result = $query->row_array();
	// return $CI->db->last_query();
	return $result['submit_date'];

  }


  // select all unique seller id
	function getSeller(){
		$CI = & get_instance();
		$CI->db->select("seller_id");
		$CI->db->distinct();
		$query = $CI->db->get('meta_data');
		$result = $query->result_array();
		// echo  $CI->db->last_query();
		return $result;
	}


 /*------------------- reporting related functions --------------------- */
 
// get count of seller wise
function getCountSellerWise($from,$to,$assignType){
  $CI = & get_instance();
  $CI->db->distinct();
  $CI->db->select('seller_id');
  $CI->db->from('form_data');
  $CI->db->where("DATE_FORMAT(submit_date,'%Y-%m-%d') >= DATE_FORMAT('$from','%Y-%m-%d')");
  $CI->db->where("DATE_FORMAT(submit_date,'%Y-%m-%d') <= DATE_FORMAT('$to','%Y-%m-%d')");
  $CI->db->where('assigned_work',$assignType);
  $result = $CI->db->get();
  // echo $CI->db->last_query();
  return $result->num_rows();
}

// get count of request/feed wise
function getCountRequestWise($from,$to,$assignType){
  $CI = & get_instance();
  $CI->db->distinct();
  $CI->db->select('request_id');
  $CI->db->from('form_data');
  $CI->db->where("DATE_FORMAT(submit_date,'%Y-%m-%d') >= DATE_FORMAT('$from','%Y-%m-%d')");
  $CI->db->where("DATE_FORMAT(submit_date,'%Y-%m-%d') <= DATE_FORMAT('$to','%Y-%m-%d')");
  $CI->db->where('assigned_work',$assignType);
  $result = $CI->db->get();
  // echo $CI->db->last_query();
  return $result->num_rows();
}

// get count of seller wise
function getCountSellerWiseWithStatus($from,$to,$assignType,$status){
  $CI = & get_instance();
  $CI->db->distinct();
  $CI->db->select('f.seller_id',false);
  $CI->db->from('form_data f');
  $CI->db->join('request_history r','f.unique_id=r.unique_id');
  $CI->db->where("DATE_FORMAT(f.submit_date,'%Y-%m-%d') >= DATE_FORMAT('$from','%Y-%m-%d')");
  $CI->db->where("DATE_FORMAT(f.submit_date,'%Y-%m-%d') <= DATE_FORMAT('$to','%Y-%m-%d')");
  $CI->db->where('f.assigned_work',$assignType);
  $CI->db->where('r.status',$status);
  $result = $CI->db->get();
  // echo $CI->db->last_query();
  return $result->num_rows();
}

// get count request wise with status
function getCountRequestWiseWithStatus($from,$to,$assignType,$status){
  $CI = & get_instance();
  $CI->db->select('f.request_id',false);
  $CI->db->from('form_data f');
  $CI->db->join('request_history r','f.unique_id=r.unique_id');
  $CI->db->where("DATE_FORMAT(f.submit_date,'%Y-%m-%d') >= DATE_FORMAT('$from','%Y-%m-%d')");
  $CI->db->where("DATE_FORMAT(f.submit_date,'%Y-%m-%d') <= DATE_FORMAT('$to','%Y-%m-%d')");
  $CI->db->where('f.assigned_work',$assignType);
  $CI->db->where('r.status',$status);
  $result = $CI->db->get();
  // echo $CI->db->last_query();
  return $result->num_rows();
}


// total count of uploading feed
function totalUploadingFeed($from,$to,$assignType){
  $CI = & get_instance();
  $CI->db->select('sum(uploaded)');
  $CI->db->from('feed_data');
  $CI->db->where('assigned_worked',$assignType);
  $CI->db->where("DATE_FORMAT(date,'%Y-%m-%d') >= DATE_FORMAT('$from','%Y-%m-%d')");
  $CI->db->where("DATE_FORMAT(date,'%Y-%m-%d') <= DATE_FORMAT('$to','%Y-%m-%d')");
  $result = $CI->db->get();
  $row = $result->row_array();
  $count = $row['sum(uploaded)'];
  if($count>0){
      return $count;
  }else{
    return 0;
  }
}


// total count of passed feed
function totalPassedFeed($from,$to,$assignType){
  $CI = & get_instance();
  $CI->db->select('sum(passed)');
  $CI->db->from('feed_data');
  $CI->db->where('assigned_worked',$assignType);
  $CI->db->where("DATE_FORMAT(date,'%Y-%m-%d') >= DATE_FORMAT('$from','%Y-%m-%d')");
  $CI->db->where("DATE_FORMAT(date,'%Y-%m-%d') <= DATE_FORMAT('$to','%Y-%m-%d')");
  $result = $CI->db->get();
  $row = $result->row_array();
  $count = $row['sum(passed)'];
  if($count>0){
      return $count;
  }else{
    return 0;
  }
}

// total count of uploading feed
function totalUploadingFeedByDate($from,$to){
  $CI = & get_instance();
  $CI->db->select('sum(uploaded)');
  $CI->db->from('feed_data');
  $CI->db->where("DATE_FORMAT(date,'%Y-%m-%d') >= DATE_FORMAT('$from','%Y-%m-%d')");
  $CI->db->where("DATE_FORMAT(date,'%Y-%m-%d') <= DATE_FORMAT('$to','%Y-%m-%d')");
  $result = $CI->db->get();
  $row = $result->row_array();
  $count = $row['sum(uploaded)'];
  if($count>0){
      return $count;
  }else{
    return 0;
  }
}


// total count of passed feed
function totalPassedFeedByDate($from,$to){
  $CI = & get_instance();
  $CI->db->select('sum(passed)');
  $CI->db->from('feed_data');
  $CI->db->where("DATE_FORMAT(date,'%Y-%m-%d') >= DATE_FORMAT('$from','%Y-%m-%d')");
  $CI->db->where("DATE_FORMAT(date,'%Y-%m-%d') <= DATE_FORMAT('$to','%Y-%m-%d')");
  $result = $CI->db->get();
  $row = $result->row_array();
  $count = $row['sum(passed)'];
  if($count>0){
      return $count;
  }else{
    return 0;
  }
}

// total count of uploading feed
function totalCountOfUploadingFeed($date){
  $format = strtotime($date);
  $y = date('Y',$format);
  $m = date('m',$format);
  $d = date('j',$format);
  $i=0;
  $total = 0;
  $CI = & get_instance();
  // for ($i=1; $i <=$d ; $i++) {
    $CI->db->select('sum(uploaded)');
    $CI->db->from('feed_data');
    $CI->db->where("DATE_FORMAT(date,'%Y-%m-%d') >= DATE_FORMAT('$y-$m-$i','%Y-%m-%d')");
    $CI->db->where("DATE_FORMAT(date,'%Y-%m-%d') <= DATE_FORMAT('$date','%Y-%m-%d')");
    $result = $CI->db->get();
    $row = $result->row_array();
    $count = $row['sum(uploaded)'];
    if($count>0){
        $total += $count;
    }else{
      $total += 0;
    }
  // }
  return $total;
  // return $CI->db->last_query();
}


// total count of passed feed
function totalCountOfPassedFeed($date){
  $format = strtotime($date);
  $y = date('Y',$format);
  $m = date('m',$format);
  $d = date('j',$format);
  $i=01;
  $total = 0;
  $CI = & get_instance();
  // for ($i=1; $i <=$d ; $i++) {
    $CI->db->select('sum(passed)');
    $CI->db->from('feed_data');
	$CI->db->where("DATE_FORMAT(date,'%Y-%m-%d') >= DATE_FORMAT('$y-$m-$i','%Y-%m-%d')");
    $CI->db->where("DATE_FORMAT(date,'%Y-%m-%d') <= DATE_FORMAT('$date','%Y-%m-%d')");
    $result = $CI->db->get();
    $row = $result->row_array();
    $count = $row['sum(passed)'];
    if($count>0){
        $total += $count;
    }else{
      $total += 0;
    }
  // }
  return $total;
  // return $CI->db->last_query();
}

// count unique seller id from particular date
function getTotalCountByDate($date,$field){
  $format = strtotime($date);
  $y = date('Y',$format);
  $m = date('m',$format);
  $d = date('j',$format);
  $total = 0;
  $CI = & get_instance();
  // for ($i=1; $i <=$d ; $i++) {
    $CI->db->distinct();
    $CI->db->select($field);
    $CI->db->from('form_data');
    $CI->db->where("DATE_FORMAT(submit_date,'%Y-%m-%d') >= DATE_FORMAT('$y-$m-01','%Y-%m-%d')");
    $CI->db->where("DATE_FORMAT(submit_date,'%Y-%m-%d') <= DATE_FORMAT('$date','%Y-%m-%d')");
    $result = $CI->db->get();
    $row = $result->result_array();
    $count = count($row);
    if($count>0){
        $total += $count;
    }else{
      $total += 0;
    }
  // }
  return $total;
  // return $CI->db->last_query();
}

// single date count seller id
// count unique seller id from particular date
function getCountByDate($from,$to,$field){
  $CI = & get_instance();
    $CI->db->distinct();
    $CI->db->select($field);
    $CI->db->from('form_data');
    $CI->db->where("DATE_FORMAT(submit_date,'%Y-%m-%d') >= DATE_FORMAT('$from','%Y-%m-%d')");
    $CI->db->where("DATE_FORMAT(submit_date,'%Y-%m-%d') <= DATE_FORMAT('$to','%Y-%m-%d')");
    $result = $CI->db->get();
    $row = $result->result_array();
    $count = count($row);
    if($count>0){
        return $count;
    }else{
      return 0;
    }
  // return $CI->db->last_query();
}

// get count of seller wise
function getCountForSingleDateWithStatus($from,$to,$status,$field){
  $CI = & get_instance();
  if($field == 'seller_id'){
    $CI->db->distinct();
  }
  $field = 'f.'.$field;
  $CI->db->select($field,false);
  $CI->db->from('form_data f');
  $CI->db->join('request_history r','f.unique_id=r.unique_id');
  $CI->db->where("DATE_FORMAT(f.submit_date,'%Y-%m-%d') >= DATE_FORMAT('$from','%Y-%m-%d')");
  $CI->db->where("DATE_FORMAT(f.submit_date,'%Y-%m-%d') <= DATE_FORMAT('$to','%Y-%m-%d')");
  $CI->db->where('r.status',$status);
  $result = $CI->db->get();
  // echo $CI->db->last_query();
  return $result->num_rows();
}

// count unique seller id from particular date
function getTotalCountWithStatus($date,$status,$field){
  $format = strtotime($date);
  $y = date('Y',$format);
  $m = date('m',$format);
  $d = date('j',$format);
  $total = 0;
  $fields = 'f.'.$field;
  $CI = & get_instance();

  // for ($i=1; $i <=$d ; $i++) {
    if($field == 'seller_id'){
      $CI->db->distinct();
    }
    $CI->db->select($fields,false);
    $CI->db->from('form_data f');
    $CI->db->join('request_history r','f.unique_id=r.unique_id');
    $CI->db->where("DATE_FORMAT(f.submit_date,'%Y-%m-%d') >= DATE_FORMAT('$y-$m-01','%Y-%m-%d')");
    $CI->db->where("DATE_FORMAT(f.submit_date,'%Y-%m-%d') <= DATE_FORMAT('$date','%Y-%m-%d')");
    $CI->db->where('r.status',$status);
    $result = $CI->db->get();
    $row = $result->result_array();
    $count = count($row);
    if($count>0){
        $total += $count;
    }else{
      $total += 0;
    }
  // }
  return $total;
  // return $CI->db->last_query();
}


// count for post call status

// get count of seller wise
function getCountForPostCall($from,$to,$assignType,$field){
  $CI = & get_instance();
  $CI->db->distinct();
  $CI->db->select($field);
  $CI->db->from('feed_data');
  $CI->db->where("DATE_FORMAT(date,'%Y-%m-%d') >= DATE_FORMAT('$from','%Y-%m-%d')");
  $CI->db->where("DATE_FORMAT(date,'%Y-%m-%d') <= DATE_FORMAT('$to','%Y-%m-%d')");
  $CI->db->where('assigned_worked',$assignType);
  $result = $CI->db->get();
  // $CI->db->last_query();
  return $result->num_rows();
}

// count unique seller id from particular date
function getTotalCountForPostCall($date,$field){
  $format = strtotime($date);
  $y = date('Y',$format);
  $m = date('m',$format);
  $d = date('j',$format);
  $i = 01;
  $total = 0;
  $CI = & get_instance();
  // for ($i=1; $i <=$d ; $i++) {
    $CI->db->distinct();
    $CI->db->select($field);
    $CI->db->from('feed_data');
    $CI->db->where("DATE_FORMAT(date,'%Y-%m-%d') >= DATE_FORMAT('$y-$m-$i','%Y-%m-%d')");
    $CI->db->where("DATE_FORMAT(date,'%Y-%m-%d') <= DATE_FORMAT('$date','%Y-%m-%d')");
    $result = $CI->db->get();
    $row = $result->result_array();
    $count = count($row);
    if($count>0){
        $total += $count;
    }else{
      $total += 0;
    }
  // }
  return $total;
  // return $CI->db->last_query();
}

// get count of seller wise
function getCountForSingleDateForPostCall($from,$to,$field){
  $CI = & get_instance();
  $CI->db->distinct();
  $CI->db->select($field);
  $CI->db->from('feed_data');
  $CI->db->where("DATE_FORMAT(date,'%Y-%m-%d') >= DATE_FORMAT('$from','%Y-%m-%d')");
  $CI->db->where("DATE_FORMAT(date,'%Y-%m-%d') <= DATE_FORMAT('$to','%Y-%m-%d')");
  $result = $CI->db->get();
  // echo $CI->db->last_query();
  return $result->num_rows();
}

/* -------- reporting function closed here ------------------------ */

// get today data uploaded or not
function checkUploadedStatus($db,$date){
  $CI = & get_instance();
  $CI->db->select('*');
  $CI->db->from($db);
  $CI->db->where("DATE_FORMAT(submit_date,'%Y-%m-%d') = DATE_FORMAT('$date','%Y-%m-%d')");
  $result = $CI->db->get();
  $count = $result->num_rows();
  if($count>0){
    return true;
  }else{
    return false;
  }
}

// get assigned agent name from unique id
function getAgentNameFromUniqueId($uniqId){
	$CI = & get_instance();
	$result = $CI->db->select('agent_name')->where('unique_id',$uniqId)->get('meta_data');
	return $result->row_object()->agent_name;
}

  // write above
 ?>
