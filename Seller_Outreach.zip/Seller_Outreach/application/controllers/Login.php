<?php
defined('BASEPATH') or exit('No Direct Script access allowed');

class Login extends CI_Controller{

  function __construct(){
    parent::__construct();
    $this->load->model('login_model');
  }

// user login function
  function index(){
    // get the value from login form
    $username = $this->input->post('username');
    $password = $this->input->post('password');
    $userType = $this->input->post('usertype');


    // check validation for login form
    $validation = array(
      array(
         'field' => 'username',
         'label' => 'Username',
         'rules' => 'trim|required'
       ),
      array(
         'field' => 'password',
         'label' => 'Password',
         'rules' => 'trim|required'
       ),
      array(
         'field' => 'userType',
         'rules' => 'required'
       ),
    );
    $this->form_validation->set_rules($validation);

    if($this->form_validation->run()==FALSE){
      $this->load->view('login');
    }else{
      // function in login model for check user details
      $user_result = $this->login_model->getUser($username,$password,$userType);

      // checking user data found or not
      if(count($user_result)>0){
        //check user is eligible for login
        if($user_result['enabled']==1){
          $userid = $user_result['user_id'];
          $usertype = $user_result['user_type'];

          $sessiondata = array(
          'user_id'  => $userid,
          'username' => $user_result['evaluator_name'],
          'level'		=> $usertype,
          'loginuser' => TRUE
          );
          $this->session->set_userdata($sessiondata);
          // checking for redirect after login
          if($usertype == "agent"){
            redirect('agent');
          }else if($usertype == "supervisor"){
            redirect('supervisor');
          }
        }else{
          $this->session->set_flashdata('msg', '<div style="font-size:14px;color:red" class="alert alert-dismissible fade show" role="alert">Not Eligible to Login<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			<span aria-hidden="true">&times;</span></button></div>');
           redirect('login');
        }
      }else{
       $this->session->set_flashdata('msg', '<div style="font-size:14px;color:red" class="alert alert-dismissible fade show" role="alert">Username and password incorrect<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			<span aria-hidden="true">&times;</span></button></div>');
		redirect('login');
      }
    }
  }

  // user logout function
  function logout(){
    $this->session->sess_destroy();
    redirect('login');
  }
  // write code above
}

 ?>
