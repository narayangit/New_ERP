<?php
defined('BASEPATH') or exit('No Direct Script access allowed');

class Agent extends CI_Controller{

  function __construct(){
    parent::__construct();
    $this->load->model('agent_model');
    is_logged_in();
  }

  // agent dashboard
  function index(){
    $data['pageid'] = 'Agent';
    $userid = $this->session->userdata('user_id');
	if($this->input->get('fromDate')){
		$from = $this->input->get('fromDate');
		$to = $this->input->get('toDate');
	}else{
		$from = $to = '';
	}
    $data['getRequestIdUnderAgent'] = $this->agent_model->getAssignRequestIdUnderAgent($userid,$from,$to);
    $date = date('Y-m-d');
    $data['callbackId'] = $this->agent_model->callbacknotification($userid,$date);
	$data['fromDate'] = $from;
	$data['toDate'] = $to;
    $this->load->view('agent/assign',$data);
  }

  // call back request id function
  function callBack(){
    $data['pageid'] = 'Call Back';
    $userid = $this->session->userdata('user_id');
	if($this->input->get('fromDate')){
		$from = $this->input->get('fromDate');
		$to = $this->input->get('toDate');
	}else{
		$from = $to = '';
	}
	
    $requestIdsUnderAgent = getRequestIdUnderAgent($userid);
    $getRequestIdUnderAgent = array();
    foreach ($requestIdsUnderAgent as $value) {
        $data1 = $this->agent_model->getRequestIdUnderAgentByStatus($value['unique_id'],$from,$to);
		if($data1['status'] == 'call back'){
          array_push($getRequestIdUnderAgent,$data1);
        }
    }
    $data['getRequestIdUnderAgent'] = $getRequestIdUnderAgent;
	$data['fromDate'] = $from;
	$data['toDate'] = $to;
    $this->load->view('agent/call-back',$data);
  }

  // call Back-Agreed to Upload request id function
  function agreedToUpload(){
    $data['pageid'] = 'Agrre to upload';
    $userid = $this->session->userdata('user_id');
	if($this->input->get('fromDate')){
		$from = $this->input->get('fromDate');
		$to = $this->input->get('toDate');
	}else{
		$from = $to = '';
	}
    $requestIdsUnderAgent = getRequestIdUnderAgent($userid);
    $getRequestIdUnderAgent = array();
    foreach ($requestIdsUnderAgent as $value) {
        $data1 = $this->agent_model->getRequestIdUnderAgentByStatus($value['unique_id'],$from,$to);
        if($data1['status'] == 'call Back-Agreed to Upload'){
          array_push($getRequestIdUnderAgent,$data1);
        }
    }
    $data['getRequestIdUnderAgent'] = $getRequestIdUnderAgent;
	$data['fromDate'] = $from;
	$data['toDate'] = $to;
    $this->load->view('agent/agree-tp-upload',$data);
  }

  // Contacted-Disagree to Upload request id function
  function disagreedToUpload(){
    $data['pageid'] = 'Disagree to Upload';
    $userid = $this->session->userdata('user_id');
	if($this->input->get('fromDate')){
		$from = $this->input->get('fromDate');
		$to = $this->input->get('toDate');
	}else{
		$from = $to = '';
	}
    $requestIdsUnderAgent = getRequestIdUnderAgent($userid);
    $getRequestIdUnderAgent = array();
    foreach ($requestIdsUnderAgent as $value) {
        $data1 = $this->agent_model->getRequestIdUnderAgentByStatus($value['unique_id'],$from,$to);
        if($data1['status'] == 'Contacted-Disagree to Upload'){
          array_push($getRequestIdUnderAgent,$data1);
        }
    }
    $data['getRequestIdUnderAgent'] = $getRequestIdUnderAgent;
	$data['fromDate'] = $from;
	$data['toDate'] = $to;
    $this->load->view('agent/disagree-tp-upload',$data);
  }

  // Listing Uploaded-Post Call request id function
  function postCall(){
    $data['pageid'] = 'Post Call';
    $userid = $this->session->userdata('user_id');
	if($this->input->get('fromDate')){
		$from = $this->input->get('fromDate');
		$to = $this->input->get('toDate');
	}else{
		$from = $to = '';
	}
    $requestIdsUnderAgent = getRequestIdUnderAgent($userid);
    $getRequestIdUnderAgent = array();
    foreach ($requestIdsUnderAgent as $value) {
        $data1 = $this->agent_model->getRequestIdUnderAgentByStatus($value['unique_id'],$from,$to);
        if($data1['status'] == 'Listing Uploaded-Post Call'){
          array_push($getRequestIdUnderAgent,$data1);
        }
    }
    $data['getRequestIdUnderAgent'] = $getRequestIdUnderAgent;
	$data['fromDate'] = $from;
	$data['toDate'] = $to;
    $this->load->view('agent/post-call',$data);
  }

  // Listing Uploaded-Pre Call request id function
  function preCall(){
    $data['pageid'] = 'Pre Call';
    $userid = $this->session->userdata('user_id');
	if($this->input->get('fromDate')){
		$from = $this->input->get('fromDate');
		$to = $this->input->get('toDate');
	}else{
		$from = $to = '';
	}
    $requestIdsUnderAgent = getRequestIdUnderAgent($userid);
    $getRequestIdUnderAgent = array();
    foreach ($requestIdsUnderAgent as $value) {
        $data1 = $this->agent_model->getRequestIdUnderAgentByStatus($value['unique_id'],$from,$to);
        if($data1['status'] == 'Listing Uploaded-Pre Call'){
          array_push($getRequestIdUnderAgent,$data1);
        }
    }
    $data['getRequestIdUnderAgent'] = $getRequestIdUnderAgent;
	$data['fromDate'] = $from;
	$data['toDate'] = $to;
    $this->load->view('agent/pre-call',$data);
  }

  // Non Contatable/Not Reachable request id function
  function notReachable(){
    $data['pageid'] = 'Not Reachable';
    $userid = $this->session->userdata('user_id');
	if($this->input->get('fromDate')){
		$from = $this->input->get('fromDate');
		$to = $this->input->get('toDate');
	}else{
		$from = $to = '';
	}
    $requestIdsUnderAgent = getRequestIdUnderAgent($userid);
    $getRequestIdUnderAgent = array();
    foreach ($requestIdsUnderAgent as $value) {
        $data1 = $this->agent_model->getRequestIdUnderAgentByStatus($value['unique_id'],$from,$to);
        if($data1['status'] == 'Non Contactable/Not Reachable'){
          array_push($getRequestIdUnderAgent,$data1);
        }
    }
    $data['getRequestIdUnderAgent'] = $getRequestIdUnderAgent;
	$data['fromDate'] = $from;
	$data['toDate'] = $to;
    $this->load->view('agent/nt-reachable',$data);
  }

  // No Follow up required request id function
  function noFollowUp(){
    $data['pageid'] = 'No FollowUp';
    $userid = $this->session->userdata('user_id');
	if($this->input->get('fromDate')){
		$from = $this->input->get('fromDate');
		$to = $this->input->get('toDate');
	}else{
		$from = $to = '';
	}
    $requestIdsUnderAgent = getRequestIdUnderAgent($userid);
    $getRequestIdUnderAgent = array();
    foreach ($requestIdsUnderAgent as $value) {
        $data1 = $this->agent_model->getRequestIdUnderAgentByStatus($value['unique_id'],$from,$to);
        if($data1['status'] == 'No Follow UP required'){
          array_push($getRequestIdUnderAgent,$data1);
        }
    }
    $data['getRequestIdUnderAgent'] = $getRequestIdUnderAgent;
	$data['fromDate'] = $from;
	$data['toDate'] = $to;
    $this->load->view('agent/no-followUp',$data);
  }

  // close request id function
  function close(){
    $data['pageid'] = 'close';
    $userid = $this->session->userdata('user_id');
	if($this->input->get('fromDate')){
		$from = $this->input->get('fromDate');
		$to = $this->input->get('toDate');
	}else{
		$from = $to = '';
	}
    $requestIdsUnderAgent = getRequestIdUnderAgent($userid);
    $getRequestIdUnderAgent = array();
    foreach ($requestIdsUnderAgent as $value) {
        $data1 = $this->agent_model->getRequestIdUnderAgentByStatus($value['unique_id'],$from,$to);
        if($data1['status'] == 'Close'){
          array_push($getRequestIdUnderAgent,$data1);
        }
    }
    $data['getRequestIdUnderAgent'] = $getRequestIdUnderAgent;
	$data['fromDate'] = $from;
	$data['toDate'] = $to;
    $this->load->view('agent/close',$data);
  }


  // form for request id
  function agentForm($uniqId=null){
    $data['pageid'] = 'form';
    $getStatus = checkFormDataRecord($uniqId);
    $userid = $this->session->userdata('user_id');
    if($getStatus){
      $uniqueIdData = getUniqueIdDataFromFormData($uniqId);
    }else{
      $uniqueIdData = getUniqueIdDataFromMetaData($uniqId);
      $sellerData= $this->agent_model->checkSeller($uniqueIdData['seller_id']);
      $uniqueIdData['seller_name'] = $sellerData['s_name'];
      $uniqueIdData['seller_ph_no'] = $sellerData['s_ph_no'];
    }
    $data['uniqueIdData'] = $uniqueIdData;
    $data['historyData'] = getUniqueIdDataFromRecord($uniqId);
    $data['agentList'] = getAllAgent();
    // validations
    $validation = array(
      array(
        'field' => 'seller_name',
        'label' => 'Seller Name',
        'rules' => 'trim|required'
      ),
      array(
        'field' => 'seller_id',
        'label' => 'Seller ID',
        'rules' => 'trim|required'
      ),
      array(
        'field' => 'seller_ph_no',
        'label' => 'Seller Phone No',
        'rules' => 'trim|required'
      ),
      array(
        'field' => 'feed_time',
        'label' => 'Feed Uploaded At*',
        'rules' => 'trim|required'
      ),
      array(
        'field' => 'rows_edited',
        'label' => 'Count of listings uploaded',
        'rules' => 'trim|required'
      ),
      array(
        'field' => 'rows_passed',
        'label' => 'Number of listings Passed',
        'rules' => 'trim|required'
      ),
      array(
        'field' => 'rows_failed',
        'label' => 'Number of listings Failed',
        'rules' => 'trim|required'
      ),
      array(
        'field' => 'tier',
        'label' => 'Tier',
        'rules' => 'trim|required'
      ),
      array(
        'field' => 'request_id',
        'label' => 'Request Id/Feed Id',
        'rules' => 'trim|required'
      ),
      array(
        'field' => 'assigned_work',
        'label' => 'Assigned Work',
        'rules' => 'trim|required'
      ),
      array(
         'field' => 'outcall_date',
         'label' => 'Enter Date',
         'rules' => 'trim|required'
       ),
      array(
         'field' => 'called_by',
         'label' => 'Called By',
         'rules' => 'trim|required'
       ),
       array(
          'field' => 'spoken_with',
          'label' => 'Spoken With',
          'rules' => 'trim|required'
        ),
       array(
          'field' => 'uploading_reason',
          'label' => 'Reason for not uploading earlier',
          'rules' => 'trim|required'
        ),
       array(
          'field' => 'status',
          'label' => 'Status',
          'rules' => 'trim|required'
        ),
       array(
          'field' => 'seller_type',
          'label' => 'Seller Type',
          'rules' => 'trim|required'
        )
    );
    // $this->form_validation->set_rules('seller_name','Seller Name','required');
    $this->form_validation->set_rules($validation);
    if($this->form_validation->run() == false){
		$this->load->view('agent/agent-form',$data);
    }else{
		// status update for other request id
		if($this->input->post('oth_request_id')){
			$oth_req_id = $this->input->post('oth_request_id');
			$this->agent_model->closeRequestId($oth_req_id);
		}

	  $uniqueId = $this->input->post('unique_id');
      // history tracking array
      $s_id = $this->input->post('seller_id');
      $s_name = $this->input->post('seller_name');
      $s_ph_no = $this->input->post('seller_ph_no');

		// if date is empty then insert null values
		if($this->input->post('followUp_date') == ''){
			$followUp_date = '';
			$followUp_time = '';
		}else{
			$followUp_date = $this->input->post('followUp_date');
			$followUp_time = $this->input->post('followUp_time');
		}

		// validation for check Not Contatable/Not Reachable more than 3 times
		$no_of_not_contactable = $this->agent_model->get_not_contactable($uniqueId);
		if($no_of_not_contactable==3){
			$this->session->set_flashdata('msg', 'Not Contactable status already filled 3 times');
			redirect("form/$uniqueId");
		}

      $track = array(
        'unique_id' => $uniqueId,
        'outcall_date' => $this->input->post('outcall_date'),
		'catalog_handling' => $this->input->post('catalog_handling'),
		'catalog_name' => $this->input->post('catalog_name'),
		'catalog_ph_no' => $this->input->post('catalog_ph_no'),
        'called_by' => $this->input->post('called_by'),
        'spoken_with' => $this->input->post('spoken_with'),
        'uploading_reason' => $this->input->post('uploading_reason'),
        'other_reason' => $this->input->post('other_reason'),
        'failure_reason' => $this->input->post('failure_reason'),
        'status' => $this->input->post('status'),
        'reason' => $this->input->post('reason'),
        'comment' => $this->input->post('comment'),
        'seller_type' => $this->input->post('seller_type'),
        'followUp_date' => $followUp_date,
        'followUp_time' => $followUp_time
      );

      // form_data array
      $formArray = array(
        'unique_id' => $uniqueId,
        'agent_id' => $userid,
        'assigned_work' => $this->input->post('assigned_work'),
        'seller_id' => $s_id,
        'seller_name' => $s_name,
        'seller_ph_no' => $s_ph_no,
        'tier' => $this->input->post('tier'),
        'vertical' => $this->input->post('vertical'),
        'request_id' => $this->input->post('request_id'),
        'feed_time' => $this->input->post('feed_time'),
        'rows_edited' => $this->input->post('rows_edited'),
        'rows_passed' => $this->input->post('rows_passed'),
        'rows_failed' => $this->input->post('rows_failed')
      );

      $seller = array(
        's_id' => $s_id,
        's_name' => $s_name,
        's_ph_no' => $s_ph_no,
      );
      // check seller is avilabel
      $sel = $this->agent_model->checkSeller($s_id);
      if(count($sel)>1){
        $this->db->where("s_id",$s_id);
        $this->db->update("seller", $seller);
      }else{
        $this->db->insert('seller',$seller);
      }

      // check unique id exists or not in form_data table
      $getStatus = checkFormDataRecord($uniqueId);
      if ($getStatus) {
        $this->agent_model->update($uniqueId,$formArray);
		$insert2 = $this->db->insert('request_history',$track);
		if ($insert2) {
			$this->session->set_flashdata('msg', 'Form data has been submitted successfully');
			redirect("form/$uniqueId");
		} else {
			$this->session->set_flashdata('msg', 'Something went wrong...Try again');
			redirect("form/$uniqueId");
		}
      }else{
        $insert1 =$this->db->insert('form_data',$formArray);
		$insert2 = $this->db->insert('request_history',$track);
		if ($insert2) {
			$this->session->set_flashdata('msg', 'Form data has been submitted successfully');
			redirect("form/$uniqueId");
		} else {
			$this->session->set_flashdata('msg', 'Something went wrong...Try again');
			redirect("form/$uniqueId");
		}
      }

    }
  }

  // summary function
    function summary(){
      $data['pageid'] = 'Summary';
      $this->form_validation->set_rules('fromDate','Start Date','required');
      $this->form_validation->set_rules('toDate','End Date','required');
      if ($this->form_validation->run() == false) {
          $this->load->view('agent/summary',$data);
      }else{
          $userid = $this->session->userdata('user_id');
          $from = $this->input->post('fromDate');
          $to = $this->input->post('toDate');
          $data['requestIds'] = getRequestIdUnderAgent($userid,$from,$to);
          $data['callback'] = getRequestIdByStatusWithDate($userid,$from,$to,'call back');
          $data['agreedToUpload'] = getRequestIdByStatusWithDate($userid,$from,$to,'call Back-Agreed to Upload');
          $data['disagreedToUpload'] = getRequestIdByStatusWithDate($userid,$from,$to,'Contacted-Disagree to Upload');
          $data['postCall'] = getRequestIdByStatusWithDate($userid,$from,$to,'Listing Uploaded-Post Call');
          $data['preCall'] = getRequestIdByStatusWithDate($userid,$from,$to,'Listing Uploaded-Pre Call');
          $data['notReachable'] = getRequestIdByStatusWithDate($userid,$from,$to,'Non Contactable/Not Reachable');
          $data['close'] = getRequestIdByStatusWithDate($userid,$from,$to,'close');
          $data['fromDate'] = $from;
          $data['toDate'] = $to;
          $data['agent_id'] = $userid;
          $this->load->view('agent/summary',$data);
      }
    }

    // summary ajax request
    function summaryDetail(){
      $from = $this->input->post('fromDate');
      $to = $this->input->post('toDate');
      $userid = $this->input->post('agent_id');
      $status = $this->input->post('status');
      if(empty($status)){
        $data['lists'] = getRequestIdUnderAgent($userid,$from,$to);
      }else{
        $data['lists'] = getRequestIdByStatusWithDate($userid,$from,$to,$status);
      }
      // $data['csrf_token'] = $this->security->get_csrf_hash();
      $data['status'] = $status;
      echo json_encode($data);
    }

    // view histrocial
    function viewHistorical(){
      $data['pageid'] = 'viewHistorical';
      $userid = $this->session->userdata('user_id');
      //validation
      $this->form_validation->set_rules('fromDate','Start Date','required');
      $this->form_validation->set_rules('toDate','End Date','required');
      if($this->form_validation->run()==false){
        $this->load->view('agent/view-historical',$data);
      }else{
          $from = $this->input->post('fromDate');
          $to = $this->input->post('toDate');
          $data['requestIdsUnderAgent'] = getRequestIdByStatusWithDate($userid,$from,$to);
          $this->load->view('agent/view-historical',$data);
      }
    }


    // write above
}

 ?>
