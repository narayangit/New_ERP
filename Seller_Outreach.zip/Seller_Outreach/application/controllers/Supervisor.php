<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Supervisor extends CI_Controller{

  function __construct(){
    parent::__construct();
    $this->load->model('supervisor_model');
    is_logged_in();
  }

  // dashboard
  function index(){
    $data['pageid'] = "supervisor";
    // $this->load->view('supervisor/index',$data);
	redirect('assign');
  }

  // download the sample file for uploading the bulk data
  function download($file_path = ""){
    	// load ci download helder
    	$this->load->helper('download');
    	// get download file path and store it in $data array
    	$download_file = $file_path;
    	// load view file
    	if(!empty($download_file))
    	{
    		//If you want to download an existing file from your server you'll need to read the file into a string
    		$data = file_get_contents(base_url("/download/".$download_file)); // Read the file's contents
    		$name = $download_file;
    		force_download($name, $data);
    	}
  }

  // dump data download
  function dumpDownload(){
    // validation
    $this->form_validation->set_rules('startDate','Starting Date','required');
    $this->form_validation->set_rules('endDate','Ending Date','required');
    // $this->form_validation->set_rules('agentName','Agent','required');
    if($this->form_validation->run() == false){
      $this->load->view('supervisor/data-upload',$data);
    }else{
		// get the filter data from form
		$from = $this->input->post('startDate');
		$to = $this->input->post('endDate');
		$seller_id = $this->input->post('seller_id');
		$request_id = $this->input->post('request_id');
		$agent_id = $this->input->post('agent_id');
		$status = $this->input->post('status');


      // load the excel library for generate the excel file
      $this->load->library('excel');
      // object for PHPExcel class
      $object = new PHPExcel();
      // set the default sheet index number
      $object->setActiveSheetIndex(0);
      // heading column name
      $table_columns = array('Enter Date','Assigneed Work','Called By','Catalog Handling','Catalog Handled Name','Catalog Handled Phone No','Seller id','Seller Name','Spoken with','Reason for not uploading earlier','For others please fill the Reason here','Seller contact number','Tier','Vertical','Request Id/Feed Id','Feed Uploaded At','Count of listings uploaded','Number of listings Passed','Number of listings failed','Failure reason','Status','If no then Reason','Comment','Seller\'s Types','Follow Up Date','Follow Up Time','Submit Date');
      $column = 0;
      // set the column heading in excel
      foreach ($table_columns as $field) {
        $object->getActiveSheet()->setCellValueByColumnAndRow($column,1,$field);
        $column++;
      }
      // fetch thd data from db
      $requestIdData = $this->supervisor_model->fetch_data($from,$to,$seller_id,$request_id,$agent_id,$status);

      // starting row for write data into excel sheet
      $excel_row = 2;
      // set the data into excel
      foreach($requestIdData as $row)
      {
		 $object->getActiveSheet()->setCellValueByColumnAndRow(0, $excel_row, $row->outcall_date);
         $object->getActiveSheet()->setCellValueByColumnAndRow(1, $excel_row, $row->assigned_work);
         $object->getActiveSheet()->setCellValueByColumnAndRow(2, $excel_row, $row->called_by);
		 $object->getActiveSheet()->setCellValueByColumnAndRow(3, $excel_row, $row->catalog_handling);
		 $object->getActiveSheet()->setCellValueByColumnAndRow(4, $excel_row, $row->catalog_name);
		 $object->getActiveSheet()->setCellValueByColumnAndRow(5, $excel_row, $row->catalog_ph_no);
		 $object->getActiveSheet()->setCellValueByColumnAndRow(6, $excel_row, $row->seller_id);
         $object->getActiveSheet()->setCellValueByColumnAndRow(7, $excel_row, $row->seller_name);
         $object->getActiveSheet()->setCellValueByColumnAndRow(8, $excel_row, $row->spoken_with);
         $object->getActiveSheet()->setCellValueByColumnAndRow(9, $excel_row, $row->uploading_reason);
         $object->getActiveSheet()->setCellValueByColumnAndRow(10, $excel_row, $row->other_reason);
         $object->getActiveSheet()->setCellValueByColumnAndRow(11, $excel_row, $row->seller_ph_no);
         $object->getActiveSheet()->setCellValueByColumnAndRow(12, $excel_row, $row->tier);
         $object->getActiveSheet()->setCellValueByColumnAndRow(13, $excel_row, $row->vertical);
         $object->getActiveSheet()->setCellValueByColumnAndRow(14, $excel_row, $row->request_id);
         $object->getActiveSheet()->setCellValueByColumnAndRow(15, $excel_row, $row->feed_time);
         $object->getActiveSheet()->setCellValueByColumnAndRow(16, $excel_row, $row->rows_edited);
         $object->getActiveSheet()->setCellValueByColumnAndRow(17, $excel_row, $row->rows_passed);
         $object->getActiveSheet()->setCellValueByColumnAndRow(18, $excel_row, $row->rows_failed);
         $object->getActiveSheet()->setCellValueByColumnAndRow(19, $excel_row, $row->failure_reason);
         $object->getActiveSheet()->setCellValueByColumnAndRow(20, $excel_row, $row->status);
         $object->getActiveSheet()->setCellValueByColumnAndRow(21, $excel_row, $row->reason);
         $object->getActiveSheet()->setCellValueByColumnAndRow(22, $excel_row, $row->comment);
         $object->getActiveSheet()->setCellValueByColumnAndRow(23, $excel_row, $row->seller_type);
         $object->getActiveSheet()->setCellValueByColumnAndRow(24, $excel_row, $row->followUp_date);
         $object->getActiveSheet()->setCellValueByColumnAndRow(25, $excel_row, $row->followUp_time);
         $object->getActiveSheet()->setCellValueByColumnAndRow(26, $excel_row, $row->submit_date);
         $excel_row++;
      }
      // this is for create the excel file
        $object_writer = PHPExcel_IOFactory::createWriter($object, 'Excel5');
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="Dump.xls"');
        $object_writer->save('php://output');
      }
  }


  // feed dump data download
  function feedDownload(){
	  $fileStatus = checkUploadedStatus('feed_data',date('Y-m-d'));
		$data['fileStatus'] = $fileStatus;
    // validation
    $this->form_validation->set_rules('startDate','Starting Date','required');
    $this->form_validation->set_rules('endDate','Ending Date','required');
    // $this->form_validation->set_rules('agentName','Agent','required');
    if($this->form_validation->run() == false){
      $this->load->view('supervisor/feed-upload',$data);
    }else{
		// get the filter data from form
		$from = $this->input->post('startDate');
		$to = $this->input->post('endDate');

      // load the excel library for generate the excel file
      $this->load->library('excel');
      // object for PHPExcel class
      $object = new PHPExcel();
      // set the default sheet index number
      $object->setActiveSheetIndex(0);
      // heading column name
      $table_columns = array('Timestamp','Date','Assigned worked','Called By','Seller ID','Tier','Vertical','Request Id/Feed Id','Count of Listings Uploaded','No Of Listings Passed','No Of Listings Failed','AV Failure Count','AV Failure Reason','Manual Failure Count','Manual Failure Reason',
              'Comments');
      $column = 0;
      // set the column heading in excel
      foreach ($table_columns as $field) {
        $object->getActiveSheet()->setCellValueByColumnAndRow($column,1,$field);
        $column++;
      }
      // fetch thd data from db
      $requestIdData = $this->supervisor_model->fetch_feed_data($from,$to);

      // starting row for write data into excel sheet
      $excel_row = 2;
      // set the data into excel
      foreach($requestIdData as $row)
      {
         $object->getActiveSheet()->setCellValueByColumnAndRow(0, $excel_row, $row->timestamp);
         $object->getActiveSheet()->setCellValueByColumnAndRow(1, $excel_row, $row->date);
         $object->getActiveSheet()->setCellValueByColumnAndRow(2, $excel_row, $row->assigned_worked);
         $object->getActiveSheet()->setCellValueByColumnAndRow(3, $excel_row, $row->called_by);
         $object->getActiveSheet()->setCellValueByColumnAndRow(4, $excel_row, $row->seller_id);
         $object->getActiveSheet()->setCellValueByColumnAndRow(5, $excel_row, $row->tier);
         $object->getActiveSheet()->setCellValueByColumnAndRow(6, $excel_row, $row->vertical);
         $object->getActiveSheet()->setCellValueByColumnAndRow(7, $excel_row, $row->request_id);
         $object->getActiveSheet()->setCellValueByColumnAndRow(8, $excel_row, $row->uploaded);
         $object->getActiveSheet()->setCellValueByColumnAndRow(9, $excel_row, $row->passed);
         $object->getActiveSheet()->setCellValueByColumnAndRow(10, $excel_row, $row->failed);
         $object->getActiveSheet()->setCellValueByColumnAndRow(11, $excel_row, $row->failure_count);
         $object->getActiveSheet()->setCellValueByColumnAndRow(12, $excel_row, $row->failure_reason);
         $object->getActiveSheet()->setCellValueByColumnAndRow(13, $excel_row, $row->man_failure_count);
         $object->getActiveSheet()->setCellValueByColumnAndRow(14, $excel_row, $row->man_failure_reason);
         $object->getActiveSheet()->setCellValueByColumnAndRow(15, $excel_row, $row->comments);
         $excel_row++;
      }
      // this is for create the excel file
        $object_writer = PHPExcel_IOFactory::createWriter($object, 'Excel5');
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="Feed-data.xls"');
        $object_writer->save('php://output');
      }
  }


  // Bulk data Upload
  function bulkUpload(){
    $data['pageid'] = "bulkUpload";
    // if file is alredy uploaded for current date then not uploading again
    $fileStatus = checkUploadedStatus('feed_data',date('Y-m-d'));
    $data['fileStatus'] = $fileStatus;
   $data['agentList'] = $this->supervisor_model->get_all_agent();
    // configuration for bulk sheet upload
    $configUpload['upload_path'] = './uploads/bulkUpload';
    $configUpload['allowed_types'] = 'csv';
    $configUpload['max_size'] = '5000';
    $this->load->library('upload',$configUpload);
    // check file format csv or not
    if( ! $this->upload->do_upload('csv_file')){
      $data['error'] = array('error' => $this->upload->display_errors());
      $this->load->view('supervisor/data-upload', $data);
    }else{
      if(is_uploaded_file($_FILES['csv_file']['tmp_name'])){
        // open the csv file with read only mode
        $csvFile = fopen($_FILES['csv_file']['tmp_name'],'r');
        // skip first line from csv file
        // if your csv file has no header then comment fgetcsv() function
        fgetcsv($csvFile);
        // read the data from csv file
        while(($line = fgetcsv($csvFile)) !== false){
          $arraydata = array(
            'unique_id' => uniqid(),
            'seller_id' => $line[0],
            'request_id'   => $line[1],
            'vertical'  => $line[2],
			'assigned_work' => $line[3],
            'feed_time' => $line[4],
            'rows_passed' => $line[5],
            'rows_failed' => $line[6],
            'rows_edited' => $line[7],
            'status' => 'Not Assign'
          );

          $this->db->insert('meta_data',$arraydata);
        }
        // close the file after insert data
        fclose($csvFile);
        $this->session->set_flashdata('msg', 'File uploaded successfully .');
        // delete the uploaded file from uploads folder
        $file =  $this->upload->data('full_path');
        unlink($file);
        redirect("bulkUpload",'refresh');
      }else{
        $this->session->set_flashdata('msg', 'Something Went Wrong file not uploaded.');
        redirect("bulkUpload",'refresh');
      }
      $this->load->view('supervisor/bulk_upload');
    }
  }

  //assign-reassign request id
  function assign(){
    $data['pageid'] = "assign";

// get the request id list form search date
    if($this->input->post('searchDate') != ""){
      $date = $this->input->post('searchDate');
    }else{
      $date = date('Y-m-d');
    }
    $data['searchDate'] = $date;
    // get the agent list under supervisor
    $data['agentList'] = $this->supervisor_model->get_all_agent();
    // get all request id
    $data['requestList'] = get_all_request($date);
    // check validation for agent and request ID
    $this->form_validation->set_rules('agentList','Agent List','required');
    $this->form_validation->set_rules('checkedRequest[]','Unique Id','required');
    // if validation is false then return to main page;
    if($this->form_validation->run() == false){
      $this->load->view('supervisor/data-assign',$data);
    }else{

      // agent id whose selected by supervisor
      $agentId = $this->input->post('agentList');
      // get the agent name from agent id
      $agentName = getAgentNameFromAgentId($agentId);
      $requestIdForAssign = $this->input->post('checkedRequest[]');
      foreach ($requestIdForAssign as $value) {
        $data = array(
          'agent_id' => $agentId,
          'agent_name' => $agentName,
          'assigned_date' => date('Y-m-d')
        );

        // get status from request id
        $status = getStatusOfUniqueId($value);
        if($status == "Not Assign"){
          $data['status'] = 'Assign';
        }else{
          $data['status'] = 'Re-Assign';
        }
        // assign the request id to agent
        $this->supervisor_model->update($value,$data);
      }

      $date = $this->input->post('searchDate');
      $requestList = get_all_request($date);
      echo json_encode($requestList);
    }
  }

  // all pending request id according date
  function pending(){
    $data['pageid'] = 'Pending';

    if($this->input->post('pendingDate')){
      $date = $this->input->post('pendingDate');
    }else{
      $date = date('Y-m-d');
    }
    $data['searchDate'] = $date;
    $data['requestList'] = get_all_pending_request($date);

    // get the agent list under supervisor
    $data['agentList'] = $this->supervisor_model->get_all_agent();
    // check validation for agent and request ID
    $this->form_validation->set_rules('agentList','Agent List','required');
    $this->form_validation->set_rules('checkedRequest[]','Unique Id','required');
    // if validation is false then return to main page;
    if($this->form_validation->run() == false){
      $this->load->view('supervisor/pending',$data);
    }else{
      // agent id whose selected by supervisor
      $agentId = $this->input->post('agentList');
      // get the agent name from agent id
      $agentName = getAgentNameFromAgentId($agentId);
      $requestIdForAssign = $this->input->post('checkedRequest[]');
      foreach ($requestIdForAssign as $value) {
        $data = array(
          'agent_id' => $agentId,
          'agent_name' => $agentName,
          'assigned_date' => date('Y-m-d')
        );

        // get status from request id
        $status = getStatusOfUniqueId($value);
        if($status == "Not Assign"){
          $data['status'] = 'Assign';
        }else{
          $data['status'] = 'Re-Assign';
        }
        // assign the request id to agent
        $this->supervisor_model->update($value,$data);
      }

      $date = $this->input->post('searchDate');
      $requestList = get_all_pending_request($date);
      echo json_encode($requestList);
    }

  }

  // see the agent list
  function agentView(){
    $data['pageid'] = "agentView";$this->form_validation->set_rules('fromDate','Start Date','required');
    $this->form_validation->set_rules('toDate','End Date','required');
    if ($this->form_validation->run() == false) {
        $this->load->view('supervisor/agent-info',$data);
    }else{
        $userid = $this->session->userdata('user_id');
        $from = $this->input->post('fromDate');
        $to = $this->input->post('toDate');
        $agentlist = $this->supervisor_model->get_all_agent();
        $dataArray = array();
        foreach ($agentlist as $value) {
          $array = array(
            'sellerContacted' => getTotalContacted('seller_id',$value['evaluator_name'],$from,$to),
            'requestContacted' => getTotalContacted('request_id',$value['evaluator_name'],$from,$to),
            'requestIds' => getRequestIdUnderAgent($value['user_id'],$from,$to),
            'callback' => getRequestIdByStatusWithDate($value['evaluator_name'],$from,$to,'call back'),
            'agreedToUpload' => getRequestIdByStatusWithDate($value['evaluator_name'],$from,$to,'call Back-Agreed to Upload'),
            'disagreedToUpload' => getRequestIdByStatusWithDate($value['evaluator_name'],$from,$to,'Contacted-Disagree to Upload'),
            'postCall' => getRequestIdByStatusWithDate($value['evaluator_name'],$from,$to,'Listing Uploaded-Post Call'),
            'preCall' => getRequestIdByStatusWithDate($value['evaluator_name'],$from,$to,'Listing Uploaded-Pre Call'),
            'notReachable' => getRequestIdByStatusWithDate($value['evaluator_name'],$from,$to,'Non Contactable/Not Reachable'),
            'noFollowUp' => getRequestIdByStatusWithDate($value['evaluator_name'],$from,$to,'No Follow UP required'),
            'close' => getRequestIdByStatusWithDate($value['evaluator_name'],$from,$to,'close'),
	          'workedUniqueId' =>$this->supervisor_model->getWorkedRequestIdUnderAgent($value['user_id'],$from,$to),
            'pendingUniqueId' => $this->supervisor_model->getPendingRequestIdUnderAgent($value['user_id'],$from,$to),
            'fromDate' => $from,
            'toDate' => $to,
            'agent_id' => $value['user_id'],
            'agent_name' => $value['evaluator_name']
          );
          array_push($dataArray,$array);
        }
        $data['agent_data'] = $dataArray;
        $this->load->view('supervisor/agent-info',$data);
    }
  }

  // summary ajax request
  function summaryDetail(){
    $from = $this->input->post('fromDate');
    $to = $this->input->post('toDate');
    $userid = $this->input->post('agent_id');
    $agentName = getAgentNameFromAgentId($userid);
    $status = $this->input->post('status');
	$data['status'] = $status;

    if(empty($status)){
      $data['lists'] = getRequestIdUnderAgent($userid,$from,$to);
    }else if($status == 'worked'){
		$data['lists'] = $this->supervisor_model->getWorkedRequestIdUnderAgent($userid,$from,$to);
	}else if($status == 'pending'){
		$data['lists'] = $this->supervisor_model->getPendingRequestIdUnderAgent($userid,$from,$to);
	}else{
      $data['lists'] = getRequestIdByStatusWithDate($agentName,$from,$to,$status);
    }
    $data['csrf_token'] = $this->security->get_csrf_hash();
    // $data['status'] = $status;
	// print_r()
    echo json_encode($data);
  }


  // all follow up request id's
  function followUp(){
	$data['pageid'] = 'followUp';
    $data['agentList'] = $this->supervisor_model->get_all_agent();
    if($this->input->post('fromDate') && $this->input->post('toDate')){
      $from = $this->input->post('fromDate');
      $to = $this->input->post('toDate');
    }else{
      $from = ''; $to = '';
    }
    $lists = $this->supervisor_model->getFollowUpRequestIdUnderAgent($from,$to);
	
	$followUpArr = array();
	foreach($lists as $value){
		if($value['status'] == 'call back'){
			$arr['unique_id'] = $value['unique_id'];
			$arr['request_id'] = $value['request_id'];
			$arr['seller_id'] = $value['seller_id'];
			$arr['vertical'] = $value['vertical'];
			$arr['called_by'] = $value['called_by'];
			$arr['assigned_to'] = getAgentNameFromUniqueId($value['unique_id']);
			$arr['followUp_date'] = $value['followUp_date'];
			$arr['followUp_time'] = $value['followUp_time'];
			$arr['status'] = $value['status'];
			array_push($followUpArr,$arr);
		}
	}
	
	$data['followUp'] = $followUpArr;
	$data['fromDate'] = $from;
	$data['toDate'] = $to;

    $this->form_validation->set_rules('agentList','Agent List','required');
    $this->form_validation->set_rules('checkedRequest[]','Unique Id','required');
	  if($this->form_validation->run() == false){
		$this->load->view('supervisor/follow-up',$data);
	  }else{
      // agent id whose selected by supervisor
      $agentId = $this->input->post('agentList');
      // get the agent name from agent id
      $agentName = getAgentNameFromAgentId($agentId);
      $requestIdForAssign = $this->input->post('checkedRequest[]');
      foreach ($requestIdForAssign as $value) {
        $data = array(
          'agent_id' => $agentId,
          'agent_name' => $agentName,
          'assigned_date' => date('Y-m-d')
        );

        // get status from request id
        $status = getStatusOfUniqueId($value);
        if($status == "Not Assign"){
          $data['status'] = 'Assign';
        }else{
          $data['status'] = 'Re-Assign';
        }
        // assign the request id to agent
        $this->supervisor_model->update($value,$data);
      }

		$from = $this->input->post('fromDate');
		$to = $this->input->post('toDate');

		$lists = $this->supervisor_model->getFollowUpRequestIdUnderAgent($from,$to);
		$followUpArr = array();
		foreach($lists as $value){
			if($value['status'] == 'call back'){
				$arr['unique_id'] = $value['unique_id'];
				$arr['request_id'] = $value['request_id'];
				$arr['seller_id'] = $value['seller_id'];
				$arr['vertical'] = $value['vertical'];
				$arr['called_by'] = $value['called_by'];
				$arr['assigned_to'] = getAgentNameFromUniqueId($value['unique_id']);
				$arr['followUp_date'] = $value['followUp_date'];
				$arr['followUp_time'] = $value['followUp_time'];
				$arr['status'] = $value['status'];
				array_push($followUpArr,$arr);
			}
		}
    echo json_encode($followUpArr);
		// $data['followUp'] = $followUpArr;
		// $this->load->view('supervisor/follow-up',$data);
	}

  }

  // feed upload data
  function feedUpload(){
    $data['pageid'] = 'feedUpload';
    // if file is alredy uploaded for current date then not uploading again
    $fileStatus = checkUploadedStatus('feed_data',date('Y-m-d'));
    $data['fileStatus'] = $fileStatus;
    // configuration for bulk sheet upload
    $configUpload['upload_path'] = './uploads/feedUpload';
    $configUpload['allowed_types'] = 'csv';
    $configUpload['max_size'] = '5000';
    $this->load->library('upload',$configUpload);
    // check file format csv or not
    if( ! $this->upload->do_upload('csv_file1')){
      $data['error'] = array('error' => $this->upload->display_errors());
      $this->load->view('supervisor/feed-upload',$data);
    }else{
      if(is_uploaded_file($_FILES['csv_file1']['tmp_name'])){
        // open the csv file with read only mode
        $csvFile = fopen($_FILES['csv_file1']['tmp_name'],'r');
        // skip first line from csv file
        // if your csv file has no header then comment fgetcsv() function
        fgetcsv($csvFile);
        // read the data from csv file
        while(($line = fgetcsv($csvFile)) !== false){
          $arraydata = array(
            'timestamp' => $line[0],
            'date'  => $line[1],
            'assigned_worked'  => $line[2],
            'called_by' => $line[3],
            'seller_id' => $line[4],
            'tier' => $line[5],
            'vertical' => $line[6],
            'request_id' => $line[7],
            'uploaded' => $line[8],
            'passed' => $line[9],
            'failed' => $line[10],
            'failure_count' => $line[11],
            'failure_reason' => $line[12],
            'man_failure_count' => $line[13],
            'man_failure_reason' => $line[14],
            'comments' => $line[15]
          );

          $this->db->insert('feed_data',$arraydata);
        }
        // close the file after insert data
        fclose($csvFile);
        $this->session->set_flashdata('msg', 'File uploaded successfully .');
        // delete the uploaded file from uploads folder
        $file =  $this->upload->data('full_path');
        unlink($file);
        redirect("feedUpload",'refresh');
      }else{
        $this->session->set_flashdata('msg', 'Something Went Wrong file not uploaded.');
        redirect("feedUpload",'refresh');
      }
    }

  }


  // generate data report
  function report(){
    $data['pageid'] = "report";

    if($this->input->post('fromDate') && $this->input->post('toDate')){
      $fromDate = $this->input->post('fromDate');
      $toDate = $this->input->post('toDate');
      // $currentDate = $toDate;
    }else{
      $fromDate = date('Y-m-d');
      $toDate = date('Y-m-d');

    }
    $currentDate = date('Y-m-d');
    $data['fromDate'] = $fromDate;
    $data['toDate'] = $toDate;
    $data['currentDate'] = $currentDate;
    $this->load->view('supervisor/report',$data);
  }








  //Write above
}

 ?>
