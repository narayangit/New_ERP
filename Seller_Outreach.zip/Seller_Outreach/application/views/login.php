<?php include(APPPATH.'views/common/head.php') ?>
	<body class="login-img">
		<!-- Header Background Animation-->
		<div id="canvas" class="gradient"></div>
		<div id="global-loader" ><div class="showbox"><div class="lds-ring"><div></div><div></div><div></div><div></div></div></div></div>
		<div class="page">
			<div class="page-single">
				<div class="container">
					<div class="row">
						<div class="col col-login mx-auto">
							<?php echo form_open('login',array('class' => 'card')) ?>
								<div class="card-body p-6">
									<div class="text-center mb-6">
										<img src="assets/images/brand/logo.png" class="h-6" alt="">
										<br>
										<?= $this->session->flashdata('msg'); ?>
									</div>
									<div class="card-title text-center">Login to your Account</div>
									<div class="form-group">
										<label class="form-label">Username</label>
										<input type="text" name="username" class="form-control" id="exampleInputEmail1"  placeholder="Enter username">
									</div>
									<div class="form-group">
										<label class="form-label">Password
											<!-- <a href="./forgot-password.html" class="float-right small">I forgot password</a> -->
										</label>
										<input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
									</div>
									<div class="form-group">
										<label class="form-label">User Type</label>
										<select class="form-control" name="userType">
											<option value="">Select</option>
											<option value="Agent">Agent</option>
											<option value="Supervisor">Supervisor</option>
										</select>
									</div>
									<!-- <div class="form-group">
										<label class="custom-control custom-checkbox">
											<input type="checkbox" class="custom-control-input" />
											<span class="custom-control-label">Remember me</span>
										</label>
									</div> -->
									<div class="form-footer">
										<button type="submit" class="btn btn-primary btn-block">Sign in</button>
									</div>
									<div class="text-center text-muted mt-3">
										Don't have account yet? <a href="./register.html">Sign up</a>
									</div>
								</div>

							</form>
						</div>
					</div>
				</div>
			</div>
		</div>


		<!-- Dashboard js -->
		<script src="<?=base_url()?>assets/js/vendors/jquery-3.2.1.min.js"></script>
		<script src="<?=base_url()?>assets/js/vendors/bootstrap.bundle.min.js"></script>
		<script src="<?=base_url()?>assets/js/vendors/jquery.sparkline.min.js"></script>
		<script src="<?=base_url()?>assets/js/vendors/selectize.min.js"></script>
		<script src="<?=base_url()?>assets/js/vendors/jquery.tablesorter.min.js"></script>
		<script src="<?=base_url()?>assets/js/vendors/circle-progress.min.js"></script>
		<script src="<?=base_url()?>assets/plugins/rating/jquery.rating-stars.js"></script>

		<!-- Custom scroll bar Js-->
		<script src="<?=base_url()?>assets/plugins/scroll-bar/jquery.mCustomScrollbar.concat.min.js"></script>

		<!-- 3Dlines-animation -->
        <script src="<?=base_url()?>assets/plugins/3Dlines-animation/three.min.js"></script>
        <script src="<?=base_url()?>assets/plugins/3Dlines-animation/projector.js"></script>
        <script src="<?=base_url()?>assets/plugins/3Dlines-animation/canvas-renderer.js"></script>
        <script src="<?=base_url()?>assets/plugins/3Dlines-animation/3d-lines-animation.js"></script>
        <script src="<?=base_url()?>assets/plugins/3Dlines-animation/color.js"></script>

		<!--Counters -->
		<script src="<?=base_url()?>assets/plugins/counters/counterup.min.js"></script>
		<script src="<?=base_url()?>assets/plugins/counters/waypoints.min.js"></script>

		<!-- custom js -->
		<script src="<?=base_url()?>assets/js/custom.js"></script>
				<script>
			var colors = new Array(
			[94,114,228],
			[130,94,228],
			[45,206,137],
			[45,206,204],
			[17,205,239],
			[17,113,239],
			[245,54,92],
			[245,96,54]);
		</script>
	</body>
</html>
