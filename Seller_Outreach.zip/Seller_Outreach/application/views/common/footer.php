<footer class="footer">
   <div class="container">
      <div class="row align-items-center flex-row-reverse">
         <div class="col-md-12 col-sm-12 mt-3 mt-lg-0 text-center">
            &copy; Copyrights 2018 All Rights Reserved by<a href="https://www.mattsenkumar.com/"> MattsenKumar LLC</a>.
            <br>
         </div>
      </div>
   </div>
</footer>
<!-- End Footer-->
</div>
</div>
</div>
<!-- Back to top -->
<a href="#top" id="back-to-top" style="display: inline;"><i class="fas fa-angle-up"></i></a>
<!-- Dashboard js -->
<script src="<?=base_url()?>assets/js/vendors/jquery-3.2.1.min.js"></script>
<script src="<?=base_url()?>assets/js/vendors/bootstrap.bundle.min.js"></script>
<script src="<?=base_url()?>assets/js/vendors/selectize.min.js"></script>
<script src="<?=base_url()?>assets/js/vendors/circle-progress.min.js"></script>
<script src="<?=base_url()?>assets/plugins/rating/jquery.rating-stars.js"></script>
<!-- Input Mask Plugin -->
<script src="<?=base_url()?>assets/plugins/input-mask/jquery.mask.min.js"></script>
<!-- Side menu js -->
<script src="<?=base_url()?>assets/plugins/toggle-sidebar/js/sidemenu.js"></script>
<!-- Custom scroll bar Js-->
<script src="<?=base_url()?>assets/plugins/scroll-bar/jquery.mCustomScrollbar.concat.min.js"></script>
<!-- c3.js Charts Plugin -->
<script src="<?=base_url()?>assets/plugins/charts-c3/d3.v5.min.js"></script>
<script src="<?=base_url()?>./assets/plugins/charts-c3/c3-chart.js"></script>
<!-- Data tables -->
<script src="<?=base_url()?>assets/plugins/datatable/jquery.dataTables.min.js"></script>
<script src="<?=base_url()?>assets/plugins/datatable/dataTables.bootstrap4.min.js"></script>
<!-- Select2 js -->
<script src="<?=base_url()?>assets/plugins/select2/select2.full.min.js"></script>
<!-- Timepicker js -->
<script src="<?=base_url()?>assets/plugins/time-picker/jquery.timepicker.js"></script>
<script src="<?=base_url()?>assets/plugins/time-picker/toggles.min.js"></script>
<!-- Datepicker js -->
<script src="<?=base_url()?>assets/plugins/date-picker/spectrum.js"></script>
<script src="<?=base_url()?>assets/plugins/date-picker/jquery-ui.js"></script>
<script src="<?=base_url()?>assets/plugins/input-mask/jquery.maskedinput.js"></script>
<!-- Vector Map -->
<script src="<?=base_url()?>assets/plugins/vector-map/jquery.vmap.js"></script>
<script src="<?=base_url()?>assets/plugins/vector-map/jquery.vmap.min.js"></script>
<script src="<?=base_url()?>assets/plugins/vector-map/jquery.vmap.sampledata.js"></script>
<script src="<?=base_url()?>assets/plugins/vector-map/country/jquery.vmap.world.js"></script>
<!--Counters -->
<script src="<?=base_url()?>assets/plugins/counters/counterup.min.js"></script>
<script src="<?=base_url()?>assets/plugins/counters/waypoints.min.js"></script>
<!-- 3Dlines-animation -->
<script src="<?=base_url()?>assets/plugins/3Dlines-animation/three.min.js"></script>
<script src="<?=base_url()?>assets/plugins/3Dlines-animation/projector.js"></script>
<script src="<?=base_url()?>assets/plugins/3Dlines-animation/canvas-renderer.js"></script>
<script src="<?=base_url()?>assets/plugins/3Dlines-animation/3d-lines-animation.js"></script>
<!-- Index Scripts -->
<script src="<?=base_url()?>assets/js/index.js"></script>
<script src="<?=base_url()?>assets/js/charts.js"></script>
<!--  Chart js -->
<script src="<?=base_url()?>assets/plugins/chart/Chart.bundle.js"></script>
<script src="<?=base_url()?>assets/plugins/chart/WidgetChart.js"></script>
<!-- Inline js -->
<script src="<?=base_url()?>assets/js/select2.js"></script>
<!-- Custom js -->
<script src="<?=base_url()?>assets/js/custom.js"></script>
<!-- Timepicker js cdn -->
<script src="<?=base_url()?>assets/js/bootstrap-timepicker.js"></script>
<!-- table2excel js -->
<script src="<?=base_url()?>assets/js/table2excel.js"></script>


<script>
   $(function(e) {
   	$('#example').DataTable({
      "lengthMenu": [ [10, 25, 50, -1], [10, 25, 50, "All"] ]
    });
   } );
</script>
<script>
   $(document).ready(function(){
       $("#add-btn").click(function(){
   				$('#hideForm,#hiddenForm').show();
   				var form = $('#newForm').clone();
   				$('#form-body').html(form);
       });

   		$('.timepicker').timepicker();
   });
</script>
</body>
</html>
