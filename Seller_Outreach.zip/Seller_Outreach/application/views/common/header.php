<body class="app sidebar-mini rtl">
   <div id="global-loader" >
      <div class="showbox">
         <div class="lds-ring">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
         </div>
      </div>
   </div>
   <div class="page">
   <div class="page-main">
   <!-- Navbar-->
   <header class="app-header header">
      <!-- Header Background Animation-->
      <div id="canvas" class="gradient"></div>
      <!-- Navbar Right Menu-->
      <div class="container-fluid">
         <div class="d-flex">
            <a class="header-brand" href="index.html">
            <img alt="ren logo" class="header-brand-img" src="<?=base_url()?>assets/images/brand/logo.png">
            </a>
            <a aria-label="Hide Sidebar" class="app-sidebar__toggle" data-toggle="sidebar" href="#"></a>
            <div class="d-flex order-lg-2 ml-auto">
               <div class="dropdown">
                  <a class="nav-link pr-0 leading-none d-flex" data-toggle="dropdown" href="#">
                  <span class="avatar avatar-md brround" style="background-image: url(<?=base_url()?>assets/images/faces/female/user.png)"></span>
                  <span class="ml-2 d-none d-lg-block">
                  <span class="text-white"><?= $this->session->userdata('username') ?></span>
                  </span>
                  </a>
                  <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                     <a class="dropdown-item" href="#"><i class="fas fa-user"></i> Profile</a>
                     <!-- <a class="dropdown-item" href="#"><i class="dropdown-icon mdi mdi-settings"></i> Settings</a>
                        <a class="dropdown-item" href="#"><span class="float-right"><span class="badge badge-primary">6</span></span> <i class="dropdown-icon mdi mdi-message-outline"></i> Inbox</a>
                        <a class="dropdown-item" href="#"><i class="dropdown-icon mdi mdi-comment-check-outline"></i> Message</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#"><i class="dropdown-icon mdi mdi-compass-outline"></i> Need help?</a> -->
                     <a class="dropdown-item" href="<?= base_url() ?>logout"><i class="fas fa-sign-out-alt"></i> Sign out</a>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </header>
   <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
   <aside class="app-sidebar">
      <div class="app-sidebar__user">
         <div class="dropdown">
            <a class="nav-link p-0 leading-none d-flex" data-toggle="dropdown" href="#">
            <span class="avatar avatar-md brround" style="background-image: url(<?=base_url()?>assets/images/faces/female/user.png)"></span>
            <span class="ml-2 "><span class="text-white app-sidebar__user-name font-weight-semibold"><?= $this->session->userdata('username') ?></span><br>
            <span class="text-muted app-sidebar__user-name text-sm"> <?= $this->session->userdata('level') ?></span>
            </span>
            </a>
            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
               <a class="dropdown-item" href="#"><i class="fas fa-user"></i> Profile</a>
               <!-- <a class="dropdown-item" href="#"><i class="dropdown-icon mdi mdi-settings"></i> Settings</a>
                  <a class="dropdown-item" href="#"><span class="float-right"><span class="badge badge-primary">6</span></span> <i class="dropdown-icon mdi mdi-message-outline"></i> Inbox</a>
                  <a class="dropdown-item" href="#"><i class="dropdown-icon mdi mdi-comment-check-outline"></i> Message</a>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="#"><i class="dropdown-icon mdi mdi-compass-outline"></i> Need help?</a> -->
               <a class="dropdown-item" href="<?= base_url() ?>logout"><i class="fas fa-sign-out-alt"></i> Sign out</a>
            </div>
         </div>
      </div>
      <ul class="side-menu">
         <?php if($this->session->userdata('level') == "agent"){ ?>
         <li>
            <a class="side-menu__item" href="<?= base_url() ?>agent"><i class="side-menu__icon fas fa-home"></i><span class="side-menu__label">Dashboard</span></a>
         </li>
         <li>
            <a class="side-menu__item" href="<?= base_url() ?>summary"><i class="side-menu__icon fas fa-file-alt"></i><span class="side-menu__label">Summary</span></a>
         </li>
         <li>
            <a class="side-menu__item" href="<?=base_url()?>historical"><i class="side-menu__icon fas fa-cubes"></i><span class="side-menu__label">Historical View</span></a>
         </li>
         <?php }else if($this->session->userdata('level') == "supervisor"){ ?>
		 <!--
         <li>
            <a class="side-menu__item" href="<?=base_url() ?>supervisor"><i class="side-menu__icon fas fa-home"></i><span class="side-menu__label">Dashboard</span></a>
         </li>
		 -->
         <li>
            <a class="side-menu__item" href="<?=base_url() ?>bulkUpload"><i class="side-menu__icon fas fa-upload"></i><span class="side-menu__label">Bulk Upload</span></a>
         </li>
         <li>
            <a class="side-menu__item" href="<?=base_url() ?>feedUpload"><i class="side-menu__icon fas fa-upload"></i><span class="side-menu__label">Feed Upload</span></a>
         </li>
         <li>
            <a class="side-menu__item" href="<?=base_url() ?>assign"><i class="side-menu__icon fas fas fa-table" ></i><span class="side-menu__label">Assign/Reassign</span></a>
         </li>
         <li>
            <a class="side-menu__item" href="<?=base_url() ?>agentView"><i class="side-menu__icon fas fa-info"></i> <span class="side-menu__label">Agent Infomation</span></a>
         </li>
		     <li>
            <a class="side-menu__item" href="<?=base_url() ?>pending"><i class="side-menu__icon fas fa-clock"></i> <span class="side-menu__label">Pending Id's</span></a>
         </li>
		     <li>
            <a class="side-menu__item" href="<?=base_url() ?>followUp"><i class="side-menu__icon fas fa-clock"></i> <span class="side-menu__label">Follow Up</span></a>
         </li>
         <li>
            <a class="side-menu__item" href="<?=base_url() ?>report"><i class="side-menu__icon fas fa-flag-checkered" ></i> <span class="side-menu__label">Report</span></a>
         </li>
         <?php } ?>
      </ul>
   </aside>
