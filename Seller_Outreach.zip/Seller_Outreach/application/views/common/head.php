<!doctype html>
<html lang="en" dir="ltr">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="msapplication-TileColor" content="#0061da">
      <meta name="theme-color" content="#1643a3">
      <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"/>
      <meta name="apple-mobile-web-app-capable" content="yes">
      <meta name="mobile-web-app-capable" content="yes">
      <meta name="HandheldFriendly" content="True">
      <meta name="MobileOptimized" content="320">
      <link rel="icon" href="favicon.ico" type="image/x-icon"/>
      <link rel="shortcut icon" type="image/x-icon" href="favicon.ico" />
      <!-- Title -->
      <title>Mattsen Kumar</title>
      <!--Font Awesome-->
      <link href="<?=base_url()?>assets/plugins/fontawesome-free/css/all.css" rel="stylesheet">
      <!-- Font family -->
      <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500" rel="stylesheet">
      <!-- Dashboard Css -->
      <link href="<?=base_url()?>assets/css/dashboard.css" rel="stylesheet" />
      <!-- vector-map -->
      <link href="<?=base_url()?>assets/plugins/vector-map/jqvmap.min.css" rel="stylesheet">
      <!-- Custom scroll bar css-->
      <link href="<?=base_url()?>assets/plugins/scroll-bar/jquery.mCustomScrollbar.css" rel="stylesheet" />
      <!-- Sidemenu Css -->
      <link href="<?=base_url()?>assets/plugins/toggle-sidebar/css/sidemenu.css" rel="stylesheet">
      <!-- c3.js Charts Plugin -->
      <link href="<?=base_url()?>assets/plugins/charts-c3/c3-chart.css" rel="stylesheet" />
      <link href="<?=base_url()?>assets/plugins/morris/morris.css" rel="stylesheet" />
      <!-- Data table css -->
      <link href="<?=base_url()?>assets/plugins/datatable/dataTables.bootstrap4.min.css" rel="stylesheet" />
      <!-- Slect2 css -->
      <link href="<?=base_url()?>assets/plugins/select2/select2.min.css" rel="stylesheet" />
      <!-- Time picker Plugin -->
      <link href="<?=base_url()?>assets/plugins/time-picker/jquery.timepicker.css" rel="stylesheet" />
      <!-- Date Picker Plugin -->
      <link href="<?=base_url()?>assets/plugins/date-picker/spectrum.css" rel="stylesheet" />
      <!---Font icons-->
      <link href="<?=base_url()?>assets/plugins/iconfonts/plugin.css" rel="stylesheet" />
      <link href="<?=base_url()?>assets/css/mystyle.css" rel="stylesheet" />
      <!-- Timepicker  -->
      <link href="<?=base_url()?>assets/css/bootstrap-timepicker.css" rel="stylesheet" />
   </head>
