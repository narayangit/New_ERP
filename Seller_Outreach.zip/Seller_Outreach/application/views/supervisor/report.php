<?php include(APPPATH.'views/common/head.php') ?>
<?php include(APPPATH.'views/common/header.php') ?>
<div class="app-content my-3 my-md-5">
   <div class="side-app">
      <div class="page-header">
         <h4 class="page-title">Reports</h4>
         <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Supervisor</a></li>
            <li class="breadcrumb-item active" aria-current="page">Report</li>
         </ol>
      </div>
      <div class="">
         <?php echo form_open('',array('class'=>'card')) ?>
         <div class="card-status bg-yellow br-tr-3 br-tl-3"></div>
         <div class="card-header">
            <h3 class="card-title">Select date for generate report</h3>
         </div>
         <div class="card-body">
            <div class="row">
               <div class="col-md-4">
                  <div class="form-group">
                     <div class="input-group">
                        <div class="input-group-prepend">
                           <div class="input-group-text">
                              <i class="fas fa-calendar tx-16 lh-0 op-6"></i>
                           </div>
                        </div>
                        <input class="form-control fc-datepicker" placeholder="MM/DD/YYYY" id="fromDate" name="fromDate" value=<?= $fromDate ?> type="text" autocomplete="off">
                     </div>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="form-group">
                     <div class="input-group">
                        <div class="input-group-prepend">
                           <div class="input-group-text">
                              <i class="fas fa-calendar tx-16 lh-0 op-6"></i>
                           </div>
                        </div>
                        <input class="form-control fc-datepicker" placeholder="MM/DD/YYYY" id="toDate" name="toDate" value=<?= $toDate ?> type="text" autocomplete="off">
                     </div>
                  </div>
               </div>
               <div class="col-md-2">
                  <button type="submit" class="btn btn-primary">Search</button>
               </div>
               </form>
            </div>
         </div>
      </div>
      <div class="row">
         <div class="col-md-12 col-lg-12">
           <div class="card">
              <div class="card-status bg-yellow br-tr-3 br-tl-3"></div>
              <div>
                <!-- <input type="button" onclick="exportTableToExcel('daily-report','daily-report')" id="export-excel" class="btn btn-primary btn-sm"> -->
                <!-- <i class="fa fa-file-excel" aria-hidden="true"></i> -->
                <i class="far fa-file-excel" id="exportReportBtn" style="font-size:30px; color:green; float:right; padding:10px"></i>
              </div>
              <div id="daily-report" style="padding:20px;">
                <h4 style="text-align:center">Daily Report</h4>
                <table   border="1" style="text-align:center">
                <thead>
                  <tr style='background:skyblue'>
                    <th rowspan='2'>Metric</th>
                    <th colspan="2">TOP 10 defaulters</th>
                    <th colspan="2">MPQC</th>
                    <th colspan="2">FMCG</th>
                    <th colspan="2">L2 Sellers</th>
                    <th colspan="2">Women's Clothing</th>
                    <th colspan="2"><?= $fromDate." to ". $toDate  ?> (Total)</th>
                    <th colspan="2">MTD</th>
                  </tr>
                  <tr style='background:blue'>
                    <th>Seller Wise</th>
                    <th>Feed Wise</th>
                    <th>Seller Wise</th>
                    <th>Feed Wise</th>
                    <th>Seller Wise</th>
                    <th>Feed Wise</th>
                    <th>Seller Wise</th>
                    <th>Feed Wise</th>
                    <th>Seller Wise</th>
                    <th>Feed Wise</th>
                    <th>Seller Wise</th>
                    <th>Feed Wise</th>
                    <th>Seller Wise</th>
                    <th>Feed Wise</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Total Count</td>
                    <td><?= getCountSellerWise($fromDate,$toDate,'Top 10 Defaulters') ?></td>
                    <td><?= getCountRequestWise($fromDate,$toDate,'Top 10 Defaulters') ?></td>
                    <td><?= getCountSellerWise($fromDate,$toDate,'MPQC') ?></td>
                    <td><?= getCountRequestWise($fromDate,$toDate,'MPQC') ?></td>
                    <td><?= getCountSellerWise($fromDate,$toDate,'FMCG') ?></td>
                    <td><?= getCountRequestWise($fromDate,$toDate,'FMCG') ?></td>
                    <td><?= getCountSellerWise($fromDate,$toDate,'L2 Seller') ?></td>
                    <td><?= getCountRequestWise($fromDate,$toDate,'L2 Seller') ?></td>
                    <td><?= getCountSellerWise($fromDate,$toDate,'Womens Clothing') ?></td>
                    <td><?= getCountRequestWise($fromDate,$toDate,'Womens Clothing') ?></td>
                    <th><?= getCountByDate($fromDate,$toDate,'seller_id') ?></th>
                    <th><?= getCountByDate($fromDate,$toDate,'request_id') ?></th>
                    <th><?= getTotalCountByDate($currentDate,'seller_id') ?></th>
                    <th><?= getTotalCountByDate($currentDate,'request_id') ?></th>
                  </tr>
                  <tr>
                    <td>Agreed to Upload</td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'Top 10 Defaulters','call Back-Agreed to Upload') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'Top 10 Defaulters','call Back-Agreed to Upload') ?></td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'MPQC','call Back-Agreed to Upload') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'MPQC','call Back-Agreed to Upload') ?></td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'FMCG','call Back-Agreed to Upload') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'FMCG','call Back-Agreed to Upload') ?></td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'L2 Seller','call Back-Agreed to Upload') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'L2 Seller','call Back-Agreed to Upload') ?></td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'Womens Clothing','call Back-Agreed to Upload') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'Womens Clothing','call Back-Agreed to Upload') ?></td>
                    <td><?= getCountForSingleDateWithStatus($fromDate,$toDate,'call Back-Agreed to Upload','seller_id') ?></td>
                    <td><?= getCountForSingleDateWithStatus($fromDate,$toDate,'call Back-Agreed to Upload','request_id') ?></td>
                    <td><?= getTotalCountWithStatus($currentDate,'call Back-Agreed to Upload','seller_id') ?></td>
                    <td><?= getTotalCountWithStatus($currentDate,'call Back-Agreed to Upload','request_id') ?></td>
                  </tr>
                  <tr>
                    <td>Rejected to Upload</td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'Top 10 Defaulters','Contacted-Disagree to Upload') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'Top 10 Defaulters','Contacted-Disagree to Upload') ?></td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'MPQC','Contacted-Disagree to Upload') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'MPQC','Contacted-Disagree to Upload') ?></td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'FMCG','Contacted-Disagree to Upload') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'FMCG','Contacted-Disagree to Upload') ?></td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'L2 Seller','Contacted-Disagree to Upload') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'L2 Seller','Contacted-Disagree to Upload') ?></td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'Womens Clothing','Contacted-Disagree to Upload') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'Womens Clothing','Contacted-Disagree to Upload') ?></td>
                    <td><?= getCountForSingleDateWithStatus($fromDate,$toDate,'Contacted-Disagree to Upload','seller_id') ?></td>
                    <td><?= getCountForSingleDateWithStatus($fromDate,$toDate,'Contacted-Disagree to Upload','request_id') ?></td>
                    <td><?= getTotalCountWithStatus($currentDate,'Contacted-Disagree to Upload','seller_id') ?></td>
                    <td><?= getTotalCountWithStatus($currentDate,'Contacted-Disagree to Upload','request_id') ?></td>
                  </tr>
                  <tr>
                    <td>Asked for a Call back</td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'Top 10 Defaulters','call back') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'Top 10 Defaulters','call back') ?></td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'MPQC','call back') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'MPQC','call back') ?></td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'FMCG','call back') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'FMCG','call back') ?></td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'L2 Seller','call back') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'L2 Seller','call back') ?></td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'Womens Clothing','call back') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'Womens Clothing','call back') ?></td>
                    <td><?= getCountForSingleDateWithStatus($fromDate,$toDate,'call back','seller_id') ?></td>
                    <td><?= getCountForSingleDateWithStatus($fromDate,$toDate,'call back','request_id') ?></td>
                    <td><?= getTotalCountWithStatus($currentDate,'call back','seller_id') ?></td>
                    <td><?= getTotalCountWithStatus($currentDate,'call back','request_id') ?></td>
                  </tr>
                  <tr>
                    <td>Uploaded Post Calling</td>
                    <td><?= getCountForPostCall($fromDate,$toDate,'Top 10 Defaulters','seller_id') ?></td>
                    <td><?= getCountForPostCall($fromDate,$toDate,'Top 10 Defaulters','request_id') ?></td>
                    <td><?= getCountForPostCall($fromDate,$toDate,'MPQC','seller_id') ?></td>
                    <td><?= getCountForPostCall($fromDate,$toDate,'MPQC','request_id') ?></td>
                    <td><?= getCountForPostCall($fromDate,$toDate,'FMCG','seller_id') ?></td>
                    <td><?= getCountForPostCall($fromDate,$toDate,'FMCG','request_id') ?></td>
                    <td><?= getCountForPostCall($fromDate,$toDate,'L2 Seller','seller_id') ?></td>
                    <td><?= getCountForPostCall($fromDate,$toDate,'L2 Seller','request_id') ?></td>
                    <td><?= getCountForPostCall($fromDate,$toDate,'Womens Clothing','seller_id') ?></td>
                    <td><?= getCountForPostCall($fromDate,$toDate,'Womens Clothing','request_id') ?></td>
                    <td><?= getCountForSingleDateForPostCall($fromDate,$toDate,'seller_id') ?></td>
                    <td><?= getCountForSingleDateForPostCall($fromDate,$toDate,'request_id') ?></td>
                    <td><?= getTotalCountForPostCall($currentDate,'seller_id') ?></td>
                    <td><?= getTotalCountForPostCall($currentDate,'request_id') ?></td>
                  </tr>
                  <tr>
                    <td>Uploaded Pre Calling</td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'Top 10 Defaulters','Listing Uploaded-Pre Call') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'Top 10 Defaulters','Listing Uploaded-Pre Call') ?></td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'MPQC','Listing Uploaded-Pre Call') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'MPQC','Listing Uploaded-Pre Call') ?></td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'FMCG','Listing Uploaded-Pre Call') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'FMCG','Listing Uploaded-Pre Call') ?></td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'L2 Seller','Listing Uploaded-Pre Call') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'L2 Seller','Listing Uploaded-Pre Call') ?></td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'Womens Clothing','Listing Uploaded-Pre Call') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'Womens Clothing','Listing Uploaded-Pre Call') ?></td>
                    <td><?= getCountForSingleDateWithStatus($fromDate,$toDate,'Listing Uploaded-Pre Call','seller_id') ?></td>
                    <td><?= getCountForSingleDateWithStatus($fromDate,$toDate,'Listing Uploaded-Pre Call','request_id') ?></td>
                    <td><?= getTotalCountWithStatus($currentDate,'Listing Uploaded-Pre Call','seller_id') ?></td>
                    <td><?= getTotalCountWithStatus($currentDate,'Listing Uploaded-Pre Call','request_id') ?></td>
                  </tr>
                  <tr>
                    <td>Not Contactable</td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'Top 10 Defaulters','Non Contactable/Not Reachable') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'Top 10 Defaulters','Non Contactable/Not Reachable') ?></td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'MPQC','Non Contactable/Not Reachable') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'MPQC','Non Contactable/Not Reachable') ?></td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'FMCG','Non Contactable/Not Reachable') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'FMCG','Non Contactable/Not Reachable') ?></td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'L2 Seller','Non Contactable/Not Reachable') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'L2 Seller','Non Contactable/Not Reachable') ?></td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'Womens Clothing','Non Contactable/Not Reachable') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'Womens Clothing','Non Contactable/Not Reachable') ?></td>
                    <td><?= getCountForSingleDateWithStatus($fromDate,$toDate,'Non Contactable/Not Reachable','seller_id') ?></td>
                    <td><?= getCountForSingleDateWithStatus($fromDate,$toDate,'Non Contactable/Not Reachable','request_id') ?></td>
                    <td><?= getTotalCountWithStatus($currentDate,'Non Contactable/Not Reachable','seller_id') ?></td>
                    <td><?= getTotalCountWithStatus($currentDate,'Non Contactable/Not Reachable','request_id') ?></td>
                  </tr>
                  <tr>
                    <td>No Follow UP required</td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'Top 10 Defaulters','No Follow UP required') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'Top 10 Defaulters','No Follow UP required') ?></td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'MPQC','No Follow UP required') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'MPQC','No Follow UP required') ?></td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'FMCG','No Follow UP required') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'FMCG','No Follow UP required') ?></td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'L2 Seller','No Follow UP required') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'L2 Seller','No Follow UP required') ?></td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'Womens Clothing','No Follow UP required') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'Womens Clothing','No Follow UP required') ?></td>
                    <td><?= getCountForSingleDateWithStatus($fromDate,$toDate,'No Follow UP required','seller_id') ?></td>
                    <td><?= getCountForSingleDateWithStatus($fromDate,$toDate,'No Follow UP required','request_id') ?></td>
                    <td><?= getTotalCountWithStatus($currentDate,'No Follow UP required','seller_id') ?></td>
                    <td><?= getTotalCountWithStatus($currentDate,'No Follow UP required','request_id') ?></td>
                  </tr>
                  <tr>
                    <td>Close</td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'Top 10 Defaulters','Close') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'Top 10 Defaulters','Close') ?></td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'MPQC','Close') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'MPQC','Close') ?></td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'FMCG','Close') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'FMCG','Close') ?></td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'L2 Seller','Close') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'L2 Seller','Close') ?></td>
                    <td><?= getCountSellerWiseWithStatus($fromDate,$toDate,'Womens Clothing','Close') ?></td>
                    <td><?= getCountRequestWiseWithStatus($fromDate,$toDate,'Womens Clothing','Close') ?></td>
                    <td><?= getCountForSingleDateWithStatus($fromDate,$toDate,'Close','seller_id') ?></td>
                    <td><?= getCountForSingleDateWithStatus($fromDate,$toDate,'Close','request_id') ?></td>
                    <td><?= getTotalCountWithStatus($currentDate,'Close','seller_id') ?></td>
                    <td><?= getTotalCountWithStatus($currentDate,'Close','request_id') ?></td>
                  </tr>
                  <?php
                    // feed uploaded
                    $top_10_uploaded = totalUploadingFeed($fromDate,$toDate,'Top 10 Defaulters');
                    $mpqc_uploaded = totalUploadingFeed($fromDate,$toDate,'MPQC');
                    $fmcg_uploaded = totalUploadingFeed($fromDate,$toDate,'FMCG');
                    $l2_seller_uploaded = totalUploadingFeed($fromDate,$toDate,'L2 Seller');
                    $womens_clothing_uploaded = totalUploadingFeed($fromDate,$toDate,'Women\'s Clothing');
                    $total_uploaded = totalUploadingFeedByDate($fromDate,$toDate);
                    $grand_uploaded = totalCountOfUploadingFeed($currentDate);
                    // feed passed
                    $top_10_passed = totalPassedFeed($fromDate,$toDate,'Top 10 Defaulters');
                    $mpqc_passed = totalPassedFeed($fromDate,$toDate,'MPQC');
                    $fmcg_passed = totalPassedFeed($fromDate,$toDate,'FMCG');
                    $l2_seller_passed = totalPassedFeed($fromDate,$toDate,'L2 Seller');
                    $womens_clothing_passed = totalPassedFeed($fromDate,$toDate,'Women\'s Clothing');
                    $total_passed = totalPassedFeedByDate($fromDate,$toDate);
                    $grand_passed = totalCountOfPassedFeed($currentDate);
                   ?>
                  <tr>
                    <td>Listings Uploaded</td>
                    <td colspan="2"><?= $top_10_uploaded ?></td>
                    <td colspan="2"><?= $mpqc_uploaded ?></td>
                    <td colspan="2"><?= $fmcg_uploaded ?></td>
                    <td colspan="2"><?= $l2_seller_uploaded ?></td>
                    <td colspan="2"><?= $womens_clothing_uploaded ?></td>
                    <td colspan="2"><?= $total_uploaded ?></td>
                    <td colspan="2"><?= $grand_uploaded ?></td>
                  </tr>
                  <tr>
                    <td>Listings removed/Under processing</td>
                    <td colspan="2">0</td>
                    <td colspan="2">0</td>
                    <td colspan="2">0</td>
                    <td colspan="2">0</td>
                    <td colspan="2">0</td>
                    <td colspan="2">0</td>
                    <td colspan="2">0</td>
                  </tr>
                  <tr>
                    <td>Listings Passed</td>
                    <td colspan="2"><?= $top_10_passed ?></td>
                    <td colspan="2"><?= $mpqc_passed ?></td>
                    <td colspan="2"><?= $fmcg_passed ?></td>
                    <td colspan="2"><?= $l2_seller_passed ?></td>
                    <td colspan="2"><?= $womens_clothing_passed ?></td>
                    <td colspan="2"><?= $total_passed ?></td>
                    <td colspan="2"><?= $grand_passed ?></td>
                  </tr>
                  <tr>
                    <td>Pass %</td>
                    <td colspan="2"><?= ($top_10_uploaded!=0)? round($top_10_passed/$top_10_uploaded*100,2) :'0'; ?>%</td>
                    <td colspan="2"><?= ($mpqc_uploaded!=0)? round($mpqc_passed/$mpqc_uploaded*100,2) :'0'; ?>%</td>
                    <td colspan="2"><?= ($fmcg_uploaded!=0)? round($fmcg_passed/$fmcg_uploaded*100,2) :'0'; ?>%</td>
                    <td colspan="2"><?= ($l2_seller_uploaded!=0)? round($l2_seller_passed/$l2_seller_uploaded*100,2) :'0'; ?>%</td>
                    <td colspan="2"><?= ($womens_clothing_uploaded!=0)? round($womens_clothing_passed/$womens_clothing_uploaded*100,2) :'0'; ?>%</td>
                    <td colspan="2"><?= ($total_uploaded!=0)? round($total_passed/$total_uploaded*100,2) :'0'; ?>%</td>
                    <td colspan="2"><?= ($grand_uploaded!=0)? round($grand_passed/$grand_uploaded*100,2) :'0'; ?>%</td>
                  </tr>
                  <tr>
                    <td colspan='15'>
                      <center><h6>Note:  Listings under processing*  and removed feeds have been excluded while calculating  pass%</h6></center>
                    </td>
                  </tr>
                </tbody>
              </table>
              </div>
            </div>
        </div>
      </div>
   </div>
</div>
<?php include(APPPATH.'views/common/footer.php') ?>
<script>

$(function(){
  $('#exportReportBtn').click(function(){
    $("#daily-report").table2excel({
      exclude: ".noExl",
      name: "report1",
      filename: "Report" + new Date().toISOString().replace(/[\-\:\.]/g, ""),
      fileext: ".xls",
      exclude_img: true,
      exclude_links: true,
      exclude_inputs: true

    });
  })
})

</script>
