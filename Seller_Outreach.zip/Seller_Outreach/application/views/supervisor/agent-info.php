<?php include(APPPATH.'views/common/head.php') ?>
<?php include(APPPATH.'views/common/header.php') ?>
<div class="app-content my-3 my-md-5">
   <div class="side-app">
      <div class="page-header">
         <h4 class="page-title">Agent Details</h4>
         <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Supervisor</a></li>
            <li class="breadcrumb-item active" aria-current="page">Agent Details</li>
         </ol>
      </div>
      <div class="row">
         <div class="col-md-12 col-lg-12">
            <?php echo form_open(); ?>
            <div class="card">
            <div class="card-status bg-yellow br-tr-3 br-tl-3"></div>
               <div class="card-header">
                  <div class="card-title">Select Date</div>
               </div>
               <div class="row">
                  <div class="col-lg-5">
                     <div class="card-body">
                        <div class="wd-200 mg-b-30">
                           <div class="input-group">
                              <div class="input-group-prepend">
                                 <div class="input-group-text"><i class="fas fa-calendar tx-16 lh-0 op-6"></i></div>
                              </div>
                              <input class="form-control fc-datepicker" name="fromDate" placeholder="MM/DD/YYYY" type="text" autocomplete="off">
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-5">
                     <div class="card-body">
                        <div class="wd-200 mg-b-30">
                           <div class="input-group">
                              <div class="input-group-prepend">
                                 <div class="input-group-text"><i class="fas fa-calendar tx-16 lh-0 op-6"></i></div>
                              </div>
                              <input class="form-control fc-datepicker" name="toDate" placeholder="MM/DD/YYYY" type="text" autocomplete="off">
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-2">
                     <div class="card-body">
                        <button type="submit" class="btn btn-primary">Submit</button>
                     </div>
                  </div>
               </div>
            </div>
            </form>
            <?php if (isset($agent_data)):?>
            <div class="card">
               <div class="card-status bg-yellow br-tr-3 br-tl-3"></div>
               <div class="card-header">
                  <div class="card-title">List of Agent Details </div>
                    <i class="far fa-file-excel" id="exportAgentDetailsbtn" style="font-size:30px; color:green; margin-left:80%;padding:10px"></i>
               </div>
               <div class="card-body">
                  <div class="table-responsive" id="agentInformation">
                     <table id="example" class="table table-striped table-bordered" style="width:100%">
                        <thead>
                           <tr>
                              <th class="wd-15p">Agent Name</th>
                              <th class="wd-15p">Assign</th>
                              <!-- <th class="wd-15p">Seller contacted</th> -->
                              <!-- <th class="wd-15p">Feed contacted</th> -->
                              <th class="wd-15p">Call Back</th>
                              <th class="wd-15p">call Back-Agreed to Upload</th>
                              <th class="wd-20p">Contacted-Disagree to Upload</th>
                              <th class="wd-15p">Listing Uploaded-Post Call</th>
                              <th class="wd-10p">Listing Uploaded-Pre Call</th>
                              <th class="wd-25p">Non contactable/Not Reachable</th>
                              <th class="wd-25p">No Follow UP required</th>
                              <th class="wd-25p">Close</th>
                              <th class="wd-25p">Worked</th>
                              <th class="wd-25p">Pending</th>
                              <th class="wd-25p">Sum of Attempt</th>

                           </tr>
                        </thead>
                        <tbody>

                           <?php foreach ($agent_data as $value): ?>
                           <tr>
                              <td><?= $value['agent_name']; ?></td>
                              <!-- <td> <a href="javascript:void(0)"><?= count($value['sellerContacted']) ?></a> </td> -->
                              <!-- <td> <a href="javascript:void(0)"><?= count($value['requestContacted']) ?></a> </td> -->
                              <td><a href="javascript:void(0)" onclick="assignList('<?=$value["fromDate"]?>','<?=$value["toDate"]?>','<?=$value["agent_id"] ?>')"> <?= count($value['requestIds']) ?></a></td>
                              <td><a href="javascript:void(0)" onclick="assignList('<?=$value["fromDate"]?>','<?=$value["toDate"]?>','<?=$value["agent_id"] ?>','call back')"> <?= count($value['callback']) ?></a></td>
                              <td><a href="javascript:void(0)" onclick="assignList('<?=$value["fromDate"]?>','<?=$value["toDate"]?>','<?=$value["agent_id"] ?>','call Back-Agreed to Upload')"> <?= count($value['agreedToUpload']) ?></a></td>
                              <td><a href="javascript:void(0)" onclick="assignList('<?=$value["fromDate"]?>','<?=$value["toDate"]?>','<?=$value["agent_id"] ?>','Contacted-Disagree to Upload')"> <?= count($value['disagreedToUpload']) ?></a></td>
                              <td><a href="javascript:void(0)" onclick="assignList('<?=$value["fromDate"]?>','<?=$value["toDate"]?>','<?=$value["agent_id"] ?>','Listing Uploaded-Post Call')"> <?= count($value['postCall']) ?></a></td>
                              <td><a href="javascript:void(0)" onclick="assignList('<?=$value["fromDate"]?>','<?=$value["toDate"]?>','<?=$value["agent_id"] ?>','Listing Uploaded-Pre Call')"> <?= count($value['preCall']) ?></a></td>
                              <td><a href="javascript:void(0)" onclick="assignList('<?=$value["fromDate"]?>','<?=$value["toDate"]?>','<?=$value["agent_id"] ?>','Non Contatable/Not Reachable')"> <?= count($value['notReachable']) ?></a></td>
                              <td><a href="javascript:void(0)" onclick="assignList('<?=$value["fromDate"]?>','<?=$value["toDate"]?>','<?=$value["agent_id"] ?>','No Follow UP required')"> <?= count($value['noFollowUp']) ?></a></td>
                              <td><a href="javascript:void(0)" onclick="assignList('<?=$value["fromDate"]?>','<?=$value["toDate"]?>','<?=$value["agent_id"] ?>','close')"> <?= count($value['close']) ?></a></td>
              							  <td><a href="javascript:void(0)" onclick="assignList('<?=$value["fromDate"]?>','<?=$value["toDate"]?>','<?=$value["agent_id"] ?>','worked')"> <?= count($value['workedUniqueId']) ?></a></td>
              							  <td><a href="javascript:void(0)" onclick="assignList('<?=$value["fromDate"]?>','<?=$value["toDate"]?>','<?=$value["agent_id"] ?>','pending')"> <?= count($value['pendingUniqueId']) ?></a></td>
              							  <?php $sum = count($value['callback']) + count($value['agreedToUpload']) + count($value['disagreedToUpload']) + count($value['postCall']) + count($value['preCall']) + count($value['notReachable']) + count($value['noFollowUp']) + count($value['close']);
              							  ?>
              							  <td><a href="javascript:void(0)"> <?= $sum ?></a></td>
                           </tr>
                           <?php endforeach; ?>
                        </tbody>
                     </table>
                  </div>
               </div>
               <!-- table-wrapper -->
            </div>
            <!-- section-wrapper -->
            <?php endif; ?>
            <!-- details of request ids   -->
            <div class="card" id="list-table" style="display:none">
               <div class="card-status bg-yellow br-tr-3 br-tl-3"></div>
               <div class="card-header">
                  <div class="card-title">List of Agent Details</div>
               </div>
               <div class="card-body">
                  <div class="table-responsive">
                     <table id="example" class="table table-striped table-bordered" style="width:100%">
                        <thead>
                           <tr>
                              <th class="wd-15p">Request Id</th>
                              <th class="wd-15p">Seller Id</th>
                              <th class="wd-15p">Vertical</th>
                              <th class="wd-20p">Status</th>
                           </tr>
                        </thead>
                        <tbody id="ajax-data">
                        </tbody>
                     </table>
                  </div>
               </div>
               <!-- table-wrapper -->
            </div>
         </div>
      </div>
   </div>
</div>
<?php include(APPPATH.'views/common/footer.php') ?>
<script type="text/javascript">
   // var csrf_token = '<?= $this->security->get_csrf_hash() ?>';
   	function assignList(from,to,agent,status){
   		// console.log(from,to,agent);
   		$.ajax({
   			url : '<?=base_url()?>supervisor/summaryDetail',
   			type: 'POST',
   			dataType: 'JSON',
   			// data:{ '<?= $this->security->get_csrf_token_name() ?>':csrf_token,fromDate:from,toDate:to,agent_id:agent,status:status },
   			data:{ fromDate:from,toDate:to,agent_id:agent,status:status },
   			success:function(e){
   				console.log(e);
   				// csrf_token = e.csrf_token;
   				if(e.lists.length>0){
   					var list="";
   					$.each(e.lists,function(key,value){
   						var uniqid = value.unique_id;
   						list+="<tr>";
   						list+="<td><a target='_blank' href='<?=base_url()?>form/"+uniqid+"'>"+value.request_id+"</a></td>";
   						list+="<td>"+value.seller_id+"</td>";
   						list+="<td>"+value.vertical+"</td>";
   						list+="<td>"+value.status+"</td>";
   						list+="</tr>";
   					});
   					$('#list-table').css('display','block');
   					$('#ajax-data').html(list);
   				}else{
   					$('#ajax-data').html("<tr><td colspan='4'><center>No Data exists</center></td></tr>");
   				}
   			},
   			error:function(error){
   				console.log(error);
   			}
   		});
   	}

    // export agent information to excel
    $('#exportAgentDetailsbtn').click(function(){
      $("#agentInformation").table2excel({
        exclude: ".noExl",
        name: "report1",
        filename: "agent-information",
        fileext: ".xls",
        exclude_img: true,
        exclude_links: true,
        exclude_inputs: true

      });
    });
</script>
