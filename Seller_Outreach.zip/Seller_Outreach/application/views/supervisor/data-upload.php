<?php include(APPPATH.'views/common/head.php') ?>
<?php include(APPPATH.'views/common/header.php') ?>
<div class="app-content my-3 my-md-5">

   <div class="side-app">
		<div class="page-header">
			 <h4 class="page-title">Bulk Upload & Dump Download</h4>
			 <ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="#">Supervisor</a></li>
				<li class="breadcrumb-item active" aria-current="page">Bulk Upload & Dump Download</li>
			 </ol>
      </div>
	  <div class="">
	  <?php if ($this->session->flashdata('msg')): ?>
		  <div class="alert alert-success alert-dismissible">
			 <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			 <?= $this->session->flashdata('msg') ?>
		  </div>
		<?php endif; ?>
         <?php echo form_open_multipart('',array('class' => 'card')) ?>
         <div class="card-status bg-yellow br-tr-3 br-tl-3"></div>
         <div class="card-header">
            <h3 class="card-title">Bulk Uplaod</h3>
         </div>
         <div class="card-body">
            <div class="row">
            <div class="col-md-6">
				<div class="text-center"><label>Download Sample CSV</label>
					<a href="<?=base_url()?>supervisor/download/bulk_upload.csv"><i class="fa fa-download"></i></a>
				</div>
               <div class="form-group">
				<div class="form-label">Upload File</div>
                  <div class="file-wrp p-2 mt-2 mb-3">
                     <input type="file" name="csv_file">
				  </div>
          <?php
            // if($fileStatus){
              // $disabled = 'disabled';
            // }else{
              $disabled = '';
            // }

           ?>
				  <button type="submit" class="btn btn-primary" <?= $disabled ?>>Upload</button>
               </div>
            </div>
               <div class="col-md-3">
                  <label for=""></label>
				</div>
            </div>
         </div>
         </form>
      </div>
      <div class="">
         <?php echo form_open('formData',array('class'=>'card')); ?>
         <div class="card-status bg-yellow br-tr-3 br-tl-3"></div>
         <div class="card-header">
            <h3 class="card-title">Dump Download</h3>
         </div>
         <div class="card-body">
            <div class="row">
               <div class="col-md-6">
                  <div class="form-group">
                     <div class="input-group">
                        <div class="input-group-prepend">
                           <div class="input-group-text">
                              <i class="fas fa-calendar tx-16 lh-0 op-6"></i>
                           </div>
                        </div>
                        <input class="form-control fc-datepicker" placeholder="MM/DD/YYYY" name="startDate" type="text" autocomplete="off">
                     </div>
                  </div>
               </div>
               <div class="col-sm-6 col-md-6">
                  <div class="form-group">
                     <div class="input-group">
                        <div class="input-group-prepend">
                           <div class="input-group-text">
                              <i class="fas fa-calendar tx-16 lh-0 op-6"></i>
                           </div>
                        </div>
                        <input class="form-control fc-datepicker" placeholder="MM/DD/YYYY" name="endDate" type="text" autocomplete="off">
                     </div>
                  </div>
               </div>
               <div class="col-md-3">
                  <div class="form-group">
                     <label class="form-label">Request Id</label>
                    <input type="text" class='form-control' placeholder='Enter request id' name='request_id'>
                  </div>
               </div>
			   <?php  ?>
               <div class="col-md-3">
                  <div class="form-group">
                     <label class="form-label">Seller Id</label>
                     <select class="form-control custom-select" name='seller_id'>
                        <option value="">Select Seller Id</option>
						<?php $sellerList = getSeller(); foreach ($sellerList as $value): ?>
							<option value="<?= $value['seller_id']?>"><?= $value['seller_id'] ?></option>
						<?php endforeach; ?>
                     </select>
                  </div>
               </div>
               <div class="col-md-3">
                  <div class="form-group">
                     <label class="form-label">Select Name</label>
                     <select class="form-control custom-select" name='agent_id'>
                        <option value="">Select Agent Name</option>
                        <?php foreach ($agentList as $value): ?>
							<option value="<?= $value['user_id']?>"><?= $value['evaluator_name'] ?></option>
						<?php endforeach; ?>
                     </select>
                  </div>
               </div>
			   <div class="col-md-3">
                  <div class="form-group">
                     <label class="form-label">Select Status</label>
                     <select class="form-control custom-select" name='status'>
                       <option value=''>Choose</option>
                       <option value="call back">call back</option>
                       <option value="call Back-Agreed to Upload">call Back-Agreed to Upload</option>
                       <option value="Contacted-Disagree to Upload">Contacted-Disagree to Upload</option>
                       <option value="Listing Uploaded-Post Call">Listing Uploaded-Post Call</option>
                       <option value="Listing Uploaded-Pre Call">Listing Uploaded-Pre Call</option>
                       <option value="Non Contatable/Not Reachable">Non Contatable/Not Reachable</option>
                       <option value="No Follow Up required">No Follow Up required</option>
                       <option value="Close">Close</option>
                     </select>
                  </div>
               </div>
               <div class="card-footer text-right">
                  <button type="submit" class="btn btn-primary">Download</button>
               </div>
               </form>
            </div>
         </div>
      </div>
   </div>
</div>
<?php include(APPPATH.'views/common/footer.php') ?>
