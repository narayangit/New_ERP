<?php include(APPPATH.'views/common/head.php') ?>
<?php include(APPPATH.'views/common/header.php') ?>
<div class="app-content my-3 my-md-5">
   <div class="side-app">
      <div class="page-header">
         <h4 class="page-title">Follow Up </h4>
         <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Supervisor</a></li>
            <li class="breadcrumb-item active" aria-current="page">Follow Up</li>
         </ol>
      </div>
      <div class="row">
         <div class="col-md-12 col-lg-12">
            <?php echo form_open(); ?>
            <div class="card">
            <div class="card-status bg-yellow br-tr-3 br-tl-3"></div>
               <div class="card-header">
                  <div class="card-title">Select Date</div>
               </div>
               <div class="row">
                  <div class="col-lg-5">
                     <div class="card-body">
                        <div class="wd-200 mg-b-30">
                           <div class="input-group">
                              <div class="input-group-prepend">
                                 <div class="input-group-text"><i class="fas fa-calendar tx-16 lh-0 op-6"></i></div>
                              </div>
                              <input class="form-control fc-datepicker" name="fromDate" id="fromDate" placeholder="MM/DD/YYYY" type="text" value="<?= $fromDate ?>" autocomplete="off">
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-5">
                     <div class="card-body">
                        <div class="wd-200 mg-b-30">
                           <div class="input-group">
                              <div class="input-group-prepend">
                                 <div class="input-group-text"><i class="fas fa-calendar tx-16 lh-0 op-6"></i></div>
                              </div>
                              <input class="form-control fc-datepicker" name="toDate" id="toDate" placeholder="MM/DD/YYYY" type="text" value='<?= $toDate ?>' autocomplete="off">
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-2">
                     <div class="card-body">
                        <button type="submit" class="btn btn-primary">Submit</button>
                     </div>
                  </div>
               </div>
            </div>
            </form>
          </div>
        </div>

          <!-- request id table  -->
          <div class="row">
             <div class="col-md-12 col-lg-12">
                <form class="" name="assignForm" id="assignForm">
                   <div class="card">
                      <div class="card-status bg-yellow br-tr-3 br-tl-3"></div>
                      <div class="card-alert alert custom-alert  mb-0">
                        <div class="row agent-frm-wrp">
                                <div class="col-md-3">



                              <select class="form-control custom-select" name="agentList">
                                <option value="0">Select Agent</option>
                                                            <?php foreach ($agentList as $value): ?>
                                        <option value="<?= $value['user_id']?>"><?= $value['evaluator_name'] ?></option>
                                        <?php endforeach; ?>
                              </select>

                                </div>
                                <div class="col-md-2">
                                  <?php
                                    if(count($followUp)>0){
                                      $disabled ='';
                                    }else{
                                      $disabled ='disabled';
                                    }

                                   ?>
                                        <button type="button" id="assignBtn" class="btn btn-primary mb-3" <?= $disabled ?>>Assign</button>

                                </div>
                                <div class="col-md-7">
                                  <i class="far fa-file-excel" id="exportbtn" style="font-size:30px; color:green; float:right; padding:10px"></i>
                                </div>
        </div></div>
                      <div class="card-header">
                         <div class="card-title">List of Request Id's</div>
                      </div>
                      <div class="card-body">
                         <div class="table-responsive" id="followUpTable">
                            <table id="example" class="table table-striped table-bordered" style="width:100%">
                               <thead>
                                  <tr>
                                     <th class="wd-5p">Checkbox</th>
                                     <th class="wd-15p">Request ID</th>
                                     <th class="wd-15p">Unique ID</th>
                                     <th class="wd-15p">Seller Id</th>
                                     <th class="wd-20p">Vertical</th>
                                     <th class="wd-15p">Called By</th>
                                     <th class="wd-15p">Assigned to</th>
									 <th class="wd-15p">Follow up Date & time</th>
									 <th class="wd-25p">Status</th>
                                  </tr>
                               </thead>
                               <tbody id="request-list">
                                  <?php foreach ($followUp as $value): ?>
                                  <tr>
                                     <td>
                                        <label class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" name="checkedRequest[]" value="<?= $value['unique_id'] ?>" >
                                        <span class="custom-control-label"></span>
                                        </label>
                                     </td>
                                     <td><?= $value['request_id'] ?></td>
                                     <td><?= $value['unique_id'] ?></td>
                                     <td><?= $value['seller_id'] ?></td>
                                     <td><?= $value['vertical'] ?></td>
                                     <td><?= $value['called_by'] ?></td>
                                     <td><?= $value['assigned_to'] ?></td>
                                     <td><?= $value['followUp_date']." ".$value['followUp_time']  ?></td>
                                     <td><?= $value['status'] ?></td>
                                  </tr>
                                  <?php endforeach; ?>
                               </tbody>
                            </table>
                         </div>
                      </div>
              <!-- table-wrapper -->
                   </div>
                </form>
             </div>
          </div>
           </div>
        </div>
        <?php include(APPPATH.'views/common/footer.php') ?>
        <script type="text/javascript">
           $(document).ready(function(){

           	$('#assignBtn').click(function(){
           		var form = $('#assignForm').serialize();
           		var fromDate = $('#fromDate').val();
           		var toDate = $('#toDate').val();
           		var table = $('#example').DataTable();
           		// table.draw(false);
           	 var info = table.page.info();
           		$.ajax({
           			url : '<?=base_url()?>followUp',
           			type: 'POST',
           			data: form+"&fromDate="+fromDate+"&toDate="+toDate,
           			success: function(e){
                  console.log(e);
           				var list="";
           				list+='<table id="example" class="table table-striped table-bordered" style="width:100%">';
           				list+='<thead><tr><th class="wd-25p">Checkbox</th><th class="wd-15p">Request ID</th><th class="wd-15p">Unique ID</th><th class="wd-15p">Seller Id</th><th class="wd-20p">Vertical</th><th class="wd-10p">Called By</th><th class="wd-10p">Assigned to</th><th class="wd-25p">Follow up Date & time</th><th class="wd-25p">Status</th></tr></thead>';
           				list+='<tbody id="request-list">';
           				$.each(JSON.parse(e),function(key,value){
           					var uniqid = value.unique_id;
           					list+='<tr>';
           					list+='<td><label class="custom-control custom-checkbox">';
           					list+='<input type="checkbox" class="custom-control-input" name="checkedRequest[]" value="'+uniqid+'">';
           					list+='<span class="custom-control-label"></span></label></td>';
           					list+='<td>'+value.request_id+'</td>'
							list+="<td>"+value.unique_id+"</td>";
           					list+="<td>"+value.seller_id+"</td>";
           					list+="<td>"+value.vertical+"</td>";
							list+="<td>"+value.called_by+"</td>";
							list+="<td>"+value.assigned_to+"</td>";
							list+="<td>"+value.followUp_date+" "+value.followUp_time+"</td>";
           					list+="<td>"+value.status+"</td>";
           					list+="</tr>";
           				});
           				list+='</tbody>';
           				list+='</table>';
           				$('.table-responsive').html(list);
           				// jump to current page
           				var goToPage = $('#example').DataTable({"destroy": true});
           				 goToPage.page(info.page).draw("page");
						 alert('Request id assigned to another user successfully');
           			},
           			error: function(error){
           				console.log();
           			}
           		});
				
           	});

              $('#exportbtn').click(function(){
                $("#followUpTable").table2excel({
                  exclude: ".noExl",
                  name: "report1",
                  filename: "followUp" + new Date().toISOString().replace(/[\-\:\.]/g, ""),
                  fileext: ".xls",
                  exclude_img: true,
                  exclude_links: true,
                  exclude_inputs: true

                });
              });

           });




        </script>
