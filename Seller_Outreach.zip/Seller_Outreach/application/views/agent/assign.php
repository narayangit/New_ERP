<?php include(APPPATH.'views/common/head.php') ?>
<?php include(APPPATH.'views/common/header.php') ?>
<div class="app-content my-3 my-md-5">
   <div class="side-app">
      <br>
      <?php if ($this->session->flashdata('msg')): ?>
      <div class="alert alert-success alert-dismissible">
         <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
         <?= $this->session->flashdata('msg') ?>
      </div>
      <?php endif; ?>
      <?php if(count($callbackId) > 0): ?>
      <?php foreach ($callbackId as $value): ?>
      <div class="alert alert-danger alert-dismissible">
         <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
         This request id <a href='<?= base_url("form/".$value['unique_id'])?>'> <?= $value['request_id'] ?> </a>  call back time is <?= $value['followUp_time'] ?>
      </div>
      <?php endforeach; ?>
      <?php endif; ?>
      <div class="page-header">
         <h4 class="page-title">Agent Details</h4>
         <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Agent</a></li>
            <li class="breadcrumb-item active" aria-current="page">Agent Details</li>
         </ol>
      </div>
      <div class="row">
         <div class="col-md-12 col-lg-12">
            <!-- <div class="card"> -->
            <!-- <div class="card-status bg-gray br-tr-3 br-tl-3"></div> -->
            <div class="text-wrap mb-5 mt-3">
               <?php include('status-tab.php') ?>
            </div>
            <!-- </div> -->
            <div class="card">
               <div class="card-status bg-yellow br-tr-3 br-tl-3"></div>
               <div class="card-header">
                  <div class="card-title">List of Request Id Details</div>
               </div>
               <div class="card-body">
                  <div class="table-responsive">
                     <table id="example" class="table table-striped table-bordered" style="width:100%">
                        <thead>
                           <tr>
                              <th class="wd-15p">Unique ID</th>
                              <th class="wd-15p">Request ID</th>
                              <th class="wd-15p">Seller Id</th>
                              <th class="wd-20p">Vertical</th>
                              <th class="wd-20p">Assigned Date</th>
                              <th class="wd-15p">Status</th>
                           </tr>
                        </thead>
                        <tbody>
                           <?php foreach ($getRequestIdUnderAgent as $value): ?>
                           <tr>
							  <td><?= $value['unique_id'] ?></td>
                              <td> <a href="<?=base_url('form/'.$value['unique_id'])?>"> <?= $value['request_id'] ?></a> </td>
                              <td><?= $value['seller_id'] ?></td>
                              <td><?= $value['vertical'] ?></td>
                              <td><?= $value['assigned_date'] ?></td>
                              <td><?= $value['status'] ?></td>
                           </tr>
                           <?php endforeach; ?>
                        </tbody>
                     </table>
                  </div>
               </div>
               <!-- table-wrapper -->
            </div>
            <!-- section-wrapper -->
         </div>
      </div>
   </div>
</div>
<?php include(APPPATH.'views/common/footer.php') ?>
