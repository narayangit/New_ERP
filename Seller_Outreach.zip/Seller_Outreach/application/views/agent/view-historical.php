<?php include(APPPATH.'views/common/head.php') ?>
<?php include(APPPATH.'views/common/header.php') ?>
<div class="app-content my-3 my-md-5">
   <div class="side-app">
      <div class="page-header">
         <h4 class="page-title">Historical View</h4>
         <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Agent</a></li>
            <li class="breadcrumb-item active" aria-current="page">Historical View</li>
         </ol>
      </div>
      <div class="row">
         <div class="col-md-12 col-lg-12">
            <div class="">
               <!-- data section -->
               <?php echo form_open(); ?>
               <div class="card">
               <div class="card-status bg-yellow br-tr-3 br-tl-3"></div>
                  <div class="card-header">
                     <div class="card-title">Select Date</div>
                  </div>
                  <div class="row">
                     <div class="col-lg-5">
                        <div class="card-body">
                           <div class="wd-200 mg-b-30">
                              <div class="input-group">
                                 <div class="input-group-prepend">
                                    <div class="input-group-text"><i class="fas fa-calendar tx-16 lh-0 op-6"></i></div>
                                 </div>
                                 <input class="form-control fc-datepicker" name="fromDate" placeholder="MM/DD/YYYY" type="text" autocomplete="off">
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-5">
                        <div class="card-body">
                           <div class="wd-200 mg-b-30">
                              <div class="input-group">
                                 <div class="input-group-prepend">
                                    <div class="input-group-text"><i class="fas fa-calendar tx-16 lh-0 op-6"></i></div>
                                 </div>
                                 <input class="form-control fc-datepicker" name="toDate" placeholder="MM/DD/YYYY" type="text" autocomplete="off">
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-2">
                        <div class="card-body">
                           <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                     </div>
                  </div>
               </div>
               </form>
               <!-- date section end -->
               <?php if(isset($requestIdsUnderAgent)): ?>
               <div class="card">
                  <div class="card-status bg-yellow br-tr-3 br-tl-3"></div>
                  <div class="card-header">
                     <div class="card-title">List of Agent Details</div>
                  </div>
                  <div class="card-body">
                     <div class="table-responsive">
                        <table id="example" class="table table-striped table-bordered" style="width:100%">
                           <thead>
                              <tr>
                                 <th class="wd-15p">Request ID</th>
                                 <th class="wd-15p">Seller Id</th>
                                 <th class="wd-20p">Vertical</th>
                                 <th class="wd-15p">Status</th>
                              </tr>
                           </thead>
                           <tbody>
                              <?php foreach ($requestIdsUnderAgent as $value): ?>
                              <tr>
                                 <td><a target="_blank" href='<?= base_url('form/'.$value['unique_id']) ?>'><?= $value['request_id'] ?></a></td>
                                 <td><?= $value['seller_id'] ?></td>
                                 <td><?= $value['vertical'] ?></td>
                                 <td><?= $value['status'] ?></td>
                              </tr>
                              <?php endforeach; ?>
                           </tbody>
                        </table>
                     </div>
                  </div>
                  <!-- table-wrapper -->
               </div>
               <!-- section-wrapper -->
               <?php endif; ?>
            </div>
         </div>
      </div>
   </div>
</div>
<?php include(APPPATH.'views/common/footer.php') ?>
