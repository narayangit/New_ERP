<?php include(APPPATH.'views/common/head.php') ?>
<?php include(APPPATH.'views/common/header.php') ?>
<div class="app-content my-3 my-md-5">
   <div class="side-app">
      <div class="page-header">
         <h4 class="page-title">Agent Details</h4>
         <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Agent</a></li>
            <li class="breadcrumb-item active" aria-current="page">Agent Details</li>
         </ol>
      </div>
      <div class="row">
         <div class="col-md-12 col-lg-12">
            <!-- <div class="card"> -->
            <!-- <div class="card-status bg-gray br-tr-3 br-tl-3"></div> -->
            <div class="text-wrap mb-5 mt-3">
               <?php include('status-tab.php') ?>
            </div>
            <!-- </div> -->
            <div class="card">
               <div class="card-status bg-yellow br-tr-3 br-tl-3"></div>
               <div class="card-header">
                  <div class="card-title">List of Agent Details</div>
               </div>
               <div class="card-body">
                  <div class="table-responsive">
                     <table id="example" class="table table-striped table-bordered" style="width:100%">
                        <thead>
                           <tr>
                              <th class="wd-15p">Unique ID</th>
                              <th class="wd-15p">Request ID</th>
                              <th class="wd-15p">Seller Id</th>
                              <th class="wd-20p">Vertical</th>
                              <th class="wd-15p">Status</th>
                              <th class="wd-15p">Last Updated</th>
                           </tr>
                        </thead>
                        <tbody>
                           <?php foreach ($getRequestIdUnderAgent as $value): ?>
                           <tr>
							  <td><?= $value['unique_id'] ?></td>
                              <td> <a href="<?=base_url('form/'.$value['unique_id'])?>"> <?= $value['request_id'] ?></a> </td>
                              <td><?= $value['seller_id'] ?></td>
                              <td><?= $value['vertical'] ?></td>
                              <td><?= $value['status'] ?></td>
                              <td><?= $value['submit_date'] ?></td>
                           </tr>
                           <?php endforeach; ?>
                        </tbody>
                     </table>
                  </div>
               </div>
               <!-- table-wrapper -->
            </div>
            <!-- section-wrapper -->
         </div>
      </div>
   </div>
</div>
<?php include(APPPATH.'views/common/footer.php') ?>
