    <?php echo form_open('agent',['method'=>'GET']) ?>
	<div class="card">
		<div class="card-status bg-yellow br-tr-3 br-tl-3"></div>
		<div class="card-header">
			<div class="card-title">Select Date</div>
		</div>
		<div class="row">
			<div class="col-lg-5">
				<div class="card-body">
					<div class="wd-200 mg-b-30">
						<div class="input-group">
							<div class="input-group-prepend">
								<div class="input-group-text">
									<i class="fas fa-calendar tx-16 lh-0 op-6"></i>
								</div>
							</div>
							<input class="form-control fc-datepicker" name="fromDate" value='<?= $fromDate ?>' placeholder="MM/DD/YYYY" autocomplete="off" type="text">
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-5">
				<div class="card-body">
					<div class="wd-200 mg-b-30">
						<div class="input-group">
							<div class="input-group-prepend">
								<div class="input-group-text">
									<i class="fas fa-calendar tx-16 lh-0 op-6"></i>
								</div>
							</div>
							<input class="form-control fc-datepicker" name="toDate" value='<?= $toDate ?>' placeholder="MM/DD/YYYY" autocomplete="off" type="text">
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-2">
				<div class="card-body">
					<input type="submit" class="btn btn-primary" value="submit">
				</div>
			</div>
		</div>
	</div>
	</form>
<?php if($fromDate!='' && $toDate!=''){ ?>
<div class="btn-list text-center">
  <a href="<?= base_url()?>agent?fromDate=<?=$fromDate?>&toDate=<?=$toDate?>"  class="btn btn-outline-primary <?= ($pageid=="Agent")?'active':'' ?> ">Assign</a>
  <a href="<?= base_url()?>callback?fromDate=<?=$fromDate?>&toDate=<?=$toDate?>" class="btn btn-outline-primary <?= ($pageid=="Call Back")?'active':'' ?>">Call Back</a>
  <a href="<?= base_url()?>agreedToUpload?fromDate=<?=$fromDate?>&toDate=<?=$toDate?>" class="btn btn-outline-primary <?= ($pageid=="Agrre to upload")?'active':'' ?>">call Back-Agreed to Upload</a>
  <a href="<?= base_url()?>disagreedToUpload?fromDate=<?=$fromDate?>&toDate=<?=$toDate?>" class="btn btn-outline-primary <?= ($pageid=="Disagree to Upload")?'active':'' ?>">Contacted-Disagree to Upload</a>
  <a href="<?= base_url()?>postcall?fromDate=<?=$fromDate?>&toDate=<?=$toDate?>" class="btn btn-outline-primary <?= ($pageid=="Post Call")?'active':'' ?>">Listing Uploaded-Post Call</a>
  <a href="<?= base_url()?>precall?fromDate=<?=$fromDate?>&toDate=<?=$toDate?>" class="btn btn-outline-primary <?= ($pageid=="Pre Call")?'active':'' ?>">Listing Uploaded-Pre Call</a>
  <a href="<?= base_url()?>notreachable?fromDate=<?=$fromDate?>&toDate=<?=$toDate?>" class="btn btn-outline-primary <?= ($pageid=="Not Reachable")?'active':'' ?>">Non contactable/Not Reachable</a>
  <a href="<?= base_url()?>nofollowup?fromDate=<?=$fromDate?>&toDate=<?=$toDate?>" class="btn btn-outline-primary <?= ($pageid=="No FollowUp")?'active':'' ?>">No Follow UP required</a>
  <a href="<?= base_url()?>close?fromDate=<?=$fromDate?>&toDate=<?=$toDate?>" class="btn btn-outline-primary <?= ($pageid=="close")?'active':'' ?>">Close</a>
</div>
<?php }else{ ?>
<div class="btn-list text-center">
  <a href="<?= base_url()?>agent"  class="btn btn-outline-primary <?= ($pageid=="Agent")?'active':'' ?> ">Assign</a>
  <a href="<?= base_url()?>callback" class="btn btn-outline-primary <?= ($pageid=="Call Back")?'active':'' ?>">Call Back</a>
  <a href="<?= base_url()?>agreedToUpload" class="btn btn-outline-primary <?= ($pageid=="Agrre to upload")?'active':'' ?>">call Back-Agreed to Upload</a>
  <a href="<?= base_url()?>disagreedToUpload" class="btn btn-outline-primary <?= ($pageid=="Disagree to Upload")?'active':'' ?>">Contacted-Disagree to Upload</a>
  <a href="<?= base_url()?>postcall" class="btn btn-outline-primary <?= ($pageid=="Post Call")?'active':'' ?>">Listing Uploaded-Post Call</a>
  <a href="<?= base_url()?>precall" class="btn btn-outline-primary <?= ($pageid=="Pre Call")?'active':'' ?>">Listing Uploaded-Pre Call</a>
  <a href="<?= base_url()?>notreachable" class="btn btn-outline-primary <?= ($pageid=="Not Reachable")?'active':'' ?>">Non contactable/Not Reachable</a>
  <a href="<?= base_url()?>nofollowup" class="btn btn-outline-primary <?= ($pageid=="No FollowUp")?'active':'' ?>">No Follow UP required</a>
  <a href="<?= base_url()?>close" class="btn btn-outline-primary <?= ($pageid=="close")?'active':'' ?>">Close</a>
</div>
<?php } ?>