<?php include(APPPATH.'views/common/head.php') ?>
<?php include(APPPATH.'views/common/header.php') ?>
<style>
.hideClass{
	display:none;
}
</style>
<div class="app-content my-3 my-md-5">
   <div class="side-app">
      <div class="page-header">
         <h4 class="page-title">Sellers Outcall Data </h4>
         <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="Index.php"><?= $this->session->userdata('level') ?></a></li>
            <li class="breadcrumb-item active" aria-current="page">Seller Outcall Data</li>
         </ol>
      </div>
	  
	  
      <div class="col-lg-12 wrp">
	  <?php echo validation_errors(); ?>
        <?php if ($this->session->flashdata('msg')): ?>
           <div class="alert alert-success alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <?= $this->session->flashdata('msg') ?>
           </div>
         <?php endif; ?>
      </div>

      <div class="col-lg-12 wrp">
         <!-- <form class="card" id="myForm"> -->
         <?php echo form_open('',array('class' => 'card', 'id' => 'myForm')) ?>
         <input type="hidden" name="unique_id" value="<?=$uniqueIdData['unique_id'] ?>">
         <div class="card-header req-field">
            <h5 class="text-primary">Seller Personal Infomation</h5>
            <span class="danger">*Fields are required</span>
         </div>
         <div class="card-body">

            <div class="row">
               <div class="col-md-4">
                  <div class="form-group">
                     <label class="form-label">Seller Name<span class="danger">*</span></label>
                     <input type="text" class="form-control" name="seller_name" placeholder="Name" value="<?= isset($uniqueIdData['seller_name'])?$uniqueIdData['seller_name']:''; ?>"  required >
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="form-group">
                     <label class="form-label">Seller Id</label>
                     <input type="text" class="form-control" name="seller_id" placeholder="Seller Id" value="<?= $uniqueIdData['seller_id'] ?>" readonly="">
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="form-group errmsg" >
                     <label class="form-label">Seller Contact<span class="danger">*</span></label></label>
                     <input type="text" class="form-control" name="seller_ph_no" id="quantity" placeholder="Enter Contact" value="<?= isset($uniqueIdData['seller_ph_no'])?$uniqueIdData['seller_ph_no']:''; ?>" required>
                     <span id="errmsg"></span>
                  </div>
               </div>
               <div></div>
            </div>
         </div>
         <div class="card-header">
            <h5 class="text-primary">Seller Listing</h5>
         </div>
         <div class="card-body">
            <div class="row">
               <div class="col-md-6 col-sm-12">
                  <label class="form-label">Count of listings uploaded<span class="danger">*</span></label>
                  <div class="row text-center">
                     <div class="col-md-4">
                        <div class="form-group">
                           <label class="form-label">Total</label>
                           <input type="text" class="form-control" name="rows_edited" placeholder="Total" value="<?= $uniqueIdData['rows_edited'] ?>" required>
                        </div>
                     </div>
                     <div class="col-md-4">
                        <div class="form-group">
                           <label class="form-label">Passed</label>
                           <input type="text" class="form-control" name="rows_passed" placeholder="Passed" value="<?= $uniqueIdData['rows_passed'] ?>" required>
                        </div>
                     </div>
                     <div class="col-md-4">
                        <div class="form-group">
                           <label class="form-label"> failed</label>
                           <input type="text" class="form-control" name="rows_failed" placeholder="failed" value="<?= $uniqueIdData['rows_failed'] ?>" required>
                        </div>
                     </div>
                  </div>
               </div>
			   <div class="col-md-3 col-sm-6">
                  <div class="form-group">
                     <label class="form-label mb-6">Feed Uploaded At</label>
                     <input type="text" class="form-control" name="feed_time" placeholder="YYYY-MM-DD" value="<?= $uniqueIdData['feed_time'] ?>" readonly="">
                  </div>
               </div>
			   <div class="col-md-3">
                  <div class="form-group">
                     <label class="form-label mb-6">Vertical</label>
                     <input type="text" class="form-control" name="vertical" placeholder="Your Answer" value="<?= $uniqueIdData['vertical'] ?>" readonly="">
                  </div>
               </div>
            </div>
         </div>
         <div class="card-header">
            <h5 class="text-primary">Seller Contact Details</h5>
         </div>
         <div class="card-body">
            <div class="row">
				<div class="col-md-3">
                  <div class="form-group">
                     <label class="form-label">Request Id/Feed Id</label>
                     <input type="text" class="form-control" name="request_id" placeholder="Request Id" value="<?= $uniqueIdData['request_id'] ?>" readonly="">
                  </div>
               </div>
			   <div class="col-md-3">
                  <div class="form-group">
                     <label class="form-label">Other Request Id/Feed Id</label>
                     <input type="text" class="form-control" name="oth_request_id" placeholder="Enter Request Id" >
                  </div>
               </div>
			    <div class="col-md-3">
                  <div class="form-group">
                     <label class="form-label">Tier<span class="danger">*</span></label>
                     <select   class="form-control custom-select" name="tier"  required>
						<?php $sel_opt = isset($uniqueIdData['tier'])?$uniqueIdData['tier']:"" ?>
                        <option value="Gold" <?= ($sel_opt=="Gold")?"selected":"" ?>>Gold</option>
                        <option value="Silver" <?= ($sel_opt=="Silver")?"selected":"" ?>>Silver</option>
                        <option value="Bronze" <?= ($sel_opt=="Bronze")?"selected":"" ?>>Bronze</option>
                     </select>
                  </div>
               </div>
               <div class="col-md-3">
                  <div class="form-group">
                     <label class="form-label">Assigneed Work<span class="danger">*</span></label>
                     <select class="form-control custom-select" name="assigned_work" required>
                        <?php $sel_opt = isset($uniqueIdData['assigned_work'])?$uniqueIdData['assigned_work']:"" ?>
                        <option value="">Select</option>
                        <option value="MPQC" <?= ($sel_opt=="MPQC")?"selected":"";  ?> >MPQC</option>
                        <option value="OLD DATA" <?= ($sel_opt=="OLD DATA")?"selected":"" ?> >OLD DATA</option>
                        <option value="FMCG" <?= ($sel_opt=="FMCG")?"selected":"" ?> >FMCG</option>
                        <option value="Top 10 Defaulters" <?= ($sel_opt=="Top 10 Defaulters")?"selected":"" ?> >Top 10 Defaulters</option>
                        <option value="L2 Seller" <?= ($sel_opt=="L2 Seller")?"selected":"" ?> >L2 Seller</option>
                        <option value="Adhoc Request" <?= ($sel_opt=="Adhoc Request")?"selected":"" ?> >Adhoc Request</option>
                        <option value="Womens Clothing" <?= ($sel_opt=="Womens Clothing")?"selected":"" ?> >Womens Clothing</option>
                     </select>
                  </div>
               </div>
            </div>
         </div>
         <div class="card-header d-flex justify-content-between">
            <h5 class="text-primary">Seller Details</h5>
         </div>
         <div class="card-body">
        <?php if (count($historyData)>0): $id = 1; ?>
         <?php foreach ($historyData as $value):  ?>
         <div class="custom-accordian">
            <div class="panel-group1" id="accordion1">
               <div class="panel panel-default mb-4">
                  <div class="panel-heading1 ">
                     <h4 class="panel-title1">
                        <a class="accordion-toggle collapsed plus-toggl" data-toggle="collapse" data-parent="#accordion" href="#collapseFour-<?=$id?>" aria-expanded="false"><?= $value['status'] ?><i class="fas fa-plus display-fa"></i></a>
                     </h4>
                  </div>
                  <div id="collapseFour-<?=$id?>" class="panel-collapse collapse" role="tabpanel" aria-expanded="false">
                     <div class="panel-body">
                        <!-- Data show form -->
                        <!-- <div class="card-body"> -->
                        <h4>Attempt-<?=$id?></h4>
                        <div class="row">

                           <div class="col-md-6">
                              <div class="form-group">
                                 <label class="form-label">Called By<span class="danger">*</span></label></label>
                                 <select class="form-control custom-select" disabled>
                                    <option><?= $value['called_by'] ?></option>
                                 </select>
                              </div>
                           </div>
                           <div class="col-md-6">
                              <div class="form-group">
                                 <label class="form-label">Spoken with<span class="danger">*</span></label></label>
                                 <input type="text" class="form-control" value="<?= $value['spoken_with'] ?>" placeholder="Your Answer" disabled>
                              </div>
                           </div>
                           <div class=" col-md-3">
                              <div class="form-group">
                                 <label class="form-label">Enter Date<span class="danger">*</span></label></label>
                                 <div class="input-group">
                                    <div class="input-group-prepend">
                                       <div class="input-group-text">
                                          <i class="fas fa-calendar tx-16 lh-0 op-6"></i>
                                       </div>
                                    </div>
                                    <input class="form-control fc-datepicker" placeholder="YYYY-MM-DD" type="text" value="<?= $value['outcall_date'] ?>" autocomplete="off" disabled>
                                 </div>
                              </div>
                           </div>
							<div class=" col-md-3">
								<div class="form-group">
									<label class="form-label">Catalog Handled<span class="danger">*</span></label></label>
									<select class="form-control custom-select" readonly disabled>
										<option><?= $value['catalog_handling'] ?></option>
									</select>
								</div>
							</div>
							<?php if($value['catalog_handling'] == 'Eco System Partner'): ?>
							 <div class="col-md-3 catalog_name_box">
								 <div class="form-group">
									<label class="form-label">Name<span class="danger">*</span></label></label>
									<input type="text" class="form-control" value='<?= $value['catalog_name'] ?>' placeholder="Your Answer" >
								 </div>
							  </div>
							  <div class="col-md-3 catalog_ph_no_box">
								 <div class="form-group">
									<label class="form-label">Contact No<span class="danger">*</span></label></label>
									<input type="text" class="form-control" value='<?= $value['catalog_ph_no'] ?>' placeholder="Your Answer" >
								 </div>
							  </div>
							 <?php endif; ?>
                           <div class="col-md-6">
                              <div class="form-group">
                                 <label class="form-label">Reason for not uploading earlier<span class="danger">*</span></label></label>
                                 <select class="form-control custom-select" disabled>
                                    <option><?= $value['uploading_reason'] ?></option>
                                 </select>
                              </div>
                           </div>
                           <div class="col-md-6">
                              <div class="form-group">
                                 <label class="form-label">For others please fill the Reason here </label>
                                 <textarea class="form-control" rows="2" placeholder="Your Answer" disabled><?= $value['other_reason'] ?></textarea>
                              </div>
                           </div>
                           <div class="col-md-6">
                              <div class="form-group">
                                 <label class="form-label">Failure reason</label>
                                 <textarea class="form-control" rows="2" placeholder="Your Answer" disabled><?= $value['failure_reason'] ?></textarea>
                              </div>
                           </div>

                           <div class="col-md-3">
                              <div class="form-group">
                                 <label class="form-label">Seller's Types<span class="danger">*</span></label>
                                 <select class="form-control custom-select" name="seller_type" disabled>
                                    <option><?=$value['seller_type']?></option>
                                 </select>
                              </div>
                           </div>
                           <div class="col-md-3">
                              <div class="form-group">
                                 <label class="form-label">Status</label>
                                 <select class="form-control custom-select" name="status" disabled>
                                    <option><?=$value['status']?></option>
                                 </select>
                              </div>
                           </div>
                           <div class="col-md-3">
                              <div class="form-group">
                                 <label class="form-label">Follow Up Date</label>
                                 <div class="input-group">
                                    <div class="input-group-prepend">
                                       <div class="input-group-text">
                                          <i class="fas fa-calendar tx-16 lh-0 op-6"></i>
                                       </div>
                                    </div>
                                    <input class="form-control fc-datepicker" placeholder="YYYY-MM-DD" type="text" value="<?= $value['followUp_date'] ?>" autocomplete="off" disabled>
                                 </div>
                              </div>
                           </div>
                           <div class="col-md-3">
                              <div class="form-group">
                                 <label class="form-label">Follow Up Time</label>
                                 <div class="d-flex">
                                    <div class="input-group date-gutters wd-150">
                                       <div class="input-group-prepend">
                                          <div class="input-group-text">
                                             <i class="fas fa-clock tx-16 lh-0 op-6"></i>
                                          </div>
                                          <!-- input-group-text -->
                                       </div>
                                       <!-- input-group-prepend -->
                                       <input class="form-control" placeholder="Set time" type="text" value="<?= $value['followUp_time'] ?>"  disabled>
                                    </div>
                                    <!-- input-group -->
                                 </div>
                              </div>
                           </div>
                           <div class="col-md-6">
                              <div class="form-group">
                                 <label class="form-label">If no then Reason </label>
                                 <textarea class="form-control" rows="2" placeholder="Your Answer" disabled><?= $value['reason'] ?></textarea>
                              </div>
                           </div>
                           <div class="col-md-6">
                              <div class="form-group">
                                 <label class="form-label">Comment </label>
                                 <textarea class="form-control" rows="2" placeholder="Your Answer" disabled><?= $value['comment'] ?></textarea>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!-- </div> -->
         <?php $id++; endforeach; ?>
         <div id="hideForm" style="display:none">
            <!-- <div class="card-header d-flex justify-content-between">
               <h5 class="text-primary">Seller Details</h5>
            </div> -->
            <div class="card-body">
               <div class="row">

                  <div class="col-md-6">
                     <div class="form-group">
                        <label class="form-label">Called By<span class="danger">*</span></label></label>
                        <select class="form-control custom-select" name="called_by" required>
                           <option value="">Select</option>
                           <?php foreach ($agentList as  $value): ?>
                           <option value="<?= $value['evaluator_name'] ?>"><?= $value['evaluator_name'] ?></option>
                           <?php endforeach; ?>
                        </select>
                     </div>
                  </div>
                  <div class="col-md-6">
                     <div class="form-group">
                        <label class="form-label">Spoken with<span class="danger">*</span></label></label>
                        <input type="text" class="form-control" name="spoken_with" placeholder="Your Answer" required>
                     </div>
                  </div>
                  <div class=" col-md-3">
                     <div class="form-group">
                        <label class="form-label">Enter Date<span class="danger">*</span></label></label>
                        <div class="input-group">
                           <div class="input-group-prepend">
                              <div class="input-group-text">
                                 <i class="fas fa-calendar tx-16 lh-0 op-6"></i>
                              </div>
                           </div>
                           <input class="form-control" placeholder="YYYY-MM-DD" type="text" name="outcall_date" autocomplete="off"  value='<?= date("Y-m-d") ?>' onkeypress='return false;' readonly>
                        </div>
                     </div>
                  </div>
				  <div class=" col-md-3">
                     <div class="form-group">
                        <label class="form-label">Catalog Handled<span class="danger">*</span></label></label>
                        <select class="form-control custom-select" name="catalog_handling" onchange='hideShowAttrCatalog($(this).find("option:selected").text());' required>
                           <option value=''>Choose</option>
                           <option value="Self">Self</option>
                           <option value="Others">Others</option>
                           <option value="Eco System Partner">Eco System Partner</option>
                           <option value="NA">NA</option>
                        </select>
                     </div>
                  </div>
				  <div class="col-md-3 catalog_name_box hideClass">
                     <div class="form-group">
                        <label class="form-label">Name<span class="danger">*</span></label></label>
                        <input type="text" class="form-control" name="catalog_name" id='catalog_name' placeholder="Your Answer" >
                     </div>
                  </div>
				  <div class="col-md-3 catalog_ph_no_box hideClass">
                     <div class="form-group">
                        <label class="form-label">Contact No<span class="danger">*</span></label></label>
                        <input type="text" class="form-control" name="catalog_ph_no" id='catalog_ph_no' placeholder="Your Answer" >
                     </div>
                  </div>
                  <div class="col-md-6">
                     <div class="form-group">
                        <label class="form-label">Reason for not uploading earlier<span class="danger">*</span></label></label>
                        <select class="form-control custom-select" name="uploading_reason" required>
                           <option value="">Select</option>
                           <option value="Didn't understand one or more error message, already contacted seller support">Didn't understand one or more error message, already contacted seller support</option>
                           <option value="Didn't understand one or more error message, Didn't contacted seller support">Didn't understand one or more error message, Didn't contacted seller support</option>
                           <option value="Understood the error but not interested">Understood the error but not interested</option>
                           <option value="inventery/catalog/Account Related issues">inventery/catalog/Account Related issues</option>
                           <option value="Didn't Check the error/Not aware of the failure">Didn't Check the error/Not aware of the failure</option>
                           <option value="Understood the error, will upload Later">Understood the error, will upload Later</option>
                           <option value="Disagree to share the reason">Disagree to share the reason</option>
                           <option value="Non-Contactable/Not Reachable">Non-Contactable/Not Reachable</option>
                           <option value="Others">Others</option>
                        </select>
                     </div>
                  </div>
                  <div class="col-md-6">
                     <div class="form-group">
                        <label class="form-label">For others please fill the Reason here </label>
                        <textarea class="form-control" name="other_reason" rows="2" placeholder="Your Answer"></textarea>
                     </div>
                  </div>
                  <div class="col-md-6">
                     <div class="form-group">
                        <label class="form-label">Failure reason</label>
                        <textarea class="form-control" name="failure_reason" rows="2" placeholder="Your Answer"></textarea>
                     </div>
                  </div>

                  <div class="col-md-3">
                     <div class="form-group">
                        <label class="form-label">Seller's Types<span class="danger">*</span></label>
                        <select class="form-control custom-select" name="seller_type" required>
                           <option value="">Select</option>
                           <option value="Defaulter Seller">Defaulter Seller</option>
                           <option value="Non-Responsive Seller">Non-Responsive Seller</option>
                           <option value="Angry/irate Seller">Angry/irate Seller</option>
                           <option value="Facing Account related Issue">Facing Account related Issue</option>
                           <option value="Facing Catalog related issue">Facing Catalog related issue</option>
                           <option value="Interested in Uploading">Interested in Uploading</option>
                        </select>
                     </div>
                  </div>
                   <div class="col-md-3">
                     <div class="form-group">
                        <label class="form-label">Status<span class="danger">*</span></label>
                        <select class="form-control custom-select" name="status" onchange='hideShowAttr($(this).find("option:selected").text());' required>
                           <option value=''>Select</option>
                           <option value="call back">call back</option>
                           <option value="call Back-Agreed to Upload">call Back-Agreed to Upload</option>
                           <option value="Contacted-Disagree to Upload">Contacted-Disagree to Upload</option>
                           <option value="Listing Uploaded-Post Call">Listing Uploaded-Post Call</option>
                           <option value="Listing Uploaded-Pre Call">Listing Uploaded-Pre Call</option>
                           <option value="Non Contactable/Not Reachable">Non Contactable/Not Reachable</option>
                           <option value="No Follow Up required">No Follow Up required</option>
                           <option value="Close">Close</option>
                        </select>
                     </div>
                  </div>
                  <div class="col-md-3 date">
                     <div class="form-group">
                        <label class="form-label">Follow Up Date</label>
                        <div class="input-group">
                           <div class="input-group-prepend">
                              <div class="input-group-text">
                                 <i class="fas fa-calendar tx-16 lh-0 op-6"></i>
                              </div>
                           </div>
                           <input class="form-control fc-datepicker" placeholder="YYYY-MM-DD" type="text" id="followUp_date" name="followUp_date" autocomplete="off" onkeypress='return false;'>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-3 time">
                     <div class="form-group">
                        <label class="form-label">Follow Up Time</label>
                        <div class="d-flex">
                           <div class="input-group date-gutters wd-150">
                              <div class="input-group-prepend">
                                 <div class="input-group-text">
                                    <i class="fas fa-clock tx-16 lh-0 op-6"></i>
                                 </div>
                                 <!-- input-group-text -->
                              </div>
                              <!-- input-group-prepend -->
                              <input class="form-control timepicker" id="followUp_time" name="followUp_time" placeholder="Set time" type="text" autocomplete="off" onkeypress='return false;'>
                           </div>
                           <!-- input-group -->
                        </div>
                     </div>
                  </div>
                  <div class="col-md-6">
                     <div class="form-group">
                        <label class="form-label">If no then Reason </label>
                        <textarea class="form-control" name="reason" rows="2" placeholder="Your Answer"></textarea>
                     </div>
                  </div>
                  <div class="col-md-6">
                     <div class="form-group">
                        <label class="form-label">Comment </label>
                        <textarea class="form-control" name="comment" rows="2" placeholder="Your Answer"></textarea>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <?php else: ?>
         <!-- Data show form -->
         <div id="newForm">
            <div class="card-body">
               <div class="row">
                  <div class="col-md-6">
                     <div class="form-group">
                        <label class="form-label">Called By<span class="danger">*</span></label></label>
                        <select class="form-control custom-select" name="called_by" required>
                           <option value="">Select</option>
                           <?php foreach ($agentList as  $value): ?>
                           <option value="<?= $value['evaluator_name'] ?>"><?= $value['evaluator_name'] ?></option>
                           <?php endforeach; ?>
                        </select>
                     </div>
                  </div>
                  <div class="col-md-6">
                     <div class="form-group">
                        <label class="form-label">Spoken with<span class="danger">*</span></label></label>
                        <input type="text" class="form-control" name="spoken_with" placeholder="Your Answer" required>
                     </div>
                  </div>
                  <div class=" col-md-3">
                     <div class="form-group">
                        <label class="form-label">Enter Date<span class="danger">*</span></label></label>
                        <div class="input-group">
                           <div class="input-group-prepend">
                              <div class="input-group-text">
                                 <i class="fas fa-calendar tx-16 lh-0 op-6"></i>
                              </div>
                           </div>
                           <input class="form-control" placeholder="YYYY-MM-DD" type="text" name="outcall_date" autocomplete="off"  value='<?= date("Y-m-d") ?>' onkeypress='return false;' readonly>
                        </div>
                     </div>
                  </div>
				  <div class=" col-md-3">
                     <div class="form-group">
                        <label class="form-label">Catalog Handled<span class="danger">*</span></label></label>
                        <select class="form-control custom-select" name="catalog_handling" onchange='hideShowAttrCatalog($(this).find("option:selected").text());' required>
                           <option value=''>Choose</option>
                           <option value="Self">Self</option>
                           <option value="Others">Others</option>
                           <option value="Eco System Partner">Eco System Partner</option>
                           <option value="NA">NA</option>
                        </select>
                     </div>
                  </div>
				  <div class="col-md-3 catalog_name_box hideClass">
                     <div class="form-group">
                        <label class="form-label">Name<span class="danger">*</span></label></label>
                        <input type="text" class="form-control" name="catalog_name" id='catalog_name' placeholder="Your Answer" >
                     </div>
                  </div>
				  <div class="col-md-3 catalog_ph_no_box hideClass">
                     <div class="form-group">
                        <label class="form-label">Contact No<span class="danger">*</span></label></label>
                        <input type="text" class="form-control" name="catalog_ph_no" id='catalog_ph_no' placeholder="Your Answer" >
                     </div>
                  </div>
                  <div class="col-md-6">
                     <div class="form-group">
                        <label class="form-label">Reason for not uploading earlier<span class="danger">*</span></label></label>
                        <select class="form-control custom-select" name="uploading_reason" required>
                           <option value="">Select</option>
                           <option value="Didn't understand one or more error message, already contacted seller support">Didn't understand one or more error message, already contacted seller support</option>
                           <option value="Didn't understand one or more error message, Didn't contacted seller support">Didn't understand one or more error message, Didn't contacted seller support</option>
                           <option value="Understood the error but not interested">Understood the error but not interested</option>
                           <option value="inventery/catalog/Account Related issues">inventery/catalog/Account Related issues</option>
                           <option value="Didn't Check the error/Not aware of the failure">Didn't Check the error/Not aware of the failure</option>
                           <option value="Understood the error, will upload Later">Understood the error, will upload Later</option>
                           <option value="Disagree to share the reason">Disagree to share the reason</option>
                           <option value="Non-Contactable/Not Reachable">Non-Contactable/Not Reachable</option>
                           <option value="Others">Others</option>
                        </select>
                     </div>
                  </div>
                  <div class="col-md-6">
                     <div class="form-group">
                        <label class="form-label">For others please fill the Reason here </label>
                        <textarea class="form-control" name="other_reason" rows="2" placeholder="Your Answer"></textarea>
                     </div>
                  </div>
                  <div class="col-md-6">
                     <div class="form-group">
                        <label class="form-label">Failure reason </label>
                        <textarea class="form-control" name="failure_reason" rows="2" placeholder="Your Answer"></textarea>
                     </div>
                  </div>

                  <div class="col-md-3">
                     <div class="form-group">
                        <label class="form-label">Seller's Types<span class="danger">*</span></label>
                        <select class="form-control custom-select" name="seller_type" required>
                           <option value="">Select</option>
                           <option value="Defaulter Seller">Defaulter Seller</option>
                           <option value="Non-Responsive Seller">Non-Responsive Seller</option>
                           <option value="Angry/irate Seller">Angry/irate Seller</option>
                           <option value="Facing Account related Issue">Facing Account related Issue</option>
                           <option value="Facing Catalog related issue">Facing Catalog related issue</option>
                           <option value="Interested in Uploading">Interested in Uploading</option>
                        </select>
                     </div>
                  </div>
                  <div class="col-md-3">
                     <div class="form-group">
                        <label class="form-label">Status<span class="danger">*</span></label>
                        <select class="form-control custom-select" name="status" onchange='hideShowAttr($(this).find("option:selected").text());' required>
                           <option value=''>Select</option>
                           <option value="call back">call back</option>
                           <option value="call Back-Agreed to Upload">call Back-Agreed to Upload</option>
                           <option value="Contacted-Disagree to Upload">Contacted-Disagree to Upload</option>
                           <option value="Listing Uploaded-Post Call">Listing Uploaded-Post Call</option>
                           <option value="Listing Uploaded-Pre Call">Listing Uploaded-Pre Call</option>
                           <option value="Non Contactable/Not Reachable">Non Contactable/Not Reachable</option>
                           <option value="No Follow UP required">No Follow UP required</option>
                           <option value="Close">Close</option>
                        </select>
                     </div>
                  </div>
                  <div class="col-md-3 date">
                     <div class="form-group">
                        <label class="form-label">Follow Up Date</label>
                        <div class="input-group">
                           <div class="input-group-prepend">
                              <div class="input-group-text">
                                 <i class="fas fa-calendar tx-16 lh-0 op-6"></i>
                              </div>
                           </div>
                           <input class="form-control fc-datepicker" id='followUp_date' placeholder="YYYY-MM-DD" type="text" name="followUp_date" autocomplete="off"  onkeypress='return false;'>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-3 time">
                     <div class="form-group">
                        <label class="form-label">Follow Up Time</label>
                        <div class="d-flex">
                           <div class="input-group date-gutters wd-150">
                              <div class="input-group-prepend">
                                 <div class="input-group-text">
                                    <i class="fas fa-clock tx-16 lh-0 op-6"></i>
                                 </div>
                              </div>
                              <input class="form-control timepicker" id='followUp_time' name="followUp_time" placeholder="Set time" type="text" autocomplete="off" onkeypress='return false;'>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-6">
                     <div class="form-group">
                        <label class="form-label">If no then Reason </label>
                        <textarea class="form-control" name="reason" rows="2" placeholder="Your Answer"></textarea>
                     </div>
                  </div>
                  <div class="col-md-6">
                     <div class="form-group">
                        <label class="form-label">Comment </label>
                        <textarea class="form-control" name="comment" rows="2" placeholder="Your Answer"></textarea>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <?php endif; ?>

         <!--  Form copy -->
         <div class="card" id="hiddenForm" style="display:none">
            <div  id="form-body">
            </div>
         </div>
         <!-- <div class="card-header d-flex justify-content-between"> -->
           <!-- <h5 class="text-primary"></h5> -->
            <?php if($this->session->userdata('level') == 'agent' && count($historyData)>0): ?>
            <div class="text-right">
            <a class="btn btn-success btn-sm" href="JavaScript:void(0);"  id="add-btn"><i class="fas fa-plus" ></i> Add Form</a>
            </div>
          <?php endif; ?>
         <!-- </div> -->
         <!--  Form copy end -->
         <?php if($this->session->userdata('level') == 'agent'){ ?>
         <div class="card-footer text-center">
            <button type="submit" class="btn btn-primary"  id="btnSubmit">Submit</button>
         </div>
         <?php } ?>
         </form>
      </div>
   </div>
</div>
<?php include(APPPATH.'views/common/footer.php') ?>

<script>
function hideShowAttr(val)
{
   if(val == 'call back' || val == 'call Back-Agreed to Upload' || val == 'Listing Uploaded-Pre Call' || val == 'Non Contactable/Not Reachable'){
	   $('.date,.time').show();
     $('#followUp_time,#followUp_date').css('border','1px solid red');
	   $('#followUp_time,#followUp_date').prop('required',true);
   }else{
	   $('.date,.time').hide();
	   $('#followUp_time,#followUp_date').css('border','');
	   $('#followUp_time,#followUp_date').prop('required',false);
   }
}

function hideShowAttrCatalog(val){
	
	if(val == 'Eco System Partner'){
		$('.catalog_name_box,.catalog_ph_no_box').show();
		$('#catalog_name,#catalog_ph_no').prop('required',true);
	}else{
		$('.catalog_name_box,.catalog_ph_no_box').hide();
		$('#catalog_name,#catalog_ph_no').prop('required',false);
	}
}

$(function(e){
  $("#add-btn").click(function(){
     $('#hideForm,#hiddenForm').show();
     var form = $('#newForm').clone();
     $('#form-body').html(form);
  });
})
</script>
