## Nodejs in 10 minutes

clone the project

### Installations
* npm install

### Run

* npm run start

:)