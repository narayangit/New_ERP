<?php
class PostsController extends AppController {

	var $name = 'Posts';
	var $uses = array('Post');
	var $helpers = array('Html', 'Form', 'Javascript');
	var $components = array('RequestHandler');

	function index() {
		$this->Post->recursive = 0;
		$this->set('posts', $this->paginate());
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid Post.', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->set('post', $this->Post->read(null, $id));
	}

	function add() {
		$this->render('edit');
	}
	
	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid Post', true));
			$this->redirect(array('action'=>'index'));
		}
		if (empty($this->data)) {
			$this->data = $this->Post->read(null, $id);
		}
	}	

	function ajax_edit() {
		Configure::write('debug', 0);
		$this->layout = 'ajax';
        if ($this->RequestHandler->isAjax()) {
			if (!empty($this->data)) {
				$this->Post->create();
				$this->Post->set($this->data['Post']);
				if($this->Post->validates()) {
					if ($this->Post->save($this->data)) {
						$message = __('The Post has been saved.', true);
						$data = $this->data;
						$this->set('success', compact('message', 'data'));
					}
				} else {
					$message = __('The Post could not be saved. Please, try again.', true);
					$Post = $this->Post->invalidFields();
					$data = compact('Post');
					$this->set('errors', compact('message', 'data'));
				}
			}
			
		}
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for Post', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->Post->del($id)) {
			$this->Session->setFlash(__('Post deleted', true));
			$this->redirect(array('action'=>'index'));
		}
	}

}
?>