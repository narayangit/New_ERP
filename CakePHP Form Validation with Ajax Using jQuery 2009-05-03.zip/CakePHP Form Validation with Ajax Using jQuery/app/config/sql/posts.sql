create table posts (
  id int(11) not null auto_increment,
  title varchar(32) not null,
  body text not null,
  published tinyint(1) not null,
  created datetime default null,
  updated datetime default null,
  primary key (id)
);
