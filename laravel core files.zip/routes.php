<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/',  ['uses' => 'Landing@index']);
Route::get('/data/archivedaily',  ['uses' => 'Sampling\DataController@archivedaily']);


// admin/listusers
Route::get('admin/login',['uses'=>'Admin\LoginController@login','as' => 'admin.login']);
Route::get('admin/loginCheck',['uses'=> 'Admin\LoginController@loginCheck','as'=>'admin.loginCheck']);
Route::post('admin/loginCheck',['uses'=> 'Admin\LoginController@loginCheck','as'=>'admin.loginCheck']);

Route::group(['middleware' => 'authcheck'], function () {


    Route::group(['prefix' =>'admin','namespace' => 'Admin'], function()
    {
        Route::get('logout',['uses'=>'LogoutController@logout','as'=> 'admin.logout']);

        Route::get('dashboard',['uses'=>'DashboardController@dashboard','as' => 'admin.dashboard']);
        Route::get('dashboard/getanalyst',['uses' => 'DashboardController@getAnalystData']);
        Route::get('dashboard/getdata',['uses' => 'DashboardController@getDashboardData']);
        Route::get('dashboard/downloadreport',['uses' => 'DashboardController@downloadReport']);

        Route::get('user',['uses'=>'UserController@index', 'as'=>'user.index']);
        Route::get('user/create',['uses'=>'UserController@create', 'as'=>'user.create']);
        Route::post('user',['uses'=>'UserController@store', 'as'=>'user.store']);
        Route::get('user/edit/{id}',['uses'=>'UserController@edit', 'as'=>'user.edit']);
        Route::patch('user/update/{id}',['uses'=> 'UserController@update', 'as' => 'user.update']);
        Route::delete('user/delete/{id}',['uses'=> 'UserController@destroy', 'as' => 'user.destroy']);

        Route::get('role',['uses'=> 'RoleController@index','as' => 'role.index']);
        Route::get('role/create',['uses'=> 'RoleController@create','as' => 'role.create']);
        Route::post('role',['uses'=> 'RoleController@store','as' => 'role.store']);
        Route::get('role/edit/{id}',['uses'=> 'RoleController@edit','as' => 'role.edit']);
        Route::put('role/{id}',['uses'=> 'RoleController@update', 'as' => 'role.update']);
        Route::delete('role/delete/{id}',['uses'=> 'RoleController@destroy', 'as' => 'role.destroy']);

                //----------------priority---------------
                Route::get('priority',['uses'=>'PriorityController@index', 'as'=>'priority.index']);
        Route::get('priority/edit/{id}',['uses'=>'PriorityController@edit', 'as'=>'priority.edit']);
        Route::patch('priority/update/{id}',['uses'=> 'PriorityController@update', 'as' => 'priority.update']);


     Route::group(['prefix' => 'system', 'namespace' => 'SystemSetting'], function()
     {
         //General Settings
         Route::get('/data', ['uses' => 'GeneralController@index', 'as' => 'system.data']);

         Route::get('/data/buyersbrowseupload', ['uses' => 'GeneralController@buyersbrowseupload']);
         Route::put('/data/buyersbrowseupload', ['uses' => 'GeneralController@buyersbrowseupload']);
         Route::post('/data/buyersbrowseupload', ['uses' => 'GeneralController@buyersbrowseupload']);


         Route::get('/data/featuresetupload', ['uses' => 'GeneralController@featuresetupload']);
         Route::put('/data/featuresetupload', ['uses' => 'GeneralController@featuresetupload']);
         Route::post('/data/featuresetupload', ['uses' => 'GeneralController@featuresetupload']);



         Route::get('/data/raterssetupload', ['uses' => 'GeneralController@raterssetupload']);
         Route::put('/data/raterssetupload', ['uses' => 'GeneralController@raterssetupload']);
         Route::post('/data/raterssetupload', ['uses' => 'GeneralController@raterssetupload']);

                 //------------Upload Buyers Product Set----//
                 Route::get('/data/buyersproductsetupload', ['uses' => 'GeneralController@buyersproductsetupload']);
         Route::put('/data/buyersproductsetupload', ['uses' => 'GeneralController@buyersproductsetupload']);
         Route::post('/data/buyersproductsetupload', ['uses' => 'GeneralController@buyersproductsetupload']);

                 //-----------Upload Insight Set--------//

                 Route::get('/data/insightsetupload', ['uses' => 'GeneralController@insightsetupload']);
         Route::put('/data/insightsetupload', ['uses' => 'GeneralController@insightsetupload']);
         Route::post('/data/insightsetupload', ['uses' => 'GeneralController@insightsetupload']);

                 //------------------Upload ABFeature Set----------------//

                 Route::get('/data/abfeaturesetupload', ['uses' => 'GeneralController@abfeaturesetupload']);
         Route::put('/data/abfeaturesetupload', ['uses' => 'GeneralController@abfeaturesetupload']);
         Route::post('/data/abfeaturesetupload', ['uses' => 'GeneralController@abfeaturesetupload']);


         Route::get('/data/download', ['uses' => 'GeneralController@downloadfile']);
         Route::post('/data/deletefile', ['uses' => 'GeneralController@deletefile']);



         //Form Builder
         Route::get('/form_builder', ['uses' => 'FormBuilderController@index','as' => 'system.formbuilder'] );
         Route::post('/form_builder', ['uses' => 'FormBuilderController@index']);
         //App
         Route::get('/app', ['uses' => 'AppController@index', 'as' => 'system.app']);


     });


    });



     Route::group(['prefix' => 'teamlead', 'namespace' => 'TeamLead'], function()
    {
        Route::get('dashboard',['uses' => 'DashboardController@dashboard', 'as' => 'teamlead.dashboard']);
        Route::get('dashboard/getanalyst',['uses' => 'DashboardController@getAnalystData']);
        Route::get('dashboard/getdata',['uses' => 'DashboardController@getDashboardData']);
        Route::get('dashboard/downloadreport',['uses' => 'DashboardController@downloadReport']);

        /********* old routes *******/
//        Route::get('analysedquery/list',['uses'=>'AnalysisController@queriesList', 'as' => 'analysedquery.index']);
//        Route::get('analysedquery/list/getdata',['uses' => 'AnalysisController@getData']);
//        Route::get('analysedquery/edit/{id}',['uses'=>'AnalysisController@edit' ,'as' => 'analysedquery.edit']);
//        Route::post('analysedquery/editdata/{id}',['uses' => 'AnalysisController@editData']);
//        Route::post('analysedquery/update/{id}',['uses' => 'AnalysisController@update', 'as' => 'analysedquery.update']);

        /******* new routes *********/
        Route::get('analysedquery2/list',['uses'=>'\App\Http\Controllers\QueryData\AnalysisController@queriesList','as' => 'analysedquery.index']);

        Route::get('analysedquery2/edit/{id}',['uses'=>'\App\Http\Controllers\QueryData\AnalysisController@view' ,'as' => 'analysedquery.edit']);
        Route::post('analysedquery2/editdata/{id}',['uses' => '\App\Http\Controllers\QueryData\AnalysisController@editData']);
        Route::post('analysedquery2/update/{id}',['uses' => 'AnalysisController@update', 'as' => 'analysedquery.update']);
        /********* end old/new*********/


        Route::get('skippedquery/list',['uses' => 'SkippedController@skippedList', 'as' => 'skippedquery.index']);
        Route::get('skippedquery/list/getdata',['uses' => 'SkippedController@getData']);
        Route::post('skippedquery/list1','SkippedController@getfilterdata');
        Route::get('skippedquery/getassigned/{id}',['uses'=> 'SkippedController@queryAssigned']);
        Route::post('pagination/fetch_data', 'SkippedController@ajaxfilterPagination');

        Route::get('permission/check',['uses'=>'PermissionController@permissionCheck','as' => 'permission.check']);

        Route::get('reports/weekly',['uses' => 'ReportController@weeklyQA','as' => 'reports.weekly']);
        Route::get('reports/weekly/getdata',['uses' => 'ReportController@getData','as' => 'reports.getData']);
        Route::get('reports/weekly/downloadreport',['uses' => 'ReportController@downloadReport','as' => 'reports.downloadreport']);
         Route::get('reports/weekly/downloadreport2',['uses' => 'ReportController@downloadReportGolden','as' => 'reports.downloadreport']);
         Route::get('reports/weekly/downloadreport1',['uses' => 'ReportController@downloadReportInsight','as' => 'reports.downloadreport']);
        Route::post('reports/weekly/list1','ReportController@getfilterdata');





        //Other Reports
        Route::get('reports/other',['uses' => 'Report2Controller@index', 'as' => 'reports.other']);


    });


//reports
    Route::group(['prefix' => 'reports', 'namespace' => 'Reports'], function()
    {
        //Raters bias Reports
        Route::get('reports/ratersbias',['uses' => 'Ratersbias@index', 'as' => 'reports.ratersbias']);
        Route::get('reports/pbpercentage',['uses' => 'Pbpercentage@index', 'as' => 'reports.pbpercentage']);

        Route::get('reports/buyersproductreport',['uses' => 'BuyersProductReport@index', 'as' => 'reports.buyersproductreport']);
        Route::get('reports/buyersproductreport/downloadreport',['uses' => 'BuyersProductReport@downloadReport']);

        Route::get('reports/buyersbrowsereport',['uses' => 'BuyersBrowseReport@index', 'as' => 'reports.buyersbrowsereport']);
        Route::get('reports/buyersbrowsereport/downloadreport',['uses' => 'BuyersBrowseReport@downloadReport']);

        //Route::get('reports/screenshotdownloadreport',['uses' => 'ScreenshotDownloadReport@index', 'as' => 'reports.screenshotdownloadreport']);
        //Route::get('reports/screenshotdownloadreport/downloadreport',['uses' => 'ScreenshotDownloadReport@downloadReport']);
                 Route::get('reports/screenshotdownloadreport',['uses' => 'ScreenshotDownloadReport@index', 'as' => 'reports.screenshotdownloadreport']);
                Route::get('reports/screenshotdownloadreport/downloadreport',['uses' => 'ScreenshotDownloadReport@downloadReport']);

    });
    //Route::get('addModule',['uses'=>'PermissionController@module']);
});
