<?php
use Illuminate\Support\Facades\Session;
 if (Session::has('login'))
        {
            $login = Session::get('login');
                        //--Get userId from session----//
            $userId = $login[0]['userid'];
                }
$sdate = '';
$edate = '';
if(isset($_GET['startdate'])){
    $sdate = $_GET['startdate'];
}
if(isset($_GET['enddate'])){
    $edate = $_GET['enddate'];
}


$startdate = \DateTime::createFromFormat('d-m-Y H:i:s',$sdate.' 00:00:00');
$enddate = \DateTime::createFromFormat('d-m-Y H:i:s',$edate.' 23:59:59');

if(empty($startdate))
    $startdate = new \DateTime('last sunday midnight');

if(empty($enddate))
    $enddate = new \DateTime();

?>
@extends('layouts.admin.default')
@section('title','Edit Query')
@section('body')



    <div class="panel-body" style="margin-top: 60px;">

        <div class="formViews row">
            <div class="col-xs-12">
                <h3>Download Screenshots</h3>
            </div>

            <div class="col-sm-3">
                <div class="form-group form-group-default required">
                    <label>Start Date</label>
                    <input type="text" class="form-control startdate" name="startdate" value="<?php echo $startdate->format('d-m-Y');?>" required>
                </div>
            </div>

            <div class="col-sm-3">
                <div class="form-group form-group-default required">
                    <label>End Date</label>
                    <input type="text" class="form-control enddate" name="enddate" value="<?php echo $enddate->format('d-m-Y');?>" required>
                </div>
            </div>
                        <div class="col-md-3" id="querySetDiv">

                <?php if(!empty($querySets))
                    { ?>
                        <select id="qsegment" class="cs-select cs-skin-slide" data-init-plugin="cs-select">
                            <option value="0">All Sets</option>
                            <?php foreach($querySets as $qs) {?>
                                <option value="<?php echo $qs->id;?>"><?php echo $qs->name;?></option>
                            <?php } ?>
                        </select>
                   <?php } else   { ?>
                        <i>List could not be loaded!</i>
                <?php }?>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class="form-group form-group-default">
                    <label>Query List (Comma separated)</label>
                    <textarea  class="form-control" id="querylist"  style="height:250px"></textarea>
                </div>
            </div>
        </div>
                <div class="row">
                <!---User Id field Added for Unlimited screen shots for specific user -->
                        <input type="hidden" class="form-control" name="userid" id="userid" value="<?php echo $userId;?>">
                </div>
        <div class="row">
            <div class="col-md-12 text-center">
                <a href="#" class="btn btn-primary" id="screenshot_applydaterange" target="_blank">Download</a>
            </div>

        </div> <!--Form Views Filter -->



    </div> <!-- .panel-body -->

    <style>
        .status{
            padding: 4px;
            border-radius: 4px;
        }
        .pending{
            background: #c00;
            color: #fff;
        }
        .assigned{
            background: yellow;
            color: #111;
        }
        .resolved{
            background: green;
            color: #fff;
        }
        .formViews.row {
            /*margin-top: 97px;*/
            /*margin-left: 100px;*/
        }

        .dt-buttons{
            padding: 20px 0px;
        }
        .dt-buttons > a{
            background: #10cfbd;
            padding: 5px 10px;
            text-align: center;
            color: #fff;
            border-radius: 6px;
            margin-left: 4px;
            transition: box-shadow 0.4s ease-in-out;
        }
        .dt-buttons > a:hover{
            box-shadow: 0 0 8px rgba(0,0,0,0.3);
        }
        .table-responsive{
                /*height: calc(100vh - 150px);*/
            display: table;
            padding-right: 40px;
        }
    </style>



<script async="async" defer="defer">


</script>
