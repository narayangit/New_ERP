<?php

namespace App\Http\Controllers\Reports;


use App\Http\Controllers\Controller;
use App\Models\UserTeam;
use Illuminate\Support\Facades\Session;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\View;
use App\Models\User;

class ScreenshotDownloadReport extends Controller{

    public function index(Request $request)
    {


        $sdate = $request->startdate;
        $edate = $request->enddate;

        $startdate = \DateTime::createFromFormat('d-m-Y H:i:s',$sdate.' 00:00:00');
        $enddate = \DateTime::createFromFormat('d-m-Y H:i:s',$edate.' 23:59:59');

        if(empty($startdate))
            $startdate = new \DateTime('last sunday midnight');

        if(empty($enddate))
            $enddate = new \DateTime();

                //$querySets = \App\Models\QuerySet::whereIn('id',array(1,2,3,4,6,8))->get();
                $querySets = \App\Models\QuerySet::whereIn('id',array(1))->get();
        $analystList = User::where('Roles_id','=', 1)->get();

        return View::make('reports.screenshotdownload')
            ->with(compact('analystList'))
            ->with(compact('querySets'));
    }


    public function downloadReport(Request $request)
    {
        //ini_set('memory_limit', '-1');
                //ini_set('max_execution_time', '-1');
                ini_set('memory_limit', '512M');
        set_time_limit(0);

        $sdate = $request->startdate;
        $edate = $request->enddate;
                $qset = $request->queryset;
        $qsegment = array();
        $qbankids = array();
        $querylist = array();
        $analyst = $request->analyst;
        if($request->has('querylist'))
        {
            if(stripos($request->querylist,'|') === false)
            {
                //single segment
                $querylist = array($request->querylist);
            }
            else
            {
                $querylist = explode('|',$request->querylist);
            }
            $qbankids = \App\Models\QueryBank::select('id')->whereIn('search_term',$querylist)->get()->pluck('id')->values()->toArray();
        }


        $startdate = \DateTime::createFromFormat('d-m-Y H:i:s',$sdate.' 00:00:00');
        $enddate = \DateTime::createFromFormat('d-m-Y H:i:s',$edate.' 23:59:59');

        if(empty($startdate))
            $startdate = new \DateTime('last sunday midnight');

        if(empty($enddate))
            $enddate = new \DateTime();

        if($request->has('qsegment'))
        {
           /* if(stripos($request->qsegment,',') === false)
            {
                //single segment
                $qsegment = array($request->qsegment);
            }
            else
            {
                $qsegment = explode(',',$request->qsegment);
            }*/
                        $qsegment = array($request->qsegment);
                        $querySegmList = \App\Models\QuerySegment::select('id')->whereIn('QuerySet_id',$qsegment)->get()->pluck('id')->values()->toArray();
        }

        $queryAnalysisList = \App\Models\QueryAnalysis::where('analysed_at','>',$startdate)->where('analysed_at','<',$enddate);
        if(!empty($qsegment) && (sizeof($qsegment)>0) && empty($qbankids) && sizeof($querySegmList)>1){
           $queryAnalysisList->whereIn('QuerySegment_id',$querySegmList);
                }else{
                        if(!empty($qbankids))
            $queryAnalysisList->whereIn('QueryBank_id',$qbankids);
                }
        $queryAnalysisList = $queryAnalysisList->get();

        $zip = new \ZipArchive();


        $zipsubfolders = array();
        if ($zip->open(storage_path('app/public').'/download.zip',\ZipArchive::CREATE|\ZipArchive::OVERWRITE) === TRUE) {
            foreach($queryAnalysisList as $qa) {
                if (empty($qa)) //for autocomplete
                {
                    $qa = new \App\Models\QueryAnalysis();
                }

                if(file_exists($qa->screenshot))
                {
                    $screenshotlist = scandir($qa->screenshot, SCANDIR_SORT_ASCENDING);
                    if (!empty($screenshotlist)) {
                        foreach ($screenshotlist as $filename) {
                            if (strlen($filename) > 3) {

                                $date = \DateTime::createFromFormat('Y-m-d H:i:s',$qa->analysed_at);

                                if(!in_array($qa->queryBank->search_term,$zipsubfolders))
                                    $zip->addEmptyDir($qa->queryBank->search_term);

                                $zip->addFile($qa->screenshot . '/' . $filename, $qa->queryBank->search_term.'/'.$qa->id.'-'.$date->format('Y-m-d_h:i').'-'.$filename);
                            }
                        }
                    }
                }

            }


            if($zip->numFiles !== 0 )
            {
                $zip->close();

                $file_name = storage_path('app/public').'/download.zip';

                header("Content-Type: application/zip");
                header("Content-Disposition: attachment; filename=screenshotDownload".time().".zip");
                header("Content-Length: " . filesize($file_name));

                readfile($file_name);
            }
            else
            {
                echo 'No screenshots found';
            }



            exit;
        } else {
            echo 'failed';
        }







    }

/*
 * *
 *
 * select `QA`.`id` AS `id`,`QA`.`QueryBank_id` AS `QueryBank_id`,(select `QB`.`search_term` from `fkart`.`FKB_QueryBank` `QB` where (`QB`.`id` = `QA`.`QueryBank_id`)) AS `Term`,`QA`.`QueryBankHasSegment_id` AS `QueryBankHasSegment_id`,(select `QBHS1`.`ctr` from `fkart`.`FKR_QueryBank_has_QuerySegment` `QBHS1` where (`QBHS1`.`id` = `QA`.`QueryBankHasSegment_id`)) AS `CTR`,(select `QBHS2`.`internal_search_count` from `fkart`.`FKR_QueryBank_has_QuerySegment` `QBHS2` where (`QBHS2`.`id` = `QA`.`QueryBankHasSegment_id`)) AS `Count`,(select `QBHS3`.`successful_search_count` from `fkart`.`FKR_QueryBank_has_QuerySegment` `QBHS3` where (`QBHS3`.`id` = `QA`.`QueryBankHasSegment_id`)) AS `Clicks`,`QA`.`QuerySegment_id` AS `QuerySegment_id`,(select `QS`.`name` from `fkart`.`FKS_QuerySet` `QS` where (`QS`.`id` = (select `Qseg2`.`QuerySet_id` from `fkart`.`FKC_QuerySegment` `Qseg2` where (`Qseg2`.`id` = `QA`.`QuerySegment_id`) limit 1))) AS `Set`,(select `Qseg1`.`name` from `fkart`.`FKC_QuerySegment` `Qseg1` where (`Qseg1`.`id` = `QA`.`QuerySegment_id`)) AS `Segment`,(select `FU`.`email` from `fkart`.`FKB_Users` `FU` where (`FU`.`id` = `QA`.`Analysed_by`)) AS `Analyst`,`QA`.`Analysed_by` AS `Analysed_by`,`QA`.`analysed_at` AS `analysed_at`,`QA`.`time_taken` AS `time_taken`,(select `QT`.`name` from `fkart`.`FKC_QueryType` `QT` where (`QT`.`id` = `QA`.`QueryType_id`)) AS `Type`,(select `Qcat`.`name` from `fkart`.`FKC_QueryCategory` `Qcat` where (`Qcat`.`id` = (select `Qsub1`.`QueryCategory_id` from `fkart`.`FKC_QuerySubCategory` `Qsub1` where (`Qsub1`.`id` = `QA`.`QuerySubcategory_id`) limit 1))) AS `Category1`,(select `Qsub`.`name` from `fkart`.`FKC_QuerySubCategory` `Qsub` where (`Qsub`.`id` = `QA`.`QuerySubcategory_id`)) AS `Category2` from `fkart`.`FKB_QueryAnalysis` `QA` where (`QA`.`QuerySegment_id` in (29,30,31,32,33)) order by `Term`
 */

}
