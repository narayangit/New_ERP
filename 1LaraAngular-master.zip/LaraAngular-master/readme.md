# Laravel & Angularjs Demo Project 

Just an experimental project on Laravel and Angularjs

## License

[MIT license](http://opensource.org/licenses/MIT).
