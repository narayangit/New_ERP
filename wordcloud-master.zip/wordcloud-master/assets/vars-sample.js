var FACEBOOK_APP_ID = '';
var GOOGLE_CLIENT_ID = '';
var IMGUR_CLIENT_ID = '';

var DONATE_HTML = '';
