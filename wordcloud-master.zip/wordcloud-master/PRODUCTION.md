## Build for production

Require `node`. Run

    npm install
    npm run grunt

and find the app in the `production` folder. Run

    npm run grunt deploy

To push the files to `gh-pages` hosting.
