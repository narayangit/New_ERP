'use strict';
callback({
    'hello': 'world'
});
