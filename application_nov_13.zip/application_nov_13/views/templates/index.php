<?php
include 'common/header_view.php';
include 'common/sidebar_view.php';
 ?>
 
	<!-- start page content -->
    <div class="page-content-wrapper">
        <div class="page-content">
            <div class="page-bar">
                <div class="page-title-breadcrumb">
                    <div class=" pull-left">
                        <div class="page-title">Dashboard</div>
                    </div>
                    <ol class="breadcrumb page-breadcrumb pull-right">
                        <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="index.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                        </li>
                        <li class="active">Dashboard</li>
                    </ol>
                </div>
            </div>
           <!-- start widget -->
			<div class="state-overview">
					<div class="row">
				        <div class="col-xl-4 col-md-6 col-12">
				          <div class="info-box bg-b-blue">
				            <span class="info-box-icon push-bottom"><i class="material-icons">group</i></span>
				            <div class="info-box-content">
				              <span class="info-box-text">Total W2RT Users</span>
				              <span class="info-box-number"><?=_count('students');?></span>
				              <div class="progress">
				                <div class="progress-bar" style="width: <?=_count('students');?>0%"></div>
				              </div>
				              
				            </div>
				            <!-- /.info-box-content -->
				          </div>
				          <!-- /.info-box -->
				        </div>
				        <!-- /.col -->
				        <div class="col-xl-4 col-md-6 col-12">
				          <div class="info-box bg-b-yellow">
				            <span class="info-box-icon push-bottom"><i class="material-icons">person</i></span>
				            <div class="info-box-content">
				              <span class="info-box-text">Total Guru's</span>
				              <span class="info-box-number"><?=_count('mentors');?></span>
				              <div class="progress">
				                <div class="progress-bar" style="width: <?=_count('mentors');?>0%"></div>
				              </div>

				            </div>
				            <!-- /.info-box-content -->
				          </div>
				          <!-- /.info-box -->
				        </div>
				        <!-- /.col -->
				        <div class="col-xl-4 col-md-6 col-12">
				          <div class="info-box bg-b-blue">
				            <span class="info-box-icon push-bottom"><i class="material-icons">school</i></span>
				            <div class="info-box-content">
				              <span class="info-box-text">Total Technologies</span>
				              <span class="info-box-number">9</span>
				              <div class="progress">
				                <div class="progress-bar" style="width: 90%"></div>
				              </div>
				            </div>
				            <!-- /.info-box-content -->
				          </div>
				          <!-- /.info-box -->
				        </div>
				      
				      </div>
				</div>
			<!-- end widget -->
             <!-- chart start -->
            <div class="row">
            <div class="col-sm-7">
            	<div class="card card-topline-lightblue">
            		<!-- <div class="card-box"> -->
                         <div class="card-head">
                             <header>Gurukul Sessions Calendar</header>
                         </div>
                         <div class="card-body" >
                         	<div class="panel-body" style="padding-bottom:12%;">
                                    <div id="calendar" class="has-toolbar"> </div>
                                </div>
                         </div>
                        <!-- </div> -->
                     </div>
                </div>
               <div class="col-sm-5">
                   <div class="row">
                    <div class="col-md-12">
                        <div class="card card-topline-lightblue">
                            <div class="card-head">
                                <header>Users Per Technology</header>
                                <div class="tools">
                                    <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
                                    <a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
                                    <a class="t-close btn-color fa fa-times" href="javascript:;"></a>
                                </div>
                            </div>
                            <div class="card-body" id="chartjs_bar_parent">
                                <div class="row">
                                    <canvas id="chartjs_bar2" ></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
				<div class="row">
				   <div class="col-md-12">
						<div class="card card-topline-lightblue">
							<div class="card-head">
								<header>Users Ratio Per Sessions </header>
								<div class="tools">
									<a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
									<a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
									<a class="t-close btn-color fa fa-times" href="javascript:;"></a>
								</div>
							</div>
							<div class="card-body no-padding">
								<div class='row'>
									<div class='col-md-9'>
										<select class='form-control' id='event-list'>
										<?php 
											$events = last_completed_event();
											foreach($events as $event){  ?>
											
											<option value="<?= $event['id'] ?>"><?= $event['title'] ?></option>
										
										<?php }?>
									</select>
									</div>
									<div class='col-md-3'>
										<button class='btn btn-primary pieChartBtn'>Submit</button>
									</div>
								</div>
									
								<div class="row">
									<canvas style="width:500px; height:250px;" id="chartjs_pie2"></canvas>
									<canvas style="width:500px; height:250px;" id="chartjs_pie3"></canvas>
								</div>
							</div>
						</div>
					</div>
				</div>
                </div>
            </div>
             <!-- Chart end -->
        </div>
    </div>
    <!-- end page content -->
    <!-- start chat sidebar -->
    
    <!-- end chat sidebar -->
</div>

<!-- end page container -->
<?php include 'common/footer_view.php'; ?>

<script type="text/javascript">

var events_date = {};

$.ajax({
      url:'<?php echo BASEURL . "event/events_calendar";?>',
      dataType: 'JSON',
      success: function(data){
        //console.log(data);
        events_date = data;
    }
}); //End ajax

var AppCalendar = function() {
    return {
        init: function() {
            this.initCalendar()
        },
        initCalendar: function() {
            if (jQuery().fullCalendar) {
                var e = new Date,
                    t = e.getDate(),
                    a = e.getMonth(),
                    n = e.getFullYear(),
                    r = {};
                $("#calendar").removeClass("mobile"), r = {
                    left: "prev,next,today",
                    center: "title",
                    right: "month,agendaWeek,agendaDay"
                };
                var l = function(e) {
                        var t = {
                            title: $.trim(e.text())
                        };
                        e.data("eventObject", t), e.draggable({
                            zIndex: 999,
                            revert: !0,
                            revertDuration: 0
                        })
                    },
                    o = function(e) {
                        e = 0 === e.length ? "Untitled Event" : e;
                       /* var t = $('<div class="external-event label label-event">' + e + "</div>");*/
                        var t = $('<div class="external-event label label-event-' +e+'">' + e + "</div>");
                        jQuery("#event_box").append(t), l(t)
                    };
                $("#external-events div.external-event").each(function() {
                    l($(this))
                }), $("#event_add").unbind("click").click(function() {
                    var e = $("#event_title").val();
                    o(e)
                }), $("#event_box").html(""), o("holiday"), o("birthday"), o("meeting"), o("competition"), o("dinner"), o("party"), $("#calendar").fullCalendar("destroy"), $("#calendar").fullCalendar({
                    header: r,
                    defaultView: "month",
                    slotMinutes: 15,
                    editable: !0,
                    droppable: !0,
					dayClick: function(date, jsEvent, view) {
						 var d = date.format();
						 $.ajax({
							url:'<?php echo BASEURL . "event/events_list_by_date";?>',
							type:'GET',
							data:{selectDate:d},
							dataType: 'text',
							success:function(result){
								var event_list = JSON.parse(result);
								var list ='';
								$.each(event_list,function(key,value){
									console.log(value);
									list += "<option value='"+value.id+"'>"+value.title+"</option>";
								});
								
								$('#event-list').html(list);
								
							}
						 });
						

					},
                    drop: function(e, t) {
                        var a = $(this).data("eventObject"),
                            n = $.extend({}, a);
                        n.start = e, n.allDay = t, n.className = $(this).attr("data-class"), $("#calendar").fullCalendar("renderEvent", n, !0), $("#drop-remove").is(":checked") && $(this).remove()
                    },
					
                    /***** events ********/
                    events: events_date
                })
            }
        }
    }
}();
AppCalendar.init()

/************** BAR CHART ***************/

$.ajax({
      url:'<?php echo BASEURL . "students-bar-chart";?>',
      dataType: 'JSON',
      success: function(result){
        //console.log(result);
        var technologies = result.map(function(e){
				        	return e.technology;
				        });
        var student_no = result.map(function(e){
				        	return e.student_no;
				        });

        var color = Chart.helpers.color;
	    var barChartData = {
	        labels: technologies,
	        datasets: [{
	             label: 'Users',
	             backgroundColor: color(window.chartColors.blue).alpha(0.5).rgbString(),
	             borderColor: window.chartColors.blue,
	             borderWidth: 1,
	             data: student_no
	        }]
	    };

	     var ctx = document.getElementById("chartjs_bar2").getContext("2d");
		 window.myBar = new Chart(ctx, {
	         type: 'bar',
	         data: barChartData,
	         options: {
				 scales: {
					yAxes: [{
						display: true,
					  ticks: {
							beginAtZero: true
						}
					}],
					xAxes: [{
						ticks: {
							autoSkip: false,
							maxRotation: 45,
							minRotation: 45,
						}
					}]
				  },
	             responsive: true,
	             legend: {
	                position: 'top',
	             },
	             title: {
	                 display: true
	                 //,text: 'Bar Chart'
	             }
	         }
	     });
    }
});

/************** PIE CHART ***************/
// first of all get first option value
var sess_id = $('#event-list').val();
$('.pieChartBtn').click(function(){
sess_id = $('#event-list').val();
	drawPieChart(sess_id);
});
drawPieChart(sess_id);

function drawPieChart(sess_id){
	var datas;
	$.ajax({
		url:'<?php echo BASEURL . "event/get_data_for_pie_chart";?>',
		type:'GET',
		data:{event_id:sess_id},
		dataType: 'JSON',
		success: function(result){
		console.log(result);
			// configuration for applied and attended users
			var config = {
				type: 'pie',
				data: {
					datasets: [{
						data: [result.attended,result.applied],
						backgroundColor: [
							window.chartColors.red,
							window.chartColors.orange
						],
						label: 'Dataset 1'
					}],
					labels: [
						"Attend",
						"Applied"
					]
				},
				options: {
					responsive: false
					
				}
			};
			
			// configuration for attended and feedback 
			var config1 = {
				type: 'pie',
				data: {
					datasets: [{
						data: [result.attended,result.feedback],
						backgroundColor: [
							window.chartColors.red,
							window.chartColors.green
						],
						label: 'Dataset 1'
					}],
					labels: [
						"Attend",
						"Feedback"
					]
				},
				options: {
					responsive: false
					
				}
			};

			var ctx = document.getElementById("chartjs_pie2").getContext("2d");
			window.myPie = new Chart(ctx, config);
			
			var ctx1 = document.getElementById("chartjs_pie3").getContext("2d");
			window.myPie = new Chart(ctx1, config1);	
			
			//
		}
	});
	
	
}

</script>