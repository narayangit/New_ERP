<?php 

include 'common/header_view.php';
include 'common/sidebar_view.php';
?>
<div class="page-content-wrapper">
                <div class="page-content">
                    <div class="page-bar">
                        <div class="page-title-breadcrumb">
                            <div class=" pull-left">
                                <div class="page-title">Form</div>
                            </div>
                            <ol class="breadcrumb page-breadcrumb pull-right">
                                <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="index.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                                </li>
								<li class="active">Feedback Form</li>
                            </ol>
                        </div>
                    </div>

<div class="row">
                        <div class="col-md-12 col-sm-12">
						<?php echo form_open('index.php/student/feedback_save') ?>
						<?php echo validation_errors(); ?>
                            <div class="card card-box">
                                <div class="card-head">
                                    <header>Feedback Form</header>
                                </div>
                                <div class="card-body" id="bar-parent2">
                                    <!--<form action="#" id="form_sample_2" class="form-horizontal" novalidate="novalidate"> -->
									
									<input type='hidden' value='<?= $event_id; ?>' name='event_id'>
									<input type='hidden' value='<?= $student_id; ?>' name='student_id'>
                                        <div class="form-body">
										<div class="row">
                                        <div class="col-md-4">
                                          
                                              
                                                <div class="form-group  ">
                                                <label class="control-label ">First Name
                                                    <span class="required" aria-required="true"> * </span>
                                                </label>
                                                <div class="">
                                                    <div class="input-icon ">
                                                        <i class="fa"></i>
                                                        <input type="text" class="form-control" name="fname" value='<?= $this->session->userdata('username') ?>' required readonly> </div>
                                                </div>
                                            </div>
                                            </div>
                                            <div class="col-md-4">
                                          
                                              
                                          <div class="form-group  ">
                                          <label class="control-label ">Last Name
                                              <span class="required" aria-required="true"> * </span>
                                          </label>
                                          <div class="">
                                              <div class="input-icon ">
                                                  <i class="fa"></i>
                                                  <input type="text" class="form-control" name="lname" value='<?= $feedback->last_name ?>' > </div>
                                          </div>
                                      </div>
                                      </div>
                                      <div class="col-md-4">
                                          
                                              
                                          <div class="form-group  ">
                                          <label class="control-label ">Email Address
                                              <span class="required" aria-required="true"> * </span>
                                          </label>
                                          <div class="">
                                              <div class="input-icon ">
                                                  <i class="fa"></i>
                                                  <input type="text" class="form-control" name="email" value='<?= $this->session->userdata('email') ?>'  readonly required> </div>
                                          </div>
                                      </div>
                                      </div>
                                            <div class="col-md-12">
                                            <div class="form-group">
	                                            <label>Please let us know if (on a scale of 1-5)</label>
	                                            <select class="form-control" aria-required="true" name='let_know' required>
                                                <option value="">Choose</option>
	                                                <option value='the Presenter was easy to understand?' <?= ($feedback->let_know == 'the Presenter was easy to understand?')?'selected':'' ?> >the Presenter was easy to understand?</option>
	                                                <option value='Meeting your fellow participants was one of the highlights of the session?' <?= ($feedback->let_know == 'Meeting your fellow participants was one of the highlights of the session?')?'selected':'' ?> >Meeting your fellow participants was one of the highlights of the session?</option>
	                                                <option value='you look forward to attending the next session?' <?= ($feedback->let_know == 'you look forward to attending the next session?')?'selected':'' ?> >you look forward to attending the next session?</option>
	                                            
	                                            </select>
	                                        </div>
                                            </div>
                                            <div class="col-md-4">
                                          
                                              
                                          <div class="form-group  ">
                                          <label class="control-label ">Which Session did you attend?
                                              <span class="required" aria-required="true"> * </span>
                                          </label>
                                          <div class="">
                                              <div class="input-icon ">
                                                  <i class="fa"></i>
                                                  <input type="text" class="form-control" name="session_name" value='<?= $feedback->session_name ?>' required> </div>
                                          </div>
                                      </div>
                                      </div>
                        
                                      <div class="col-md-8">
                                          
                                              
                                          <div class="form-group  ">
                                          <label class="control-label ">How satisfied are you with the content of the session?
                                              <span class="required" aria-required="true"> * </span>
                                          </label>
                                          <div class="">
                                              <div class="input-icon ">
                                                  <i class="fa"></i>
                                                  <input type="text" class="form-control" name="satisfied" value='<?= $feedback->satisfied ?>' required> </div>
                                          </div>
                                      </div>
                                      </div>
                                      <div class="col-md-6">
                                          
                                              
                                          <div class="form-group  ">
                                          <label class="control-label ">Any information that you think was not covered in the session?
                                              <span class="required" aria-required="true"> * </span>
                                          </label>
                                          <div class="">
                                              <div class="input-icon ">
                                                  <i class="fa"></i>
                                                  <input type="text" class="form-control" name="information" value='<?= $feedback->information ?>' required> </div>
                                          </div>
                                      </div>
                                      </div>
                                      <div class="col-md-6">
                                          
                                              
                                          <div class="form-group  ">
                                          <label class="control-label ">Are you already working in your area of primary interest?
                                              <span class="required" aria-required="true"> * </span>
                                          </label>
                                          <div class="">
                                              <div class="input-icon ">
                                                  <i class="fa"></i>
                                                  <input type="text" class="form-control" name="interest" value='<?= $feedback->interest ?>' required> </div>
                                          </div>
                                      </div>
                                      </div>
                              
                                      <div class="col-md-6">
                                          
                                        
                                          <div class="form-group  ">
                                          <label class="control-label ">Overall assessment of the event?
                                              <span class="required" aria-required="true"> * </span>
                                          </label>
                                          <div class="">
                                              <div class="input-icon ">
                                                  <i class="fa"></i>
                                                  <textarea class="form-control" rows="2" id="assessment" name='assessment' required><?= $feedback->assessment ?></textarea> </div>
                                          </div>
                                      </div>
                                      </div>   
                                      <div class="col-md-6">
                                          
                                        
                                          <div class="form-group  ">
                                          <label class="control-label ">Any additional comments?
                                              <span class="required" aria-required="true"> * </span>
                                          </label>
                                          <div class="">
                                              <div class="input-icon ">
                                                  <i class="fa"></i>
                                               
                                                  <textarea class="form-control" rows="2" id="comment" name='comment' required><?= $feedback->last_name?></textarea>
                                                </div>
                                          </div>
                                      </div>
                                      </div>  
                                      <div class="col-md-12">
										<div class="form-group  ">
                                         <p> <label class="control-label ">Rate the relevance of the session on a scale of 1-5?
                                              <span class="required" aria-required="true"> * </span>
                                          </label></p>
                                          
                                          <div class="radio radio-yellow form-check-inline">
                                                    <input id="radiobg2" name="rating" type="radio" value='1' <?= ($feedback->rating == 1)?'checked':'' ?> >
                                                    <label for="radiobg2">
                                                        1
                                                    </label>
                                                </div>
                                                <div class="radio radio-yellow form-check-inline">
                                                    <input id="radiobg3" name="rating" type="radio" value='2' <?= ($feedback->rating == 2)?'checked':'' ?>>
                                                    <label for="radiobg3">
                                                        2
                                                    </label>
                                                </div>
                                                <div class="radio radio-yellow form-check-inline">
                                                    <input id="radiobg4" name="rating" type="radio" value='3' <?= ($feedback->rating == 3)?'checked':'' ?>>
                                                    <label for="radiobg4">
                                                        3
                                                    </label>
                                                </div>
                                                <div class="radio radio-yellow form-check-inline">
                                                    <input id="radiobg5" name="rating" type="radio" value='4' <?= ($feedback->rating == 4)?'checked':'' ?>>
                                                    <label for="radiobg5">
                                                        4
                                                    </label>
                                                </div>
                                                <div class="radio radio-yellow form-check-inline">
                                                    <input id="radiobg6" name="rating" type="radio" value='5' <?= ($feedback->rating == 5)?'checked':'' ?>>
                                                    <label for="radiobg6">
                                                        5
                                                    </label>
                                                </div>
                                      </div>
                                      </div>                   
                                            </div>
                                            </div>
                                        </div>

										<?php if(count($feedback)==0): ?>
                                         <div class="form-group">
                                            <div class="offset-md-4 col-md-8">
                                                <input type="submit" class="btn btn-info m-r-20" value='Submit'>
                                                <!--<button type="button" class="btn btn-default">Cancel</button>-->
                                            </div>
                                        </div>
										<?php endif; ?>
                                    
                                </div>
								</form>
                            </div>
                        </div>


</div>
</div>

<?php include 'common/footer_view.php'; ?>