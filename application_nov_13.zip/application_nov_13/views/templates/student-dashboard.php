<?php 
include 'common/header_view.php';
include 'common/sidebar_view.php';
$student_id = $this->session->userdata('id');
?>
<style>
.close {
    text-indent: -10px; 
    
}
</style>

			<!-- start page content -->
            <div class="page-content-wrapper">
                <div class="page-content">
				<div class="page-bar">
                        <div class="page-title-breadcrumb">
                            <div class=" pull-left">
                                <div class="page-title">Session Details</div>
                            </div>
                            <ol class="breadcrumb page-breadcrumb pull-right">
                                <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="index.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                                </li>
                                <li class="active">Session Details</li>
                            </ol>
                        </div>
                    </div>
                <div class="row">
					<div class="col-md-12">
					<?php if($this->session->flashdata('msg')!=''){ ?>
						<div class="alert alert-success alert-dismissible">
						  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						  <?= $this->session->flashdata('msg'); ?>
						</div>
					<?php } ?>
										
					
                            <div class="panel tab-border card-box event-info">
                                <header class="panel-heading panel-heading-gray custom-tab ">
                                    <ul class="nav">
                                        <li class="nav-item"><a href="#about" data-toggle="tab" >Past Session</a>
                                        </li>
                                        <li class="nav-item"><a href="#profile" data-toggle="tab" class="active">Upcoming Session</a>
                                        </li>
                                    </ul>
                                </header>
                                <div class="panel-body">
                                    <div class="tab-content">
                        
                <div class="tab-pane " id="about">
                    <div class="row thumb-icon">

	                <?php $rating = ''; foreach ($student_past_event as $events) {
						$rating = student_rating($events->id,$student_id);
					?>
						<div class="col-lg-4 col-md-6 col-12 col-sm-6 ">
							<div class="blogThumb">
                                <div class="thumb-center"><img class="img-responsive" alt="user" src="../assets/img/course/course1.jpg">
                                <div class="promo-logo">
									<img class="img-responsive" alt="user" src="../assets/img/course/course1.jpg">
								</div>
                            </div>
								
                                <div class="course-box">
                                <h5 class="event-name text-center"><?php echo $events->technology;?></h5>
									<p class="event-add-info"><span><i class="fa fa-user" aria-hidden="true"></i><?php echo $events->event_name;?></span></p>
									<p><span> <i class="fa fa-calendar-o" aria-hidden="true"></i><?php echo $events->start_date." - ".$events->end_date;?></span></p>
			                        <p class="event-add-info"><span><i class="fa fa-address-card-o" aria-hidden="true"></i><?php echo $events->city." ".$events->address;?></span></p>
                                    
									<p><a href="<?= BASEURL. "feedback/".$events->id."/".$student_id ?>" class="btn btn-sm btn-circle btn-primary " >Feedback </a></p>
			                    </div>
							</div>
						</div>
					<?php } ?>
					</div>
			    </div>
				
		        <div class="tab-pane active" id="profile">
		           <div class="row thumb-icon">
					<?php foreach ($student_upcoming_event as $events) { ?>
		                <div class="col-lg-3 col-md-6 col-12 col-sm-6 ">
							<div class="blogThumb">
								<div class="thumb-center"><img class="img-responsive" alt="user" src="../assets/img/course/course1.jpg"></div>
								<div class="course-box">
									<p><span> <i class="fa fa-address-card" aria-hidden="true"></i><?php echo $events->technology;?></span></p>
									<p><span><i class="fa fa-user" aria-hidden="true"></i><?php echo $events->event_name;?></span></p>
									<p><span> <i class="fa fa-calendar-o" aria-hidden="true"></i><?php echo $events->start_date." - ".$events->end_date;?></span></p>
			                        <p><span><i class="fa fa-address-card-o" aria-hidden="true"></i><?php echo $events->city." ".$events->address;?></span></p>
			                        <p><a href="javascript:void(0);" class="btn btn-round btn-success" onClick="applyforevent(this,'<?=$events->id;?>','<?=$events->mentor_id;?>');"><?php echo (has_applied($student_id,$events->id)) ? 'Applied': 'Apply';?></a></p>

			                    </div>
							</div>
						</div>
					<?php } ?>
					</div>
                </div>

                </div>
            </div>
        </div>
    </div>
</div>  
</div>

  
  </div>
</div>

<?php include 'common/footer_view.php'; ?>

    <script type="text/javascript">

      function applyforevent(obj, eid,mid) {
            $.ajax({
                url: '<?php echo BASEURL . "applyforevent";?>',
                method :'post',
                data: {'event_id': eid,'mentor_id': mid},
                success : function(data){
                  console.log(data);
                  if(data == 1){
                      $(obj).text('Applied');
                    }
                  }
            });
        }

        /* Open Modal Popup*/
        function feedbackModal(eid,mid,isfeedback){
            document.getElementsByName("event_id")[0].value = eid;
            document.getElementsByName("mentor_id")[0].value = mid;
            document.getElementsByName("feedback")[0].value = isfeedback;
            
        }       
        
    </script>
    
  </body>
</html>