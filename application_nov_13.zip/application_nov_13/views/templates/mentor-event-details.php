<?php 
include 'common/header_view.php';
include 'common/sidebar_view.php';
?>
			<!-- start page content -->
            <div class="page-content-wrapper">
                <div class="page-content">
				<div class="page-bar">
				<?php echo $this->session->flashdata('msg');?>
            <div class="page-title-breadcrumb">
                <div class=" pull-left">
                    <div class="page-title">Session Details</div>
                </div>
                <ol class="breadcrumb page-breadcrumb pull-right">
                    <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="index.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                    </li>
                    <li class="active">Session Details</li>
                </ol>
            </div>
        </div>

                <div class="row">
                        <div class="col-md-12">
                            <div class="panel tab-border card-box event-info">
                                <header class="panel-heading panel-heading-gray custom-tab " style="padding:0px;">
                                    <ul class="nav">
                                        <!-- <li class="nav-item"><a href="#home" data-toggle="tab" class="active">Today's Event</a>
                                        </li> -->
                                       <li class="nav-item">
                                        	<a href="#profile" data-toggle="tab" class="active" >Upcoming Session</a>
                                        </li>
										 <li class="nav-item">
                                        	<a href="#about" data-toggle="tab" >Past Session</a>
                                        </li>
                                    </ul>
                                </header>
                    <div class="panel-body">
                        <div class="tab-content">
			               
						<div class="tab-pane active" id="profile">
							<div class="row thumb-icon">
								<?php foreach ($event_details as $events) {

						  $upcomingDate = date('Y-m-d', strtotime($events->start_date));
						  $now = date('Y-m-d');

						  if( $upcomingDate >= $now ){
									$total_applied_students = (int) count_applied_students($events->id);
								 ?>
									<div class="col-lg-3 col-md-6 col-12 col-sm-6 ">
										<div class="blogThumb">
											<div class="thumb-center"><img class="img-responsive" alt="user" src="../assets/img/course/course1.jpg"></div>
											<div class="course-box">
												<!-- <h4>Event Details</h4> -->
												<p><span> <i class="fa fa-address-card" aria-hidden="true"></i><?php echo $events->technology;?></span></p>
												<p><span><i class="fa fa-user" aria-hidden="true"></i><?php echo get_name($events->mentor_id);?></span></p>
												<p><span> <i class="fa fa-calendar-o" aria-hidden="true"></i><?php echo $events->start_date." - ".$events->end_date;?></span></p>
												<p><span><i class="fa fa-address-card-o" aria-hidden="true"></i><?php echo $events->city." ".$events->address;?></span></p>
												<p><a href="<?= BASEURL . 'event-attendance/1/'.$events->id.'/'.$events->mentor_id;?>" class="btn btn-round btn-primary btn-sm">Registered <?=$total_applied_students;?></a>
											</div>
										</div>
									</div>
								<?php } 

						  }
						?>
								</div>
							</div>
							
							<div class="tab-pane" id="about">
			                    <div class="row thumb-icon">

                        <?php foreach ($event_details as $events) {
                          $pastDate = date('Y-m-d', strtotime($events->start_date));
                          $now = date('Y-m-d');

                          if( $pastDate < $now ){
                        	$total_applied_students = (int) count_applied_students($events->id);
							$total_attended_students = (int) count_attend_students($events->id);
                         ?>
		                <div class="col-lg-4 col-md-6 col-12 col-sm-6">
							<div class="blogThumb">
								<div class="thumb-center">
								<img class="img-responsive" alt="user" src="../assets/img/course/course1.jpg">
								<div class="promo-logo">
									<img class="img-responsive" alt="user" src="../assets/img/course/course1.jpg">
								</div>
								</div>
								<div class="course-box">
									
                                <h5 class="event-name text-center"> <?php echo $events->technology;?></h5>
									<p><span><i class="fa fa-user" aria-hidden="true"></i><?php echo get_name($events->mentor_id);?></span></p>
									<p><span> <i class="fa fa-calendar-o" aria-hidden="true"></i><?php echo $events->start_date." - ".$events->end_date;?></span></p>
			                        <p class="event-add-info"><span><i class="fa fa-address-card-o" aria-hidden="true"></i><?php echo $events->city." ".$events->address;?></span></p>

			                        <p>
										<a href="<?= BASEURL . 'event-attendance/1/'.$events->id.'/'.$events->mentor_id;?>" class="btn btn-circle btn-primary btn-sm">Registered <span class="num"><?=$total_applied_students;?></span></a>
										<a href="<?= BASEURL . 'event-attendance/2/'.$events->id.'/'.$events->mentor_id;?>" class="btn btn-circle  btn-success btn-sm">Participant <span class="num"><?=$total_attended_students?></span></a> <br>
										<span style='float:right; margin-right:20%; font-size:10px; color:red'> * check feedback</span>
									</p>
			                    </div>
							</div>
						</div>
					<?php } 
              }
          ?>
					</div>
		        </div>
			
     
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
</div>

	<?php include 'common/footer_view.php'; ?>
	</body>
</html>