<?php include 'include/head.php'; ?>
<body>
    <div class="limiter">
		<div class="container-login100 page-background">
			<div class="wrap-login100">
				<form class="login100-form validate-form">
					<span class="login100-form-logo">
						<img alt="" src="../assets/img/logo-2.png">
					</span>
					<!-- <span class="login100-form-title  p-t-27">
						Forgot Your Password?
					</span> -->
					<!-- <p class="text-center txt-small-heading">
						Forgot Your Password? Let Us Help You.
					</p> -->
					<div class="wrap-input100 validate-input" data-validate = "Enter username">
						<input class="input100" type="text" name="username" placeholder="Enter Your Register Email Address">
						<span class="focus-input100" data-placeholder="&#xf207;"></span>
					</div>
					<div class="container-login100-form-btn">
						<button class="login100-form-btn">
							Send
						</button>
					</div>
					<div class="text-center p-t-27">
						<a class="txt1" href="login.php">
							Login?
						</a>
					</div>
				</form>
			</div>
		</div>
	</div>
    <!-- start js include path -->
    <script src="../assets/plugins/jquery/jquery.min.js" ></script>
    <!-- bootstrap -->
    <script src="../assets/plugins/bootstrap/js/bootstrap.min.js" ></script>
    <script src="../assets/js/pages/extra-pages/pages.js" ></script>
    <!-- end js include path -->
</body>
</html>