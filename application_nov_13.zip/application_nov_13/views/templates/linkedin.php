<?php 
include 'common/header_view.php';
include 'common/sidebar_view.php';
?>
			 <!-- end sidebar menu -->
			<!-- start page content -->
            <div class="page-content-wrapper">
                <div class="page-content">
                    <div class="page-bar">
                        <div class="page-title-breadcrumb">
                            <div class=" pull-left">
                                <div class="page-title">Linkedin Authentication</div>
                            </div>
                            <ol class="breadcrumb page-breadcrumb pull-right">
                                <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="index.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                                </li>
                                <li class="active">Linkedin Authentication</li>
                            </ol>
                        </div>
					</div>
					<div class="col-md-12">

<div class="card card-topline-aqua">
    <div class="card-body no-padding height-9">
       <!--  <div class="profile-userbuttons">
		<?php 
		if(isset($oauthURL) && $oauthURL != ""){ ?>
			<a class="btn btn-circle blue" href="<?= $oauthURL ?>"><i class="fa fa-linkedin-square" aria-hidden="true"></i>
				Login with LinkedIn
			</a> 
		<?php } ?>
        </div> -->
		<?php if($this->session->userdata('userData')){  ?>
			<div class="welcome-msz col-md-8 offset-md-2 text-center" >
				<h1 class="text-ultra-bold full-width mb-0 text-uppercase welcome-heading" style="font-family: 'Merriweather', serif; color:#26c281;">Thank you <?php echo $_SESSION["formattedName"] ?>, for registering with us!!! </h1>
				<h3 class="text-normal full-width my-2 text-uppercase welcome-heading" style="font-family: 'Merriweather', serif; color:#3598dc;">Hello! Welcome to Nasscom </h3>
				<h4><a href="mailto:user@mattsenkumar.com" class="welcome-heading"><?php echo $_SESSION["userData"]["email"] ?></a></h4>
			</div>
		<?php }else{ ?>
			<div class="profile-userbuttons">
			<?php 
			if(isset($oauthURL) && $oauthURL != ""){ ?>
				<a class="btn btn-circle blue" href="<?= $oauthURL ?>"><i class="fa fa-linkedin-square" aria-hidden="true"></i>
					Login with LinkedIn
				</a>
	        </div>
			<?php }
			}
			?>



                                      
                                    </div>
                                </div>
</div>

                    <!-- <div class="row">


						<div class="col-md-12">
							<div class="" id="line-parent">
							<h4>Click this button to authenticate</h4>
							
							<?php
								if($this->session->userdata('userData')){  ?>
							
							<div class="container col-sm-12">
							   <?php if (isset($error_msg)) { ?>
								<div class="alert alert-dismissable alert-danger">
								  <button data-dismiss="alert" class="close" type="button">x</button>
								  <p><?php echo $error_msg; ?></p>
								</div>
							  <?php } else { ?>
								<h2>Thank you <?php echo $_SESSION["formattedName"] ?>, for registering with us!!!</h2>
								<h2>Welcome back <?php echo $_SESSION["formattedName"] ?>!!!</h2>
							  <?php } ?>
							   <h5>Your email id is: <span style="text-decoration:underline;"><?php echo $_SESSION["userData"]["email"] ?></span></h5>
							  <div class="margin20"></div>
							</div>
							
								<?php } ?>
							
							<?php if(isset($oauthURL) && $oauthURL != ""){ ?>
								<div class='col-md-offset-3 col-md-3'>
									<a class="btn btn-block btn-social btn-linkedin" href="<?= $oauthURL ?>">
								<i class="fa fa-linkedin"></i> Login with LinkedIn
								</a>
								</div>	
							<?php } ?>
							   
							</div>
						</div>
					</div> -->
				</div>
            <!-- end page content -->
			</div>
        <!-- end page container -->
      
<?php include 'common/footer_view.php'; ?>
  </body>
</html>