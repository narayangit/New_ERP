<!DOCTYPE html>
<html lang="en">
<?php define('BASEURL', base_url() . 'index.php/'); ?>
<!-- BEGIN HEAD -->
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <meta name="description" content="Responsive Admin Template" />
    <meta name="author" content="SmartUniversity" />
    <title><?php echo ($title) ? 'MK | ' . $title : 'MK'; ?> </title>
    <!-- google font -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet" type="text/css" />
    <link href="https://fonts.googleapis.com/css?family=Merriweather:400,700" rel="stylesheet">
    <!-- login CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/css/pages/extra_pages.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/plugins/iconic/css/material-design-iconic-font.min.css');?>">
    <!-- icons -->
    <link href="<?php echo base_url('assets/fonts/simple-line-icons/simple-line-icons.min.css');?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url('assets/fonts/font-awesome/css/font-awesome.min.css');?>" rel="stylesheet" type="text/css"/>
	<link href="<?php echo base_url('assets/fonts/material-design-icons/material-icon.css');?>" rel="stylesheet" type="text/css" />
	<!--bootstrap -->
	<link href="<?php echo base_url('assets/plugins/bootstrap/css/bootstrap.min.css');?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url('assets/plugins/summernote/summernote.css');?>" rel="stylesheet">
	<!-- full calendar -->
	<link href="<?php echo base_url('assets/plugins/fullcalendar/fullcalendar.css');?>" rel="stylesheet" type="text/css" />
	 <!-- data tables -->
    <link href="<?php echo base_url('assets/plugins/datatables/plugins/bootstrap/dataTables.bootstrap4.min.css');?>" rel="stylesheet" type="text/css"/>
    <!-- Material Design Lite CSS -->
	<link rel="stylesheet" href="<?php echo base_url('assets/plugins/material/material.min.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/material_style.css');?>">
  
       
	<!-- inbox style -->
    <link href="<?php echo base_url('assets/css/pages/inbox.min.css" rel="stylesheet" type="text/css');?>" />
	<!-- Theme Styles -->
    <link href="<?php echo base_url('assets/css/theme/light/theme_style.css');?>" rel="stylesheet" id="rt_style_components" type="text/css" />
    <link href="<?php echo base_url('assets/css/plugins.min.css');?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url('assets/css/pages/formlayout.css');?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url('assets/css/theme/light/style.css');?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url('assets/css/responsive.css');?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url('assets/css/theme/light/theme-color.css');?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url('assets/plugins/dropzone/dropzone.css');?>" rel="stylesheet" media="screen">
    <!-- PICKER -->
    <link href="<?php echo base_url('assets/plugins/bootstrap-datetimepicker/css/bootstrap-datetimepicker.min.css');?>" rel="stylesheet" media="screen">
    <link href="<?php echo base_url('assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.css');?>" rel="stylesheet" media="screen">
	<!-- favicon -->
    <link rel="shortcut icon" href="<?php echo base_url('assets/img/favicon.ico');?>" /> 
    <link href="<?php echo base_url('assets/css/mystyle.css');?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url('assets/css/rating.css');?>" rel="stylesheet" type="text/css" />

    <link href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar-scheduler/1.9.4/scheduler.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url('assets/css/jquery.rateyo.min.css');?>"  type="text/css" />
	
	
 </head>