<!-- END HEAD -->

<body class="page-header-fixed sidemenu-closed-hidelogo page-content-white page-md header-white white-sidebar-color logo-indigo">
    <div class="page-wrapper">
        <!-- start header -->
        <div class="page-header navbar navbar-fixed-top">
            <div class="page-header-inner ">
                <!-- logo start -->
                <div class="page-logo">
				<a href="index.html" class="logo">
                  
					<span class="logo-mk" ><img src="<?php echo base_url('assets/images/logo.png');?>" alt="" style="width:100%;"></span> </a>
					
                </div>
                <!-- logo end -->
				<ul class="nav navbar-nav navbar-left in">
					<li><a href="#" class="menu-toggler sidebar-toggler"><i class="icon-menu"></i></a></li>
				</ul>
	  
				
                <!-- start mobile menu -->
                <a href="javascript:void(0);" class="menu-toggler responsive-toggler" data-toggle="collapse" data-target=".navbar-collapse">
                    <span></span>
                </a>
               <!-- end mobile menu -->
                <!-- start header menu -->
                <div class="top-menu">
                    <ul class="nav navbar-nav pull-right">
                    	<li><a href="javascript:void(0);" class="fullscreen-btn"><i class="fa fa-arrows-alt"></i></a></li>

                        <!-- start notification dropdown -->
                        <li class="dropdown dropdown-extended dropdown-notification" id="header_notification_bar">
                            <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                                <i class="fa fa-bell-o"></i>
                                <span class="badge headerBadgeColor1 count"></span>
                            </a>
                            <ul class="dropdown-menu">
                                <li class="external">
                                    <h3><span class="bold">Notifications</span></h3>
                                    <span class="notification-label purple-bgcolor newcount"></span>
                                </li>
                                <li>
                                    <ul class="dropdown-menu-list small-slimscroll-style" data-handle-color="#637283">
                                        <li><a href="javascript:void(0);">Not Found!</a></li>
                                        <!-- <li>
                                            <a href="javascript:void(0);">
                                                <span class="time">3 mins</span>
                                                <span class="details">
                                                <span class="notification-icon circle purple-bgcolor"><i class="fa fa-user o"></i></span>
                                                <b>John Micle </b>is now following you. </span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0);">
                                                <span class="time">7 mins</span>
                                                <span class="details">
                                                <span class="notification-icon circle blue-bgcolor"><i class="fa fa-comments-o"></i></span>
                                                <b>Sneha Jogi </b>sent you a message. </span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0);">
                                                <span class="time">12 mins</span>
                                                <span class="details">
                                                <span class="notification-icon circle pink"><i class="fa fa-heart"></i></span>
                                                <b>Ravi Patel </b>like your photo. </span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0);">
                                                <span class="time">15 mins</span>
                                                <span class="details">
                                                <span class="notification-icon circle yellow"><i class="fa fa-warning"></i></span> Warning! </span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0);">
                                                <span class="time">10 hrs</span>
                                                <span class="details">
                                                <span class="notification-icon circle red"><i class="fa fa-times"></i></span> Application error. </span>
                                            </a>
                                        </li> -->
                                    </ul>
                                    <div class="dropdown-menu-footer">
                                        <a href="<?php echo BASEURL . 'mentor-ask';?>"> All notifications </a>
                                    </div>
                                </li>
                            </ul>
                        </li>
                        <!-- end notification dropdown -->
                                    
 						<!-- start manage user dropdown -->
 						<li class="dropdown dropdown-user">
                            <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                                <img alt="" class="img-circle " src="<?php echo base_url('assets/img/dp.jpg');?>" />
                                <span class="username username-hide-on-mobile"> <?php echo $this->session->userdata('username');?> </span>
                                <i class="fa fa-angle-down"></i>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-default">
                                <li>
									<?php if($this->session->userdata('usertype') == 2){ ?>
										<a href="<?php echo BASEURL . 'mentor/profile';?>">
                                        <i class="icon-logout"></i>Profile</a>
									<?php }else if($this->session->userdata('usertype') == 3){ ?>
										<a href="<?php echo BASEURL . 'student/profile';?>">
                                        <i class="icon-logout"></i>Profile</a>
									<?php } ?>
                                    
                                </li>
								<li>
                                    <a href="<?php echo BASEURL . 'login/logout';?>">
                                        <i class="icon-logout"></i> Log Out </a>
                                </li>
                            </ul>
                        </li>
                        <!-- end manage user dropdown -->
                  
                    </ul>
                </div>
            </div>
        </div>
        <!-- end header -->

	
        <!-- start page container -->
        <div class="page-container">
 			<!-- start sidebar menu -->
 			<div class="sidebar-container">
 				<div class="sidemenu-container navbar-collapse collapse fixed-menu">
	                <div id="remove-scroll" class="left-sidemenu">
	                    <ul class="sidemenu  page-header-fixed slimscroll-style" data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200" style="padding-top: 20px">
	                        <li class="sidebar-toggler-wrapper hide">
	                            <div class="sidebar-toggler">
	                                <span></span>
	                            </div>
	                        </li>
	                        <li class="sidebar-user-panel">
	                            <div class="user-panel">
	                                <div class="pull-left image">
	                                    <img src="<?php echo base_url('assets/img/dp.jpg');?>" class="img-circle user-img-circle" alt="User Image" />
	                                </div>
	                                <div class="pull-left info">
	                                    <p> <?php echo $this->session->userdata('username');?> </p>
	                                    <a href="#"><i class="fa fa-circle user-online"></i><span class="txtOnline"> Online</span></a>
	                                </div>
	                            </div>
	                        </li>

                        <!-- For Admin sidebar -->
	                     <?php 
                         if( $this->session->userdata('usertype') == 1 ){ ?>
                            <li class="nav-item">
                                <a href="<?php echo BASEURL . 'dashboard1';?>" class="nav-link nav-toggle"> <i class="material-icons">dashboard</i> 
                                <span class="title">Dashboard</span></a>
                            </li>
                            <li class="nav-item">
                            <a href="<?php echo BASEURL . 'mentor-details';?>" class="nav-link nav-toggle"><i class="material-icons">group</i>
                                <span class="title">Gurus</span></a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo BASEURL . 'event-details';?>" class="nav-link nav-toggle"> <i class="material-icons">event</i> 
                                <span class="title">Sessions</span></a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo BASEURL . 'technologies';?>" class="nav-link nav-toggle"> <i class="material-icons">computer</i> 
                                <span class="title">Technologies</span></a>
                            </li>
							<li class="nav-item">
                                <a href="<?php echo BASEURL . 'ask-history/1';?>" class="nav-link nav-toggle"> <i class="material-icons">history</i> 
                                <span class="title">Ask History</span></a>
                            </li>
							
                            
                        <!-- For Mentor sidebar -->
                         <?php }

                         if($this->session->userdata('usertype') == 2 ){ ?>
                            <li class="nav-item">
	                            <a href="<?php echo BASEURL . 'dashboard2';?>" class="nav-link nav-toggle"> <i class="material-icons">dashboard</i>
	                                <span class="title">Guru Dashboard</span> 
	                            </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo BASEURL . 'mentor-event-details';?>" class="nav-link nav-toggle"> <i class="material-icons">list</i>
                                    <span class="title">Session Details</span> 
                                </a>
                            </li>
							<li class="nav-item">
                                <a href="<?php echo BASEURL . 'auth';?>" class="nav-link nav-toggle"> <i class="fa fa-linkedin"></i>
                                    <span class="title">Linkedin Auth</span> 
                                </a>
                            </li>
							<li class="nav-item">
    	                            <a href="<?php echo BASEURL . 'mentor-ask';?>" class="nav-link nav-toggle"> <i class="material-icons">list</i>
    	                                <span class="title">Ask a question</span> 
    	                            </a>
                                </li>
                            <!-- For Student sidebar -->
                            <?php }

                            if($this->session->userdata('usertype') == 3 ){ ?>

                                <li class="nav-item">
                                    <a href="<?php echo BASEURL . 'dashboard3';?>" class="nav-link nav-toggle"> <i class="material-icons">dashboard</i>
                                        <span class="title">User Dashboard</span> 
                                    </a>
                                </li>

								<li class="nav-item">
									<a href="<?php echo BASEURL . 'student-event-details';?>" class="nav-link nav-toggle"> <i class="material-icons">list</i>
										<span class="title">Session Details</span> 
									</a>
								</li>
	
                                <li class="nav-item">
    	                            <a href="<?php echo BASEURL . 'ask';?>" class="nav-link nav-toggle"> <i class="material-icons">list</i>
    	                                <span class="title">Ask a question</span> 
    	                            </a>
                                </li>

                            <?php } ?>

	                    </ul>
	                </div>
                </div>
            </div>
            <!-- end sidebar menu --> 