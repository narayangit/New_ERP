<div class="page-footer">
            <div class="page-footer-inner"> 2017 &copy; All Rights Reserved by 
            <a href="https://www.mattsenkumar.com/" target="_top" class="makerCss">MattsenKumar LLC.</a>
            </div>
            <div class="scroll-to-top">
                <i class="icon-arrow-up"></i>
            </div>
        </div>
        <!-- end footer -->
    </div>
    <!-- start js include path -->
    <script src="<?php echo base_url('assets/plugins/jquery/jquery.min.js');?>" ></script>
    <script src="<?php echo base_url('assets/plugins/popper/popper.js');?>" ></script>
    <script src="<?php echo base_url('assets/plugins/jquery-blockui/jquery.blockui.min.js');?>" ></script>
	<script src="<?php echo base_url('assets/plugins/jquery-slimscroll/jquery.slimscroll.js');?>"></script>
    <script src="<?php echo base_url('assets/plugins/jquery-ui/jquery-ui.min.js');?>" ></script>

    <!-- bootstrap -->
    <script src="<?php echo base_url('assets/plugins/bootstrap/js/bootstrap.min.js');?>" ></script>
    <script src="<?php echo base_url('assets/plugins/bootstrap-switch/js/bootstrap-switch.min.js');?>" ></script>
    <script src="<?php echo base_url('assets/plugins/sparkline/jquery.sparkline.js');?>" ></script>
	<script src="<?php echo base_url('assets/js/pages/sparkline/sparkline-data.js');?>" ></script>
 
    <!-- Common js-->
	<script src="<?php echo base_url('assets/js/app.js');?>" ></script>
    <script src="<?php echo base_url('assets/js/layout.js');?>" ></script>
    <script src="<?php echo base_url('assets/js/theme-color.js');?>" ></script>
   
    <!-- material -->
    <script src="<?php echo base_url('assets/plugins/material/material.min.js');?>"></script>
    <!-- chart js -->
    <script src="<?php echo base_url('assets/plugins/chart-js/Chart.bundle.js');?>" ></script>
    <script src="<?php echo base_url('assets/plugins/chart-js/utils.js');?>" ></script>
    <script src="<?php echo base_url('assets/js/pages/chart/chartjs/home-data.js');?>" ></script>
    <script src="<?php echo base_url('assets/js/pages/chart/chartjs/chartjs-data.js');?>" ></script>
    <!-- summernote -->
    <script src="<?php echo base_url('assets/plugins/summernote/summernote.js');?>" ></script>
    <script src="<?php echo base_url('assets/js/pages/summernote/summernote-data.js');?>" ></script>
   
   <!-- calendar -->
   <script src="<?php echo base_url('assets/plugins/moment/moment.min.js');?>" ></script>
    <script src="<?php echo base_url('assets/plugins/fullcalendar/fullcalendar.min.js');?>" ></script>
    <script src="<?php echo base_url('assets/js/pages/calendar/calendar.min.js');?>" ></script>
  
     <!-- data tables -->
     <script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js');?>" ></script>
 	<script src="<?php echo base_url('assets/plugins/datatables/plugins/bootstrap/dataTables.bootstrap4.min.js');?>" ></script>
    <script src="<?php echo base_url('assets/js/pages/table/table_data.js');?>" ></script>
    <script src="<?php echo base_url('assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js');?>" ></script>
    <script src="<?php echo base_url('assets/plugins/jquery-validation/js/jquery.validate.min.js');?>" ></script>
    <script src="<?php echo base_url('assets/plugins/jquery-validation/js/additional-methods.min.js');?>" ></script>
    <script src="<?php echo base_url('assets/js/pages/validation/form-validation.js');?>" ></script>
    <!-- date picker -->
    <script src="<?php echo base_url('assets/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.js');?>"  charset="UTF-8"></script>
    <script src="<?php echo base_url('assets/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker-init.js');?>"  charset="UTF-8"></script>
    <script src="<?php echo base_url('assets/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js');?>"  charset="UTF-8"></script>
    <script src="<?php echo base_url('assets/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker-init.js');?>"  charset="UTF-8"></script>
    <script src="<?php echo base_url('assets/js/pages/material-select/getmdl-select.js');?>"  charset="UTF-8"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar-scheduler/1.9.4/scheduler.min.js"  charset="UTF-8"></script>
    <script src="<?php echo base_url('assets/plugins/dropzone/dropzone.js');?>" ></script>
    <script src="<?php echo base_url('assets/js/jquery.rateyo.min.js');?>" ></script>

    <script type="text/javascript">
    $(document).ready(function() {
        load_unseen_notification('unseen');
    });
    $(document).keypress(function (e) {
        if(e.keyCode == 13) {
            //alert("Please click on send button.");
            document.getElementById("sendBtn").click();
            e.preventDefault();
        }
    });
    /*$(document).on('click', 'ul.dropdown-menu li a', function(e){
        var sender_id = $(this).data('id');
        var receiver_id = $(this).data('rid');
        var user = $(this).data('user').split(',');
        load_unseen_notification('seen', sender_id);
		//load_conversation(sender_id,receiver_id,'https://bi-test.mattsenkumar.com/nasscom_ci/assets/img/dp.jpg');
        //setTimeout(function() {
        //getUser(user[0],parseInt(user[1]),'https://bi-test.mattsenkumar.com/nasscom_ci/assets/img/dp.jpg');
        //},2);
    });*/

    function getUser(username,sid,rid,pic=''){

        $('.chat').text('');
        $('#selected_user_name').text(username);
        $('#receiver_id').val(rid);
        $('#picture').val(pic);

        load_conversation(sid,rid,pic);
    }

    function send(){
        var msg = $('#message').val();
        var sender_id = $('#sender_id').val();
        var receiver_id = $('#receiver_id').val();
        if(sender_id == "" || receiver_id == ""){
            alert('Please select one user');
            return false;
        }
        var pic = $('#picture').val();
        // console.log(" pic:- "+pic);
        $.ajax({
            url:'<?php echo BASEURL . "ask/send";?>',
            type: 'POST',
            datatype: 'JSON',
            data: {sender_id:sender_id,receiver_id:receiver_id,msg:msg},
            success: function(data){
                var obj = JSON.parse(data);
                console.log(obj.msg);
                var msg = '<li class="out"><img src="'+pic+'" class="avatar" alt=""><div class="message"><span class="arrow"></span>  <span class="body"> '+ obj.msg +' </span> <span class="datetime">'+ obj.time +'</span> </div></li>';
                $('.chat').append(msg);
                $('#message').val('');
            }
        }); //End ajax
    }
   /*  function read(){
        var sender_id = $('#sender_id').val();
        var receiver_id = $('#receiver_id').val();
        var msg_id = $('#msg-id').val();
        var pic = $('#picture').val();
        $.ajax({
            url:'<?php echo BASEURL . "ask/read";?>',
            type: 'POST',
            datatype: 'JSON',
            data: {sender_id:sender_id,receiver_id:receiver_id,msg_id:msg_id},
            success: function(data){
                var obj = JSON.parse(data);
                var msg = '';
                $.each(obj,function(key,value){
                    $('#msg-id').val(value.id);
                    console.log("aaa--"+value);
                    if(sender_id == value.sender_id){
                        msg += '<li class="out"><img src="'+pic+'" class="avatar" alt=""><div class="message"><span class="arrow"></span>  <span class="body"> '+ value.msg +' </span> <span class="datetime" style="font-size:10px">at '+ value.time +'</span></div></li>';
                    }
                        
                });
                $('.chat').append(msg);
            }
        }); //End ajax
    } */
	
    function load_conversation(sender_id,receiver_id,pic){

        /*location.href='<?= BASEURL."mentor-ask" ?>'
        var sender_id = $('#sender_id').val();
        var receiver_id = $('#receiver_id').val();
        var pic = $('#picture').val();*/
        $.ajax({
            url:'<?php echo BASEURL . "ask/get";?>',
            type: 'POST',
            datatype: 'JSON',
            data: {sender_id:sender_id,receiver_id:receiver_id},
            success: function(data){
                var obj = JSON.parse(data);
                var name = 'test';
                var msg = '';
                $.each(obj,function(key,value){
                    $('#msg-id').val(value.id);
                    
                    if(sender_id != value.sender_id){
                        msg += '<li class="in"><img src="'+pic+'" class="avatar" alt=""><div class="message"><span class="arrow"></span>  <span class="body"> '+ value.msg +' </span> <span class="datetime" style="font-size:10px">'+ value.time +'</span> </div></li>';
                    }else{
                        msg += '<li class="out"><img src="'+pic+'" class="avatar" alt=""><div class="message"><span class="arrow"></span>  <span class="body"> '+ value.msg +' </span> <span class="datetime" style="font-size:10px">at '+ value.time +'</span></div></li>';
                    }
                });
                $('.chat').append(msg);
            }
        }); //End ajax
    }
    
    function load_unseen_notification(view='',sender_id='')
    {
        $.ajax({
            url:'<?php echo BASEURL . "unseen-notify";?>',
            method:"POST",
            data:{view:view,sender_id:sender_id},
            dataType:"json",
            success:function(data){
                $('.dropdown-menu-list').html(data.notification);
                $('.count').html(data.unseen_notification);
                $('.newcount').html('New '+ data.unseen_notification);
            }
        });
    }

    function getParam(name){
     name = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
     var regexS = "[\\?&]"+name+"=([^&#]*)";
     var regex = new RegExp( regexS );
     var results = regex.exec( window.location.href );
     if( results == null )
      return "";
    else
     return results[1];
    }

    window.setInterval(function(){
    	load_unseen_notification('unseen');; 
    }, 10000);

    </script>
    <!-- end js include path -->
 <!--  </body>
</html> -->
