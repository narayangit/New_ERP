<?php 
//print_r($event_attendance);die;
include 'common/header_view.php';
include 'common/sidebar_view.php';
?>

 
			<!-- start page content -->
            <div class="page-content-wrapper">
                <div class="page-content">
                  <div class="row">
                      <div class="col-md-12">
					  <?php 
						$usertype = $this->session->userdata('usertype');
						if($usertype == 1){ ?>
						<a href="<?php echo BASEURL . 'event-details';?>" class="btn btn-circle btn-primary"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</a>  
						<?php }else if($usertype == 2){ ?>
						  <a href="<?php echo BASEURL . 'mentor-event-details';?>" class="btn btn-circle btn-primary"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</a>  
						<?php } ?>
					  
                      </div>
                  </div>  
                    
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card card-topline-red">
                                <div class="card-head">
                                    <header>Attendance</header>
                                    <div class="tools">
                                        <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
	                                    <a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
	                                    <a class="t-close btn-color fa fa-times" href="javascript:;"></a>
                                    </div>
                                </div>
                                <div class="card-body ">
								<?php if($usertype ==2 && $btn_id == 1){ ?>
                                <div class="row">
									<div class="col-md-12 col-sm-12 col-12">
										<div class="btn-group">
										<button type="button" class="btn btn-round btn-primary" id="button" onClick="check_attendance();" disabled="disabled">Submit</button>
										</div>
									</div>
								</div>
								<? } ?>
                                    <div class="table-scrollable">
									
                                    <table class="table table-striped table-bordered table-hover table-checkable order-column" style="width: 100%" id="example4">
                                        <thead>
                                            <tr>
                                                <?php if($this->session->userdata('usertype') == 2 && $btn_id == 1) echo "<th>#</th>" ?>
                                                <th> Reffrence Id </th>
                                                <th> Name </th>
                                                <th> Technology Name </th>
                                                <th> Email </th>
                                                <th> Address </th>
                                                <th> City </th>
                                                <th> Contact </th>
												<?php if($btn_id == 2){ ?>
                                                <th> Feedback </th>
												<th> Rating </th>
												<?php } ?>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                            if(count($event_attendance)>0){
												$i=1;
                                            foreach ($event_attendance as $key => $attendance) { 
											$style = '';
												if($this->session->userdata('usertype') == 2):
													$style = ($attendance->apply_status == 'Present') ? "style='background-color:#dff0d8;'":'';
												endif;
												
                                                
                                                echo "<tr ".$style.">";
												  if($this->session->userdata('usertype') == 2 && $btn_id == 1):
                                                $checked = ($attendance->apply_status == 'Present') ? "checked":'';
                                                    echo '<td><label class="rt-chkbox rt-chkbox-single rt-chkbox-outline">
                                                              <input type="checkbox" class="checkboxes" aid="'.$attendance->aid.'" eid="'.$attendance->eid.'" sid="'.$attendance->id.'" sts="'.$attendance->apply_status.'" '.$checked.'/>
                                                              <span></span></label></td>';
													endif;
													
                                                    echo "<td>".$attendance->unique_id."</td>";
                                                    echo "<td>".$attendance->name."</td>";
                                                    echo "<td>".$attendance->technology."</td>";  
                                                    echo "<td>".$attendance->email."</td>";
                                                    echo "<td>".$attendance->address."</td>";
                                                    echo "<td>".$attendance->location."</td>";
                                                    echo "<td>".$attendance->contact."</td>";
													if($btn_id == 2){ 
                                                    // echo "<td><a href='".base_url('index.php/view-feedback/'.$attendance->fid)."'>View Feedback</a></td>";
													echo "<td><button id='viewBtn' data-id='".$attendance->fid."'><a href='javascript:void(0)'>View Feedback</a></button></td>";
													$rating = $attendance->rating;?>
													<td>
													<div class="rating" style='pointer-events:none;'>
														<input id="star5" name="rating_<?= $i ?>" type="radio" value="5" class="radio-btn hide" <?= ($rating == 5)?'checked':'' ?>  />
														<label for="star5" >☆</label>
														<input id="star4" name="rating_<?= $i ?>" type="radio" value="4" class="radio-btn hide" <?= ($rating == 4)?'checked':'' ?>   />
														<label for="star4" >☆</label>
														<input id="star3" name="rating_<?= $i ?>" type="radio" value="3" class="radio-btn hide" <?= ($rating == 3)?'checked':'' ?>  />
														<label for="star3" >☆</label>
														<input id="star2" name="rating_<?= $i ?>" type="radio" value="2" class="radio-btn hide" <?= ($rating == 2)?'checked':'' ?>  />
														<label for="star2" >☆</label>
														<input id="star1" name="rating_<?= $i ?>" type="radio" value="1" class="radio-btn hide" <?= ($rating == 1)?'checked':'' ?>  />
														<label for="star1" >☆</label>
														<div class="clear"></div>
													</div>
													</td>
														<?php } ?>

													
                                                <?php echo "</tr>";
                                            $i++;}
											}
                                            ?>
                                        </tbody>
                                    </table>
									
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
        </div>

</div>
</div>

<!-- mdoal for feedback  -->

<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
					<button class='btn btn-primary btn-sm' style='float:right;width:80px' onclick="printDiv('copy')" >Print</button>
					
			<div class="page-content-wrapper" id="copy">
				<div class="card-head">
					<header>Feedback Form</header>
				</div>
				<div class="card-body" id="bar-parent2">
					<div class="form-body">
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label class="control-label ">First Name
										<span class="required" aria-required="true"> * </span>
									</label>
									<div class="form-group">
										<div class="input-icon  fname1">
											<input type="text" class="form-control" id="fname" readonly> 
										</div>
									</div>
								</div>
							</div>
							
							<div class="col-md-4">
								<div class="form-group  ">
									<label class="control-label ">Last Name
										<span class="required" aria-required="true"> * </span>
									</label>
									<div class="">
										<div class="input-icon lname1">
											<input type="text" class="form-control" id="lname" readonly > 
										</div>
									</div>
								</div>
							</div>
							
							<div class="col-md-4">
								<div class="form-group  ">
									<label class="control-label ">Email Address
										<span class="required" aria-required="true"> * </span>
									</label>
									<div class="">
										<div class="input-icon email1">
											<input type="text" class="form-control" id="email"  readonly> 
										</div>
									</div>
								</div>
							</div>
							
							<div class="col-md-12">
								<div class="form-group">
									<label>Please let us know if (on a scale of 1-5)</label>
									<select class="form-control" aria-required="true" id='let_know' readonly disabled>
										
									</select>
								</div>
							</div>
							
							<div class="col-md-4">
								<div class="form-group  ">
									<label class="control-label ">Which Session did you attend?
									</label>
									<div class="">
										<div class="input-icon session_name1">
											<input type="text" class="form-control" id="session_name" readonly> 
										</div>
									</div>
								</div>
							</div>
					
							<div class="col-md-8">
								<div class="form-group  ">
									<label class="control-label ">How satisfied are you with the content of the session?
										<span class="required" aria-required="true"> * </span>
									</label>
									<div class="">
										<div class="input-icon satisfied1">
											<input type="text" class="form-control" id="satisfied" readonly>
										</div>
									</div>
								</div>
							</div>
							 
							<div class="col-md-6">
								<div class="form-group  ">
									<label class="control-label ">Any information that you think was not covered in the session?
										<span class="required" aria-required="true"> * </span>
									</label>
									<div class="">
										<div class="input-icon information1">
											<input type="text" class="form-control" id="information" readonly> 
										</div>
									</div>
								</div>
							</div>
							
							<div class="col-md-6">
								<div class="form-group  ">
									<label class="control-label ">Are you already working in your area of primary interest?
										<span class="required" aria-required="true"> * </span>
									</label>
									<div class="">
										<div class="input-icon interest1">
											<input type="text" class="form-control" id="interest" readonly>
										</div>
									</div>
								</div>
							</div>
						  
							<div class="col-md-6">
								<div class="form-group  ">
									<label class="control-label ">Overall assessment of the event?
										<span class="required" aria-required="true"> * </span>
									</label>
									<div class="">
										<div class="input-icon assessment1">
											<textarea class="form-control" rows="2" id="assessment" readonly></textarea>
										</div>
									</div>
								</div>
							</div>   
							 
							<div class="col-md-6">
								<div class="form-group  ">
									<label class="control-label ">Any additional comments?
										<span class="required" aria-required="true"> * </span>
									</label>
									<div class="">
										<div class="input-icon comment1">
											<textarea class="form-control" rows="2" id="comment" readonly></textarea>
										</div>
									</div>
								</div>
							</div>  
							 
							<div class="col-md-12">
								<div class="form-group" style='pointer-events:none;'>
									<p> <label class="control-label ">Rate the relevance of the session on a scale of 1-5?
										<span class="required" aria-required="true"> * </span>
										</label>
									</p>
									<div class="radio radio-yellow form-check-inline">
										<input id="radiobg1" name="rating" type="radio" value='1'>
										<label for="radiobg1">1</label>
									</div>
									<div class="radio radio-yellow form-check-inline">
										<input id="radiobg2" name="rating" type="radio" value='2'>
										<label for="radiobg2">2</label>
									</div>
									<div class="radio radio-yellow form-check-inline">
										<input id="radiobg3" name="rating" type="radio" value='3'>
										<label for="radiobg3">3</label>
									</div>
									<div class="radio radio-yellow form-check-inline">
										<input id="radiobg4" name="rating" type="radio" value='4'>
										<label for="radiobg4">4</label>
									</div>
									<div class="radio radio-yellow form-check-inline">
										<input id="radiobg5" name="rating" type="radio" value='5'>
										<label for="radiobg5">5</label>
									</div>
								</div>
							</div>                   
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- Modal close -->



<?php include 'common/footer_view.php'; ?>

<script type="text/javascript">

$(document).ready(function(){
	
	$('input[type=checkbox]').on('click',function(){
	  $("input:checkbox").each(function(){
		var len = $("input:checked").length;
		if(len > 0){
		  $("#button").prop('disabled',false);
		}else{
		  $("#button").prop('disabled',true);
		}
	  });
	});

	// feedback view function start

	$('#viewBtn').on('click', function(){
		var feedback_id = $(this).data('id');
		$.ajax({
			url: '<?php echo BASEURL. "student/view_feedback" ?>',
			type: 'GET',
			data: {fid:feedback_id},
			datatype: 'JSON',
			success: function(data){
				var obj = JSON.parse(data);
				var opt = "<option>"+obj.let_know+"</option>";
				$('#fname').val(obj.first_name);
				$('#lname').val(obj.last_name);
				$('#email').val(obj.email);
				$('#let_know').html(opt);
				$('#session_name').val(obj.session_name);
				$('#satisfied').val(obj.satisfied);
				$('#information').val(obj.information);
				$('#interest').val(obj.interest);
				$('#assessment').val(obj.assessment);
				$('#comment').val(obj.comments);
				$('#radiobg'+obj.rating).attr('checked',true);
				
			}
			
		});
		$('#exampleModalCenter').modal('show');
	});
// feedback view function end
});

              
function check_attendance()
{
    obj = new Array();
    $("input:checkbox").each(function(){
      if($(this).is(":checked")){
        obj.push({'aid': $(this).attr("aid"),'eid': $(this).attr("eid"),'sid': $(this).attr("sid"),'apply_status': $(this).attr("sts")});
      }
    });
    if( obj.length > 0 ){
      $.ajax({
        url: '<?php echo BASEURL . "mentor/check_attendance";?>',
        method : 'post',
        data: {'data': obj},
        success : function(data){
          location.reload();
        }
      });
    }
} //End function


// print function for feedback form
function printDiv(divName) {
		
		var fn = $('#fname').val();
		var ln = $('#lname').val();
		var em = $('#email').val();
		var sess = $('#session_name').val();
		var satis = $('#satisfied').val();
		var info = $('#information').val();
		var inte = $('#interest').val();
		var asses = $('#assessment').val();
		var comm = $('#comment').val();
		
		var fname = '<input type="text" class="form-control" id="fname" value="'+fn+'" readonly>';
		var lname = '<input type="text" class="form-control" id="lname" value="'+ln+'" readonly >';
		var email = '<input type="text" class="form-control" id="email" value="'+em+'" readonly>';
		var sess_name = '<input type="text" class="form-control" id="session_name" value="'+sess+'" readonly>';
		var satisfied = '<input type="text" class="form-control" id="satisfied" value="'+satis+'" readonly>';
		var information = '<input type="text" class="form-control" id="information" value="'+info+'" readonly>';
		var interest = '<input type="text" class="form-control" id="interest" value="'+inte+'" readonly>';
		var assessment = '<textarea class="form-control" rows="2" id="assessment" readonly>'+asses+'</textarea>';
		var comment = '<textarea class="form-control" rows="2" id="comment" readonly>'+comm+'</textarea>';
		
		$('.fname1').html(fname);
		$('.lname1').html(lname);
		$('.email1').html(email);
		$('.session_name1').html(sess_name);
		$('.satisfied1').html(satisfied);
		$('.information1').html(information);
		$('.interest1').html(interest);
		$('.assessment1').html(assessment);
		$('.comment1').html(comment);
		
	 
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
}



</script>

</body>
</html>