<?php 

include 'common/header_view.php';
include 'common/sidebar_view.php';
?>

			<!-- start page content -->
            <div class="page-content-wrapper">
                <div class="page-content">
                    <div class="page-bar">
                        <div class="page-title-breadcrumb">
                            <div class=" pull-left">
                                <div class="page-title">Guru/Ask Question</div>
                            </div>
                            <ol class="breadcrumb page-breadcrumb pull-right">
                                <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="index.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                                </li>
                                <li class="active">Guru/Ask Question</li>
                            </ol>
                        </div>
                    </div>
                   <!-- start widget -->
                   <div class="row">
					        
                   <div class="col-lg-8 col-md-8 col-sm-12 col-12">
                        	<div class="card  card-box">
                                <div class="card-head">
                                    <header id='selected_user_name'>Ask Question</header>
                                </div>
                                <div class="card-body no-padding height-9">
                                    <div class="row">
                                        <ul class="chat nice-chat small-slimscroll-style">
                                            <!-- <li class="in"><img src="<?= base_url()?>assets/img/prof/prof1.jpg" class="avatar" alt="">
                                                <div class="message">
                                                    <span class="arrow"></span> <a class="name" href="#">Jone
														Doe</a> <span class="datetime">at Mar 12, 2014 6:12</span> <span class="body"> Lorem ipsum dolor sit amet,
														consectetuer adipiscing elit </span>
                                                </div>
                                            </li>
                                            <li class="out"><img src="<?= base_url()?>assets/img/dp.jpg" class="avatar" alt="">
                                                <div class="message">
                                                    <span class="arrow"></span> <a class="name" href="#">Kiran
														Patel</a> <span class="datetime">at Mar 12, 2014 6:13</span> <span class="body"> sed diam nonummy nibh euismod
														tincidunt ut </span>
                                                </div>
                                            </li> -->
                                        </ul>
                                        <div class="box-footer chat-box-submit">
              						                <form action="#" method="post">
              						                  <div class="input-group">
                        											<input type='hidden' id='msg-id' value='' >
                        											<input type='hidden' name='sender_id' id='sender_id' value='<?= $this->session->userdata('id') ?>'>
                        											<input type='hidden' name='receiver_id' id='receiver_id'>
                        											<input type='hidden' name='picture' id='picture'>
              						                    <input type="text" name="message" id="message" placeholder="Enter your ToDo List" class="form-control">
              						                    <span class="input-group-btn">
              						                    <button type="button" class="btn btn-warning btn-flat" onclick='send()'><i class="fa fa-arrow-right"></i></button>
              						                    </span> 
                                            </div>
              						                </form>
              					               </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-12 col-12">
                             <div class="card card-box">
                                 <div class="card-head">
                                     <header>Student's List</header>
                                 </div>
                                 <div class="card-body ">
                                 <div class="row">
                                        <ul class="docListWindow small-slimscroll-style">
										<?php $students =  student_list(); 
											foreach($students as $student):
										?>
                                            <li>
                                                <div class="prog-avatar">
                                                    <img src="https://bi-test.mattsenkumar.com/nasscom_ci/assets/img/dp.jpg" alt="" width="40" height="40">
                                                </div>
                                                <div class="details">
                                                    <div class="title">
                                                        <a href="javascript:void(0)" onclick='getUser("<?= $student->name?>","<?= $this->session->userdata('id') ?>","<?= $student->id ?>","https://bi-test.mattsenkumar.com/nasscom_ci/assets/img/dp.jpg")' ><?= $student->name ?></a> -(<?= $student->technology ?>)
                                                    </div>
                                                </div>
                                            </li>
										<?php endforeach; ?>
                                          
                                        </ul>
                                        <div class="full-width text-center p-t-10" >
												<a href="#" class="btn purple btn-outline btn-circle margin-0">View All</a>
											</div>
                                    </div>
                                 </div>
                             </div>
						</div>


					     
                    					</div>
					
					<!-- end widget -->

			       
        </div>
</div>
<!-- end page container -->
<?php include 'common/footer_view.php'; ?>
<script type="text/javascript">
    $(document).ready(function() {
        /*if(getParam('sid') && getParam('rid')){
            var sender_id = getParam('sid'), receiver_id = getParam('rid'), pic='https://bi-test.mattsenkumar.com/nasscom_ci/assets/img/dp.jpg';
            load_conversation(sender_id,receiver_id,pic);
            load_unseen_notification('seen', sender_id);
        }*/
        if(getParam('uname') && getParam('sid') && getParam('rid')){
            var uname = getParam('uname'), sender_id = getParam('sid'), receiver_id = getParam('rid'), pic='https://bi-test.mattsenkumar.com/nasscom_ci/assets/img/dp.jpg';
            getUser(decodeURI(uname),parseInt(receiver_id),parseInt(sender_id),'https://bi-test.mattsenkumar.com/nasscom_ci/assets/img/dp.jpg');
            load_unseen_notification('seen', sender_id);
        }
    });
/*
    function getParam(name){
     name = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
     var regexS = "[\\?&]"+name+"=([^&#]*)";
     var regex = new RegExp( regexS );
     var results = regex.exec( window.location.href );
     if( results == null )
      return "";
    else
     return results[1];
    }*/

</script>
</body>
</html>