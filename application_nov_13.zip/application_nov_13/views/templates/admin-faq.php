<?php 

include 'common/header_view.php';
include 'common/sidebar_view.php';
?>

			<!-- start page content -->
            <div class="page-content-wrapper">
                <div class="page-content">
                    <div class="page-bar">
                        <div class="page-title-breadcrumb">
                            <div class=" pull-left">
                                <div class="page-title">Ask Question History</div>
                            </div>
                            <ol class="breadcrumb page-breadcrumb pull-right">
                                <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="index.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                                </li>
                                <li class="active">Ask Question History</li>
                            </ol>
                        </div>
                    </div>
                   <!-- start widget -->
                   <div class="row">
                   <div class="col-lg-8 col-md-8 col-sm-12 col-12">
                        	<div class="card card-box">
                                <div class="card-head">
                                    <header id='selected_user_name'>Ask Question History</header>
                                </div>
                                <div class="card-body no-padding height-9">
                                    <div class="row">
                                        <ul class="chat nice-chat small-slimscroll-style">

                    <?php foreach($ask_history as $history):
                      if($history->s_type == 2){
                          $class = "in";
                          $name = get_name2($history->sender_id,'linkedin');
                        }elseif($history->s_type == 3){
                          $class = "out";
                          $name = get_name2($history->sender_id,'students');
                        }
                      ?>

                              <li class="<?=$class;?>"><img src="<?= base_url()?>assets/img/prof/prof1.jpg" class="avatar" alt="">
                                  <div class="message">
                                      <span class="arrow"></span> <a class="name" href="#"><?=$name;?></a> <span class="datetime">at <?=$history->time;?></span> <span class="body"> <?=$history->msg;?> </span>
                                  </div>
                              </li>
                     <?php endforeach; ?>
                                        </ul>

                                      <!-- <div class="box-footer chat-box-submit">
              						                <form action="#" method="post">
              						                <div class="input-group">
                      											<input type='hidden' id='msg-id' value='' >
                      											<input type='hidden' name='sender_id' id='sender_id' value='<?= $this->session->userdata('id') ?>'>
                      											<input type='hidden' name='receiver_id' id='receiver_id'>
                      											<input type='hidden' name='picture' id='picture'>
              						                  <input type="text" name="message" id="message" placeholder="Enter your ToDo List" class="form-control">
              						                  <span class="input-group-btn">
              						                    <button type="button" class="btn btn-warning btn-flat" onclick='send()'><i class="fa fa-arrow-right"></i></button>
              						                  </span>
                                          </div>
              						                </form>
              					              </div> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-12 col-12">
                             <div class="card card-box">
                                 <div class="card-head">
                                     <header>Guru's List</header>
                                 </div>
                                 <div class="card-body ">
                                 <div class="row">
                                    <ul class="docListWindow small-slimscroll-style">
            										<?php $mentors =  mentor_list_for_chat(); 
                                  foreach($mentors as $mentor):
                                ?>
                                    <li>
                                        <div class="prog-avatar">
                                            <img src="<?= $mentor->picture_url ?>" alt="" width="40" height="40">
                                        </div>
                                        <div class="details">
                                            <div class="title">
                                                <a href="<?php echo BASEURL.'ask-history/'.$mentor->id;?>"><?= $mentor->first_name." ". $mentor->last_name ?></a> -(<?= $mentor->technology ?>)
                                            </div>
                                        </div>
                                    </li>
                                <?php endforeach; ?>
                                                      
                                        </ul>
                      <div class="full-width text-center p-t-10" >
												<a href="#" class="btn purple btn-outline btn-circle margin-0">View All</a>
										  </div>
                  </div>
               </div>
           </div>
				</div>
    </div>
				<!-- end widget -->
  </div>
</div>
<!-- end page container -->
<?php include 'common/footer_view.php'; ?>

<script type="text/javascript">
    $(document).ready(function() {
        if(getParam('uname') && getParam('sid') && getParam('rid')){
            var uname = getParam('uname'), sender_id = getParam('sid'), receiver_id = getParam('rid'), pic='https://bi-test.mattsenkumar.com/nasscom_ci/assets/img/dp.jpg';
            getUser(decodeURI(uname),parseInt(receiver_id),parseInt(sender_id),'https://bi-test.mattsenkumar.com/nasscom_ci/assets/img/dp.jpg');
            load_unseen_notification('seen', sender_id);
        }
    });

</script>
</body>
</html>