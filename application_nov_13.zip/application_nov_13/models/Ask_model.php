<?php
class Ask_model extends CI_Model
{
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
		$this->load->database();
    }
	
	function get_messages($sender,$receiver,$msg_id =null){
		$this->db->select('*')->from('nscm_ask')->where("sender_id in ($sender,$receiver)")->where("receiver_id in ($sender,$receiver)");
		if($msg_id != null){
			$this->db->where('id >',$msg_id);
		}
		$result = $this->db->get()->result_object();
		return $result;
	}
	
	// get the name from user id
	function get_name_for_chat($id,$type){
		if($type == 3){
			$this->db->select('name')->from('nscm_students')->where('id',$id);
		}elseif($type == 2){
			$this->db->select('name')->from('nscm_mentors')->where('id',$id);
		}
		$query = $this->db->get();
		if($query->row()){
			return $query->row()->name;
		}
	}
	// get user/guru list of ask question history
	function ask_history($id){
		$this->db->select('*')->from('nscm_ask')->where('mentor_id',$id);
		$result = $this->db->get()->result_object();
		return $result;
	}
}
?>