<?php
class Login_model extends CI_Model
{
    /* Purpose : Constructor function */
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
		$this->load->database();
    }
	/* purpose : get the username and password from table login	*/
	function getUser($email,$password)
    {
		$this->db->select("id, email, password, user_type, active")->from("nscm_login")->where('email',$email)->where('password',$password)->where('active', "1");

		$result = $this->db->get();
		return  $result->num_rows();
	}
	function user_auth($email)
	{
		$this->db->select("*")->from("nscm_login")->where("email", $email)->where("active", "1");

		$result = $this->db->get();
		return $result->row_array();
	}
	// Update password
	function changepassword($user,$data)
    {
		$this->db->where('email',$user);
	   	$this->db->update('nscm_students',$data);
        return $this->db->affected_rows();
	}
	
	
}
?>