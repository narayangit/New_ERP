<?php
class Mentor_model extends CI_Model
{
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
		$this->load->database();
    }
	// /* purpose : get all mentor details */
	// function mentor_details()
    // {   
		// $this->db->select("*")->from("nscm_mentors")->order_by("created_date","DESC");

		// $result = $this->db->get();
		// return $result->result_object();
	// }
	/* purpose : get all mentor details */
	function mentor_details()
    {   
		$this->db->select("m.id,m.active,m.technology,m.contact,l.first_name,l.last_name,l.email,l.locale,l.position,l.company,l.company_address,l.picture_url,l.profile_url")->from("nscm_mentors AS m")->join('nscm_linkedin AS l','m.id=l.mentor_id')->order_by("created_date","DESC");

		$result = $this->db->get();
		return $result->result_object();
	}
	/* purpose : get mentor details for profile */
	function mentor_profile($mentor_id)
    {   
		$this->db->select("*")->from("nscm_linkedin")->where("mentor_id",$mentor_id);
		$result = $this->db->get();
		return $result->row_object();
	}
    /* Purpose : add mentor */
	function add_mentor($mentor_id, $post_data)
    {
    	if($mentor_id === 0){
    		$this->db->insert('nscm_mentors', $post_data);
    	}else if($mentor_id !== 0){
    		$this->db->where('id', $mentor_id)->update('nscm_mentors', $post_data);
    	}
        
		return true;
    }
    /* Purpose : edit mentor */
    function edit_mentor($mentor_id)
    {
        //$codition = '(id="'.$mentor_id.'" AND active = "1")';
        $codition = '(id="'.$mentor_id.'")';
    	$this->db->select("*")->from("nscm_mentors")->where($codition);

		$result = $this->db->get();
		return $result->row();
    }
    function deactive_mentor($id)
    {
        $codition = '(id="'.$id.'" AND active = "1")';
        $this->db->where($codition);
        return $this->db->update('nscm_mentors', ['active'=> '0']);
    }
    /* Purpose : get event details */
    function event_details()
    {
        $mentor_id = $this->session->userdata('id');
        $this->db->select("*")->from("nscm_events")->where("mentor_id='".$mentor_id."'");
        $result = $this->db->get();
        return $result->result_object();
    }

    function unseen_notify($post)
    {
        $data['notification'] = '';
        $data['unseen_notification'] = 0;

        $id = $this->session->userdata('id');
        $usertype = $this->session->userdata('usertype');
        $output = '';
        $user = array();

        if($this->input->post('view')){

            if($post['view'] == 'seen')
            {
                $this->db->where('sender_id', $post['sender_id'])->where('receiver_id', $id)->where('notify_status', 0);
                $this->db->update('nscm_ask', array('notify_status' => 1));
            }

            $query = $this->db->select("id,s_type,sender_id,receiver_id,msg,notify_status,time")->from("nscm_ask")->where('receiver_id',$id)->where('notify_status', 0)->order_by("id", "DESC")->limit(5);
            $result = $query->get()->result_object();

            if(count($result) > 0)
            {
                foreach ($result as $row) {

                    if($usertype == 2){
                        $user['id']  = (int) get_details('students',$row->sender_id)->id;
                        $user['name'] = trim(get_details('students',$row->sender_id)->name);
                        $data_user = $user['name'].','.$user['id'];
                        $redirect_url = base_url() . "index.php/mentor-ask";
                        $query_string =  "/?sid=".$row->sender_id."&rid=".$row->receiver_id."&uname=".$user['name'];

                    }elseif($usertype == 3){
                        $user['mentor_id']  = (int) get_details('linkedin',$row->sender_id)->mentor_id;
                        $user['first_name'] = trim(get_details('linkedin',$row->sender_id)->first_name);
                        $user['last_name'] = trim(get_details('linkedin',$row->sender_id)->last_name);
                        $data_user = $user['first_name'].' '.$user['last_name'].','.$user['mentor_id'];
                        $redirect_url = base_url() . "index.php/ask";

                        $query_string =  "/?sid=".$user['mentor_id']."&rid=".$row->receiver_id."&uname=".$user['first_name']." ".$user['last_name'];
                    }

                    $output .= '<li><a href="'.$redirect_url.$query_string.'" data-id="'.$row->sender_id.'" data-rid="'.$row->receiver_id.'" data-user="'.$data_user.'"><span class="time">'.dateDiff($row->time).'</span><span class="details"><span class="notification-icon circle purple-bgcolor"><i class="fa fa-comments o"></i></span>'.$row->msg.'</span></a></li>';
                }
            }
        }

        $this->db->select("id")->from("nscm_ask")->where('receiver_id', $id)->where('notify_status',0);
        $query = $this->db->get();
        $count = $query->num_rows();
        
        $data['notification'] = $output;
        $data['unseen_notification'] = $count;

        return (count($data)) ? json_encode($data):'';
    }

	// Purpose : delete mentor
    /*function delete_mentor($id)
    {
        $codition = '(id="'.$id.'" AND active = 1)';
        $this->db->where($codition);
        return $this->db->delete('nscm_mentors');
    }
    */
	
}
?>