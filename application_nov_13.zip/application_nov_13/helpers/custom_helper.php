<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

if(!function_exists('is_logged_in'))
{
  function is_logged_in(){
    $CI =& get_instance();
    $is_logged_in = $CI->session->userdata('is_logged_in');
    if( !isset($is_logged_in) || $is_logged_in != TRUE )
    {
      redirect('index.php/login');
    }
  }
}

if(!function_exists('user_role'))
{
  function user_role(){
    $CI =& get_instance();
    $user_role = $CI->session->userdata('usertype');
    if( isset($user_role) && $user_role == 1 ){
    	return 'Admin';
    }if( isset($user_role) && $user_role == 2 ){
    	return 'Mentor';
    }if( isset($user_role) && $user_role == 3 ){
    	return 'Student';
    }
  }
}

if (!function_exists('load_controller'))
{
    function load_controller($controller, $method = 'index')
    {
        require_once(FCPATH . APPPATH . 'controllers/' . $controller . '.php');

        $controller = new $controller();

        return $controller->$method();
    }
}

if (!function_exists('user_auth'))
{
	function user_auth($email)
	{    
		$CI =& get_instance();
		$CI->db->select("*")->from("nscm_login")->where("email", $email)->where("active", "1");

		$result = $CI->db->get();
		return $result->row_array();
	}
}

if (!function_exists('mentor_list'))
{
	function mentor_list()
	{
		$CI = &get_instance();
		$CI->db->select("id,name,active")->from("nscm_mentors")->where("active", "1");

		$result = $CI->db->get();
		$mentor_list = $result->result_object();
		$option = '';
		foreach ($mentor_list as $key => $mentor) {
	    	$option .= "<option value=".$mentor->id.">".$mentor->name."</option>";
		}
		return $option;
	}
}

if (!function_exists('mentor_list_for_chat'))
{
	function mentor_list_for_chat()
	{
		$CI = &get_instance();
		
		$CI->db->select("m.id,m.active,m.technology,m.contact,l.first_name,l.last_name,l.email,l.locale,l.position,l.company,l.company_address,l.picture_url,l.profile_url")->from("nscm_mentors AS m")->join('nscm_linkedin AS l','m.id=l.mentor_id')->order_by("created_date","DESC");

		// $result = $this->db->get();
		// return $result->result_object();
		
		// $CI->db->select("id,name,technology")->from("nscm_mentors")->where("active", "1");

		$result = $CI->db->get();
		return $result->result_object();
		
	}
}

if (!function_exists('student_list'))
{
	function student_list()
	{
		$CI = &get_instance();
		$CI->db->select('*')->from("nscm_students")->where('active','1');
		$result = $CI->db->get();
		return $result->result_object();
	}
}
if (!function_exists('get_details'))
{
	function get_details($table, $id)
	{
		$CI = &get_instance();
		if($table != 'linkedin'){
			$codition = '(id="'.$id.'" AND active = "1")';
		}else{
			$codition = '(mentor_id="'.$id.'")';
		}
		
		$CI->db->select('*')->from("nscm_" . $table)->where($codition);
		$result = $CI->db->get();
		return $result->row_object();
	}
}

if (!function_exists('count_applied_students'))
{
	function count_applied_students($event_id)
	{
		$CI = &get_instance();
		$CI->db->select('*')->where('event_id', $event_id);
		$query = $CI->db->get('nscm_attendance');
		return $num = $query->num_rows();
	}
}
if (!function_exists('count_all_applied_students'))
{
	function count_all_applied_students($event_id)
	{
		$CI = &get_instance();
		$CI->db->select('*')->where('event_id', $event_id);
		$query = $CI->db->get('nscm_attendance');
		return $num = $query->num_rows();
	}
}
if (!function_exists('count_feedback_students'))
{
	function count_feedback_students($event_id)
	{
		$CI = &get_instance();
		$CI->db->select('*')->where('event_id', $event_id)->where('feedback IS NOT NULL and feedback != "" ');
		$query = $CI->db->get('nscm_attendance');
		// return $CI->last_query();
		return $num = $query->num_rows();
	}
}
if (!function_exists('count_attend_students'))
{
	function count_attend_students($event_id)
	{
		$CI = &get_instance();
		$CI->db->select('*')->where('event_id', $event_id)->where('apply_status', 'Present');
		$query = $CI->db->get('nscm_attendance');
		// return $CI->db->last_query();
		return $num = $query->num_rows();
	}
}
if (!function_exists('_count'))
{
	function _count($user='students')
	{
		$CI = &get_instance();
		$CI->db->select('*')->where('active', '1');
		$query = $CI->db->get('nscm_' . $user);
		return $num = $query->num_rows();
	}
}
if (!function_exists('_student_count_for_mentors'))
{
	function _student_count_for_mentors($mentor_id)
	{
		$CI = &get_instance();
		$CI->db->select('s.id')->from('nscm_students AS s')->join('nscm_mentors AS m','s.technology = m.technology')->where('m.id',$mentor_id)->where('s.active', '1');
		$query = $CI->db->get();
		return $num = $query->num_rows();
	}
}
if (!function_exists('_training_count_for_mentors'))
{
	function _training_count_for_mentors($mentor_id)
	{
		$CI = &get_instance();
		$CI->db->select('a.id')->from('nscm_attendance AS a')->join('nscm_mentors AS m','a.mentor_id = m.id')->where('m.id',$mentor_id);
		$query = $CI->db->get();
		return $num = $query->num_rows();
	}
}
if (!function_exists('get_name'))
{
	function get_name($id = null, $table='mentors')
	{
		$CI = &get_instance();
		$CI->db->select("id, name")->from('nscm_'.$table)->where("id", $id);
		$query = $CI->db->get();
		$result = $query->row();
		return $result->name;
	}
}
if (!function_exists('get_name2'))
{
	function get_name2($id = null, $table='mentors')
	{
		$CI = &get_instance();
		$CI->db->select("*")->from('nscm_'.$table)->where("id", $id);
		$query = $CI->db->get();
		$result = $query->row();

		if($query->row()){
			if($table != 'linkedin'){
				return $result->name;
			}else{
				return $result->first_name.' '.$result->last_name;
			}
		}
	}
}
if (!function_exists('get_technology'))
{
	function get_technology($id = null)
	{
		$CI = &get_instance();
		$CI->db->select("id,name")->from("nscm_technology")->where("id", $id)->where("active", "1");

		$result = $CI->db->get();
		$get_name = $result->row();
		
		return $get_name->name;
	}
}
if (!function_exists('has_applied'))
{
	function has_applied($student_id, $event_id)
	{
		$CI = &get_instance();
		$CI->db->select("*")->from("nscm_attendance")->where("student_id", $student_id)->where("event_id", $event_id);

		$result = $CI->db->get();
		$get_name = $result->result_object();
		if(count($get_name) > 0){
			return TRUE;
		}
		return FALSE;
	}
}

if (!function_exists('count_session_for_student'))
{
	function count_session_for_student($student_id)
	{
		$CI = &get_instance();
		$CI->db->select("*")->from("nscm_attendance")->where("student_id", $student_id)->where("apply_status","Present");

		$result = $CI->db->get();
		$get_name = $result->result_object();
		if(count($get_name) > 0){
			return TRUE;
		}
		return FALSE;
	}
}

if (!function_exists('count_mentor_for_student'))
{
	function count_mentor_for_student($student_id)
	{
		$CI = &get_instance();
		$CI->db->distinct()->select("mentor_id")->from("nscm_attendance")->where("student_id", $student_id)->where("apply_status","Present");

		$result = $CI->db->get();
		$get_name = $result->result_object();
		if(count($get_name) > 0){
			return TRUE;
		}
		return FALSE;
	}
}

if (!function_exists('get_event_attendance'))
{
	function get_event_attendance($event_id,$mentor_id,$btn_id)
	{
		$CI = &get_instance();
		if($btn_id==1){
			$CI->db->select("e.id AS eid,a.id AS aid,a.event_id,a.apply_status,s.*,f.id AS fid,f.rating")->from("nscm_events AS e")->join("nscm_attendance AS a","a.event_id = e.id",false)->join("nscm_students AS s","s.id = a.student_id",false)->join('nscm_feedback AS f','f.fk_att = a.id')->where("a.event_id", $event_id);
		}elseif($btn_id==2){
			$CI->db->select("e.id AS eid,a.id AS aid,a.event_id,a.apply_status,s.*,f.id AS fid,f.rating")->from("nscm_events AS e")->join("nscm_attendance AS a","a.event_id = e.id",false)->join("nscm_students AS s","s.id = a.student_id",false)->join('nscm_feedback AS f','f.fk_att = a.id')->where("a.event_id", $event_id)->where('a.apply_status','Present');
		}
		$result = $CI->db->get();
	// return $CI->db->last_query();
		if(count($result->result_object()) > 0){
			return $result->result_object();
		}
	}
}

if (!function_exists('technologies'))
{
	function technologies($page = 'event')
	{
		$CI = &get_instance();
		$CI->db->select("id,name,logo,active")->from("nscm_technology")->where("active", "1");

		$query = $CI->db->get();
		$techno_list = $query->result_object();

		$option = '';
		if($page == 'event'){
			foreach ($techno_list as $tech) {
		    	$option .= "<option value='".$tech->name."'>".$tech->name."</option>";
			}
		}elseif($page == 'mentor'){
			foreach ($techno_list as $tech) {
		    	$option .= '<li class="mdl-menu__item" data-val='.$tech->name.'>'.$tech->name.'</li>';
			}
		}elseif($page == 'student'){
			foreach ($techno_list as $tech) {
		    	$option .= '<li class="mdl-menu__item" data-val='.$tech->name.'>'.$tech->name.'</li>';
			}
		}
		return $option;
	}
}

if (!function_exists('student_feedback'))
{
	function student_feedback($event_id = 0,$student_id = 0)
	{
		$CI = &get_instance();
		$CI->db->select("id,feedback")->from("nscm_attendance")->where("event_id = '".$event_id."' AND student_id = '".$student_id."'");
		$query = $CI->db->get();
		if($query->row()){
			return $query->row()->id;
		}
	}
}

if (!function_exists('student_rating'))
{
	function student_rating($event_id = 0,$student_id = 0)
	{
		$CI = &get_instance();
		$CI->db->select("id,rating")->from("nscm_attendance")->where("event_id = '".$event_id."' AND student_id = '".$student_id."'");
		$query = $CI->db->get();
		if($query->row()){
			return $query->row()->rating;
		}
	}
}
if (!function_exists('mentor_rating'))
{
	function mentor_rating($mentor_id = 0)
	{
		$CI = &get_instance();
		$CI->db->select("f.id,f.fk_att,f.rating")->from("nscm_feedback f")->join('nscm_attendance AS a','a.id=f.fk_att','left')->where("a.mentor_id = '".$mentor_id."'");
		$query = $CI->db->get();

		if($query->row()){
			$data['sum_of_users_rating'] = 0;

			foreach ($query->result_object() as $row){
				$data['sum_of_users_rating'] += $row->rating;
			}

			$data['total_users_rated'] = $query->num_rows();
			
			$data['rating'] = $data['sum_of_users_rating'] / $data['total_users_rated'];
			return (object) $data;
		}
	}
}

if (!function_exists('get_all_technology'))
{
	function get_all_technology()
	{
		$CI = &get_instance();
		$CI->db->select("COUNT(s.id) AS users,t.id,t.name")->from(" nscm_technology AS t")->join('nscm_students AS s','t.name=s.technology','left')->where('t.active',1)->group_by('t.name');
        $result = $CI->db->get();
		// echo $CI->db->last_query();
        return $result->result();
	}
}

if (!function_exists('last_completed_event'))
{
	function last_completed_event()
	{
		$CI = &get_instance();
		$CI->db->select("e.id,e.event_name,e.mentor_id,m.name,e.start_date,e.end_date,e.city,e.address")->from("nscm_events AS e")->join('nscm_mentors AS m','m.id = e.id')->where("DATE(end_date)< NOW()")->order_by('e.id','DESC')->limit(1);

		$result = $CI->db->get();
		$event = $result->result_array();
		$json_array = $events =[];
		
		foreach ($result->result_array() as $key => $event) {
				$events['id'] = $event['id'];
				$events['title'] = $event["event_name"] ." ". $event["name"] ." ". $event["city"] ." ". $event["address"];
				array_push($json_array, $events);
			}
			
		return $json_array;
	}
}

if (!function_exists('last_completed_event_for_mentor'))
{
	function last_completed_event_for_mentor($mentor_id)
	{
		$CI = &get_instance();
		$CI->db->select("e.id,e.event_name,e.mentor_id,m.name,e.start_date,e.end_date,e.city,e.address")->from("nscm_events AS e")->join('nscm_mentors AS m','m.id = e.id')->where("DATE(end_date)< NOW()")->where('e.mentor_id',$mentor_id)->order_by('e.id','DESC')->limit(1);

		$result = $CI->db->get();
		$event = $result->result_array();
		$json_array = $events =[];
		
		foreach ($result->result_array() as $key => $event) {
				$events['id'] = $event['id'];
				$events['title'] = $event["event_name"] ." ". $event["name"] ." ". $event["city"] ." ". $event["address"];
				array_push($json_array, $events);
			}
			
		return $json_array;
	}
}

if (!function_exists('count_users_under_mentor'))
{
	function count_users_under_mentor($mentor_id)
	{
		$CI = &get_instance();
		$CI->db->select("id")->from(" nscm_attendance")->where('mentor_id',$mentor_id)->where('apply_status','Present');
        $query = $CI->db->get();
		// return $CI->db->last_query();
        return $num = $query->num_rows();
	}
}

if (!function_exists('get_mentor_technology'))
{
	function get_mentor_technology($mentor_id)
	{
		$CI = &get_instance();
		$CI->db->select("technology")->from("nscm_mentors")->where('id',$mentor_id);
        $query = $CI->db->get();
		// echo $CI->db->last_query();
        return $query->row()->technology;
		
	}
}

if (!function_exists('unseen_notify'))
{
	function unseen_notify()
	{
		
		$CI = &get_instance();
		$receiver_id = $CI->session->userdata('id');
        $query = $CI->db->select("*")->from("nscm_ask")->where('receiver_id', $receiver_id)->limit(5);
        $result = $query->get()->result_object();
        $output = '';

        if(count($result) > 0)
        {
            foreach ($result as $row) {
                $redirect_url = base_url().'index.php/mentor-ask';
                $output .= '<li><a href="'.$redirect_url.'"><span class="time">'.$row->time.'</span><span class="details"><span class="notification-icon circle deepPink-bgcolor"><i class="fa fa-check"></i></span>'.$row->msg.'</span></a></li>';
            }
        }
        $CI->db->select("*")->from("nscm_ask")->where('receiver_id', $receiver_id)->where('notify_status',0);
        $count = $CI->db->get()->num_rows();
        
        $data = array(
           'notification' => $output,
           'unseen_notification' => $count
        );
        return $data;
	}
}

if (!function_exists('dateDiff'))
{
	function dateDiff($date){
	  $mydate= date("Y-m-d H:i:s");
	  $theDiff="";
	  $datetime1 = date_create($date);
	  $datetime2 = date_create($mydate);
	  $interval = date_diff($datetime1, $datetime2);
	  //echo $interval->format('%s Seconds %i Minutes %h Hours %d days %m Months %y Year    Ago')."<br>";
	  $min=$interval->format('%i');
	  $sec=$interval->format('%s');
	  $hour=$interval->format('%h');
	  $mon=$interval->format('%m');
	  $day=$interval->format('%d');
	  $year=$interval->format('%y');
	  if($interval->format('%i%h%d%m%y')=="00000")
	  {
	    return $sec." Seconds";
	  }else if($interval->format('%h%d%m%y')=="0000"){
	   return ($min == 1) ? $min." Minute" : $min." Minutes";
	  }else if($interval->format('%d%m%y')=="000"){
	   return ($hour == 1) ? $hour." Hour" : $hour." Hours";
	  }else if($interval->format('%m%y')=="00"){
	   return ($day == 1) ? $day." Day" : $day." Days";
	  }else if($interval->format('%y')=="0"){
	   return ($mon == 1) ? $mon." Month" : $mon." Months";
	  }else{
	   return ($year == 1) ? $year." Year" : $year." Years";
	   }
	}
}
?>