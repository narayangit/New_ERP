<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Event extends CI_Controller {
	function __construct()
	{
        parent::__construct();
        $this->load->helper(array('form','url','date','custom'));
        $this->load->library(array('session','form_validation','email'));
        $this->load->model('event_model');
        is_logged_in();
    }
    
	function index()
	{
		$data['title'] = 'Event';
		$data['get_events'] = $this->event_model->get_events();
		$this->load->view('templates/add-event',$data);
	}

    function add_event()
	{
		// configuration for bulk sheet upload
		$config['upload_path'] = './uploaded_logo/';
		$config['allowed_types'] = 'gif|jpg|png|jpeg';
		// $config['max_size'] = '100';
		$config['max_width']  = '1024';
		$config['max_height']  = '768';
		$config['overwrite'] = TRUE;
		$config['encrypt_name'] = FALSE;
		$config['remove_spaces'] = TRUE;
		if ( ! is_dir($config['upload_path']) ) die("THE UPLOAD DIRECTORY DOES NOT EXIST");
		$this->load->library('upload', $config);
		if ( ! $this->upload->do_upload('event_logo')) {
			$this->session->set_flashdata('msg', '<div class="alert alert-danger text-center" id="alert-msg"><button type="button" class="close" data-dismiss="alert">X</button><strong>Error! </strong>Something Went Wrong form not submitted.</div>');
			redirect('index.php/event-details');
		} else {
			$upload_data = $this->upload->data();
		}
		$post_data = [
            'event_name' => $this->input->post('event_name'),
            'start_date' => $this->input->post('start_date'),
            'end_date' => $this->input->post('end_date'),
            'mentor_id' => $this->input->post('guru_name'),
            'technology' => $this->input->post('tech_name'),
            'city' => $this->input->post('location'),
            'address' => $this->input->post('address'),
			'logo' => $upload_data['file_name']
        ];	
		
		
		$add_data = $this->event_model->add_event($post_data);

    	if($add_data) {
      		$this->session->set_flashdata('msg', '<div class="alert alert-success" id="alert-msg"><button type="button" class="close" data-dismiss="alert">X</button><strong>Success! </strong>Event created successfully.</div>');
			redirect('index.php/event-details');
		} else {
			$this->session->set_flashdata('msg', '<div class="alert alert-danger text-center" id="alert-msg"><button type="button" class="close" data-dismiss="alert">X</button><strong>Error! </strong>Something Went Wrong form not submitted.</div>');
			redirect('index.php/event-details');
		}
	}
	function event_details()
	{
		$data['title'] = 'Event';
		$data['event_details'] = $this->event_model->get_events();
		$this->load->view('templates/event-details',$data);
	}
	function get_events()
	{
		$data['title'] = 'Event';
		$data['get_events'] = $this->event_model->get_events();
		$this->load->view('templates/event-details',$data);
		
	}
	function get_events_all()
	{
		$data['title'] = 'Event';
		$data['get_events_all'] = $this->event_model->get_events_all('today');

		$this->load->view('templates/event-details',$data);
		//$this->load->view('templates/mentor-view-detail',$data);
	}
	function events_calendar()
	{
		echo $this->event_model->events_calendar();
	}
	function events_calendar_for_guru()
	{
		$mentor_id = $this->session->userdata('id');
		echo $this->event_model->events_calendar_guru($mentor_id);
	}
	function events_calendar_for_user()
	{
		$user_id = $this->session->userdata('id');
		echo $this->event_model->events_calendar_user($user_id);
	}
	
	function events_list_by_date(){
		$d = $this->input->get('selectDate');
		echo $this->event_model->get_events_by_date($d);
	}
	
	function events_list_by_date_for_mentor(){
		$mentor_id = $this->session->userdata('id');
		$d = $this->input->get('selectDate');
		echo $this->event_model->get_events_by_date_for_mentor($d,$mentor_id);
	}
	
	function get_data_for_pie_chart(){
		$event_id = $this->input->get('event_id');
		$data['applied'] = count_all_applied_students($event_id);
		$data['attended'] = count_attend_students($event_id);
		$data['feedback'] = count_feedback_students($event_id);
		
		echo json_encode($data);
	}
	
	
	//write your code above
}
