<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ask extends CI_Controller {

	function __construct(){
        parent::__construct();
        $this->load->helper(array('form','url','date','custom'));
        $this->load->library(array('session','form_validation','email'));
        $this->load->model('Ask_model');
        is_logged_in();

    }
	
	function get(){
		$sender_id = $this->input->post('sender_id');
		$receiver_id = $this->input->post('receiver_id');
		$result = $this->Ask_model->get_messages($sender_id,$receiver_id);
		
		$msgArr = [];
		foreach($result as $v){
			$data['id'] = $v->id;
			$data['sender_id'] = $v->sender_id;
			$data['receiver_id'] = $v->receiver_id;
			// if($v->s_type == 3){ $s_type = 3; $r_type = 2;}
			// elseif($v->s_type == 2){ $s_type = 2; $r_type = 3;}
			// $data['sender_name'] = $this->Ask_model->get_name_for_chat($v->sender_id,$s_type);
			// $data['receiver_name'] = $this->Ask_model->get_name_for_chat($v->receiver_id,$r_type);
			$data['msg'] = $v->msg;
			$data['time'] = date('M d, Y h:i:s a',strtotime($v->time));
			array_push($msgArr,$data);
		}
		echo json_encode($msgArr);
	}

	function read(){
		$sender_id = $this->input->post('sender_id');
		$receiver_id = $this->input->post('receiver_id');
		$msg_id = $this->input->post('msg_id');
		$result = $this->Ask_model->get_messages($sender_id,$receiver_id,$msg_id);
		
		
		$msgArr = [];
		foreach($result as $k => $v){
			$data['id'] = $v->id;
			$data['sender_id'] = $v->sender_id;
			$data['receiver_id'] = $v->receiver_id;
			// if($v->s_type == 3){ $s_type = 3; $r_type = 2;}
			// elseif($v->s_type == 2){ $s_type = 2; $r_type = 3;}
			// $data['sender_name'] = $this->Ask_model->get_name_for_chat($v->sender_id,$s_type);
			// $data['receiver_name'] = $this->Ask_model->get_name_for_chat($v->receiver_id,$r_type);
			$data['msg'] = $v->msg;
			$data['time'] = date('M d, Y h:i:s a',strtotime($v->time));
			array_push($msgArr,$data);
		}
		echo json_encode($msgArr);
	}
	
	function send(){

		if($this->session->userdata('usertype') == 2){
			$mentor_id = $this->input->post('sender_id');
		}else{
			$mentor_id = $this->input->post('receiver_id');
		}

		$msgArr = [
			'sender_id' => $this->input->post('sender_id'),
			'receiver_id' => $this->input->post('receiver_id'),
			'msg' => $this->input->post('msg'),
			's_type' => $this->session->userdata('usertype'),
			'mentor_id' => $mentor_id
		];
		$this->db->insert('nscm_ask',$msgArr);
		$last_row_id = $this->db->insert_id();
		$result = $this->db->select("time")->from("nscm_ask")->where("id", $last_row_id)->get();
		$get_time = $result->row()->time;
		$time = date('M d, Y h:i:s a',strtotime($get_time));
		
		$data['username'] = $this->session->userdata('username');
		$data['msg'] = $this->input->post('msg');
		$data['time'] = $time;
		echo json_encode($data);
	}
	
	function ask_history($id){

		$data['title'] = 'Ask Question History';
		$data['ask_history'] = $this->Ask_model->ask_history($id);
		$this->load->view('templates/admin-faq',$data);
	}
	

} //End Class
