<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Student extends CI_Controller {

	function __construct(){
        parent::__construct();
        $this->load->helper(array('form','url','date','custom'));
        $this->load->library(array('session','form_validation','email'));
        $this->load->model('Student_model');
        is_logged_in();

    }
	
	function index()
	{
		$data['title'] = 'Events List';
        $data['student_past_event'] = $this->Student_model->student_events('past');
        $data['student_upcoming_event'] = $this->Student_model->student_events('upcoming');
        // $this->load->view('templates/student-dashboard',$data);
        $this->load->view('templates/student-index',$data);
	}
	
	function profile(){
		$data['title'] = 'Profile';
		$data['profile'] = $this->Student_model->user_profile($this->session->userdata('id'));
		$this->load->view('templates/student-profile',$data);
	}
	
	function edit_profile($student_id = 0){
		//print_r($_POST);die;
		$data['profile'] = $this->Student_model->user_profile($student_id);
		
		$this->form_validation->set_rules('name','Name','trim|required');
		$this->form_validation->set_rules('email', 'Email', 'trim|required');
		$this->form_validation->set_rules('gender', 'Gender', 'trim|required');
		$this->form_validation->set_rules('technology', 'Technology', 'trim|required');
		$this->form_validation->set_rules('contact', 'User Name', 'trim|required');
		$this->form_validation->set_rules('address', 'Address', 'trim|required');
		$this->form_validation->set_rules('location', 'Location', 'trim|required');
		
		if($this->form_validation->run() === false){
			$data['title'] = 'Edit Profile';
			$this->load->view('templates/edit-student-profile',$data);
		} else {
			$this->db->set('name', $this->input->post('name'));
			$this->db->set('email', $this->input->post('email'));
			$this->db->set('gender', $this->input->post('gender'));
			$this->db->set('technology', $this->input->post('technology'));
			$this->db->set('contact', $this->input->post('contact'));
			$this->db->set('address', $this->input->post('address'));
			$this->db->set('location', $this->input->post('location'));
			$this->db->set('updated_date', date('Y-m-d h:i:s'));

			$this->db->where('id', $student_id);
			$is_updated = $this->db->update('nscm_students');

				if($is_updated) {
					$this->session->set_flashdata('msg', '<div class="alert alert-success text-center">Data updated successfully.</div>');
					redirect('index.php/student/profile');
				} else {
					$this->session->set_flashdata('msg', '<div class="alert alert-danger text-center">Not updated, try again.</div>');
	               redirect('index.php/edit-student-profile/'. $student_id);
				}
			}
		//$data['profile'] = $this->Student_model->user_profile($this->session->userdata('id'));
		//$this->load->view('templates/edit-student-profile',$data);
	}
	
    /*function get_events_student(){
        $this->load->model('Event_model');
        $data['get_events_student'] = $this->Student_model->get_events_student();
        $this->load->view('templates/student-dash',$data);

    }*/
    function student_events()
    {
        $data['title'] = 'Student Event Details';
        $data['student_past_event'] = $this->Student_model->student_events('past');
        $data['student_upcoming_event'] = $this->Student_model->student_events('upcoming');
        $this->load->view('templates/student-dashboard',$data);
    }
    function apply_event()
    {
        $data['apply_event'] = $this->Student_model->apply_event();
        $this->load->view('templates/student-view-detail', $data);
    }
	function delete_student($id)
    {
        if (empty($id))
        {
            show_404();
        }

        if($this->Student_model->delete_mentor($id)){
			$this->session->set_flashdata('message', 'Mentor Deleted Sucessfully');
			redirect('index.php/student');
		}		
    }
    /*Student ask a question*/
    function ask()
    {
        $data['title'] = 'Ask a question';
        $this->load->view('templates/faq',$data);
    }
    function applyforevent(){
        echo $this->Student_model->applyforevent($this->input->post());
    }
    /*Student Bar Chart*/
    function student_barchart()
    {
        echo $this->Student_model->student_barchart();
    }
    /*Student Feedback*/
    function student_feedback($event_id,$student_id)
    {
		$data['title'] = 'Feedback';
		$data['event_id'] = $event_id;
		$data['student_id'] = $student_id;
		$att_id =  student_feedback($event_id,$student_id);
		$result = $this->db->select('*')->from('nscm_feedback')->where('fk_att',$att_id)->get();
		$data['feedback'] = $result->row_object();
		$this->load->view('templates/feedback-form',$data);
		// $result = $this->Student_model->student_feedback($this->input->post(),$eid=0);
		// print_r($result);
		
    }
	
	function feedback_save()
	{
		$event_id = $this->input->post('event_id');
		$student_id = $this->input->post('student_id');
		$data['event_id'] = $event_id;
		$data['student_id'] = $student_id;
		
		$att_id =  student_feedback($event_id,$student_id);
		$arr = [
			'fk_att' => $att_id,
			'first_name' => $this->input->post('fname'),
			'last_name' => $this->input->post('lname'),
			'email' => $this->input->post('email'),
			'let_know' => $this->input->post('let_know'),
			'session_name' => $this->input->post('session_name'),
			'satisfied' => $this->input->post('satisfied'),
			'information' => $this->input->post('information'),
			'interest' => $this->input->post('interest'),
			'assessment' => $this->input->post('assessment'),
			'comments' => $this->input->post('comment'),
			'rating' => $this->input->post('rating')
		];
		$status = $this->db->insert('nscm_feedback',$arr);
		if($status){
			$this->session->set_flashdata('msg','Feedback has been successfully submitted');
		}else{
			$this->session->set_flashdata('msg','Try again. Something went wrong');
		}
		redirect('index.php/student-event-details');
	}
	
	function view_feedback(){
		$fid = $this->input->get('fid');
		$result = $this->db->select('*')->from('nscm_feedback')->where('id',$fid)->get();
		$feedback= $result->row_object();
		echo json_encode($feedback);
	}
	
} //End Class
