<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	function __construct(){

        parent::__construct();
        $this->load->helper(array('form','url','date','custom'));
        $this->load->library(array('session','form_validation','email'));
        $this->load->model('admin_model');
        is_logged_in();
    }

    function index(){

    	$data['title'] = 'Admin Dashboard';
    	$this->load->view('templates/index',$data);
    	//$this->load->view('templates/admin-calendar',$data);
	}
	
	function add_technology(){
		$data['title'] = 'Technology';
		$data['technologies'] = get_all_technology();
		$this->form_validation->set_rules('tech_name','Technology Name','required|trim');
		// $this->form_validation->set_rules('tech_logo','required|trim');
		 if ($this->form_validation->run() == FALSE){
			$this->load->view('templates/technology',$data);
		}else{
			$tech_name = $this->input->post('tech_name');
			$this->db->insert('nscm_technology',array('name'=>$tech_name));
			redirect('index.php/technologies');
		}
    	
    	//$this->load->view('templates/admin-calendar',$data);
	}
	
	function delete_technology(){
		$id = $this->input->post('tech_id');
		$update = $this->db->where('id',$id)->update('nscm_technology',array('active'=>0));
		$result = [];
		if($update){
			$result['msg'] = 'success';
		}else{
			$result['msg'] = 'failed';
		}
		
		echo json_encode($result);
		
	}
	
	
/*
    function add_admin()
	{
		$post_data = [
            'event_name' => $this->input->post('event_name'),
            'start_date' => $this->input->post('start_date'),
            'end_date' => $this->input->post('end_date'),
            'mentor_id' => $this->input->post('mentor_name'),
            'city' => $this->input->post('location'),
            'address' => $this->input->post('address')
        ];
		$add_data = $this->admin_model->add_admin($post_data);

    	if($add_data) {
      		$this->session->set_flashdata('msg', '<div class="alert alert-success text-center">Data created successfully.</div>');
			redirect('index.php/admin');
		} else {
			$this->session->set_flashdata('msg', '<div class="alert alert-danger text-center">Something Went Wrong form not submitted.</div>');
			redirect('index.php/admin');
		}
	}*/
	/*public function add_mentor()
	{
		$data['title'] = 'Add Mentor';
    	$this->load->view('templates/add-mentor',$data);
	}
	public function update_mentor()
	{
		$data['title'] = 'Update Mentor';
    	$this->load->view('templates/all-mentor',$data);
	}

	public function details()
	{
		$data['title'] = 'Mentor';
		$data['get_mentors'] = $this->mentor_model->get_mentors();

		$this->load->view('templates/mentor-view-detail',$data);
	}
	*/

	//write your code above
}
