<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Email extends CI_Controller {

	private $id;
    public function __construct()
    {
        parent::__construct();
        //$this->load->model('narayan/model');
        $this->load->library('form_validation');
        $this->load->library('parser');
    }

	public function index()
	{
		$data = [
			'title' => 'Zimplistic | Email',
	        'heading' => 'Zimplistic Heading',
	        'entries' => [
                ['title' => 'Title 1', 'body' => 'Body 1'],
                ['title' => 'Title 2', 'body' => 'Body 2'],
                ['title' => 'Title 3', 'body' => 'Body 3'],
                ['title' => 'Title 4', 'body' => 'Body 4'],
                ['title' => 'Title 5', 'body' => 'Body 5']
        	]
		];
		//$this->load->view('supervisor_analyst/email.php');
		$this->parser->parse('supervisor_analyst/email_view', $data);
	}
}
