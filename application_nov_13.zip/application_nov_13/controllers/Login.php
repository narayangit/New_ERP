<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function __construct()
	{
        parent::__construct();
        $this->load->helper(array('form','url','date','custom'));
        $this->load->library(array('session','form_validation','email'));		
    }
    
	public function index()
	{
		$usertype = $this->session->userdata('usertype');
		if($usertype == 1){
			redirect('index.php/dashboard1');
		}else if($usertype == 2){
			redirect('index.php/dashboard2');
		}else if($usertype == 3){
			redirect('index.php/dashboard3');
		}
		
		$this->load->model('login_model');
		$data['title']='Login';
		$email = $this->input->post("email");
        $password = $this->input->post("pass");
        
        $this->form_validation->set_rules('email', 'User Name', 'trim|required');
		$this->form_validation->set_rules('pass', 'Password', 'trim|required');
		
		if ($this->form_validation->run() == FALSE) {
			$this->load->view('templates/login',$data);
		}else{
			$usr_result = $this->login_model->getUser($email,$password);

			if ($usr_result > 0){

				// Function defined in custom_helper
				$get_user_detail = $this->login_model->user_auth($email);

				if( $get_user_detail['active'] === '1' ){

					// set the session data
					$session_data = array(
						'id' => $get_user_detail['id'],
						'username' => $get_user_detail['username'],
						'email' => $get_user_detail['email'],
						'password' => $get_user_detail['password'],
						'usertype' => $get_user_detail['user_type'],
						'is_logged_in' => TRUE
					);
					$this->session->set_userdata($session_data);
					
					if($get_user_detail['user_type'] === '1'){
						redirect('index.php/dashboard1');
					}elseif($get_user_detail['user_type'] === '2'){
						redirect('index.php/dashboard2');
					}elseif($get_user_detail['user_type'] === '3'){
						redirect('index.php/dashboard3');
					}
				}
			}else{
				$this->session->set_flashdata('msg', '<div class="message"><span class="message-content" style="color:#FF0000;"><i class="fa fa-info-circle"></i>Email or Password Incorrect
					<a href="login"><i class="fa fa-close pull-right"></i></a></span></div>');
                redirect('index.php/login');
			}
		}
	}

	public function logout()
	{
		 $user_data = $this->session->all_userdata();
         foreach ($user_data as $key => $value) {
            if ($key != 'session_id' && $key != 'ip_address' && $key != 'user_agent' && $key != 'last_activity') {
                $this->session->unset_userdata($key);
            }
        }
       redirect('index.php/login');
	}
	
	//write your code above
}
